echo "Enter Mysql Credential :"
read -p "Username : " ROOT_USER
read -p "Password : " ROOT_PASSWORD
NOW=$(date +"%m_%d_%Y")
BACKUP_DIR="__database_backup_${NOW}" 
if [ -z $ROOT_USER ]; then
    echo "Username is Required." 
    exit
fi
if [ -z $ROOT_PASSWORD ]; then
    echo "Password is Required." 
    exit
fi
[ ! -d "$BACKUP_DIR" ] && mkdir -p "$BACKUP_DIR"
for DB in $(mysql -u "$ROOT_USER" -p"$ROOT_PASSWORD" -e 'show databases' -s --skip-column-names 2>/dev/null); do
    DB_NAME=$(echo -e "${DB}" | tr -d '[:space:]') #(Removing all spaces, tabs, newlines, etc from a variable)
    if [ $DB_NAME != "Database" ] && [ $DB_NAME != "dbispconfig" ] && [ $DB_NAME != "mysql" ] && [ $DB_NAME != "performance_schema" ] && [ $DB_NAME != "information_schema" ] && [ $DB_NAME != "phpmyadmin" ] && [ $DB_NAME != "sys" ]; then
        COUNT_TABLES=$(mysql $DB_NAME -u $ROOT_USER -p$ROOT_PASSWORD -se "SELECT COUNT(*) AS TOTALNUMBEROFTABLES FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '$DB_NAME'" 2>/dev/null)
        COUNT_ROWS=$(mysql $DB_NAME -u $ROOT_USER -p$ROOT_PASSWORD -se "SELECT SUM(TABLE_ROWS) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='$DB_NAME'" 2>/dev/null)
        echo "[ $DB_NAME ]"
        echo -e " \t Total no of tables: $COUNT_TABLES"
        echo -e " \t Total no of rows: $COUNT_ROWS"
        mysqldump -u "$ROOT_USER" -p"$ROOT_PASSWORD" --no-tablespaces $DB_NAME > "$BACKUP_DIR/$DB_NAME.sql" 2>/dev/null #( 2>&1 : hide warning )
    	echo -e "\e[1m DONE: \e[92mExported Database is : $DB\e[0m"
    fi
done
