-- phpMyAdmin SQL Dump\
-- version 4.9.10\
-- https://www.phpmyadmin.net/\
--\
-- Host: localhost:8889\
-- Generation Time: Jan 10, 2025 at 11:31 AM\
-- Server version: 5.7.39\
-- PHP Version: 5.6.40\
\
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";\
SET time_zone = "+00:00";\
\
--\
-- Database: `inczwolle_plan`\
--\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `areas`\
--\
\
CREATE TABLE `areas` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) NOT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `areas`\
--\
\
INSERT INTO `areas` (`id`, `name`, `workspace_id`, `created_at`, `updated_by`, `updated_at`) VALUES\
(11, 'Area', 4, '2015-03-27 09:40:27', NULL, '0000-00-00 00:00:00'),\
(12, 'Area2', 4, '2015-03-27 09:40:30', NULL, '0000-00-00 00:00:00'),\
(13, 'Area 3', 4, '2015-03-27 09:40:35', NULL, '0000-00-00 00:00:00'),\
(14, 'Area4 ', 4, '2015-03-27 09:40:38', NULL, '0000-00-00 00:00:00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `companies`\
--\
\
CREATE TABLE `companies` (\
  `id` int(11) NOT NULL,\
  `workgroup_id` int(11) NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `additional_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `zipcode` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `city` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `country` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `general_phone_number` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `general_mail_address` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `short_description` text COLLATE utf8_unicode_ci,\
  `website_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `facebook_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `linkedin_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `twitter_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `companies`\
--\
\
INSERT INTO `companies` (`id`, `workgroup_id`, `name`, `additional_name`, `address`, `zipcode`, `city`, `country`, `general_phone_number`, `general_mail_address`, `logo`, `short_description`, `website_url`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES\
(1, 1, 'Devrepublic', '', 'ahmedabad', '7701CA', 'Dedemsvaart', 'India', '1234', 'jaykesh@devrepublic.nl', 'user_07012015_115013.png', 'short description', 'google.com', 'https://www.facebook.com/', 'http://google.com', 'https://twitter.com/creatiefcoop', NULL, 2, '2014-12-06 10:25:13', '2021-07-01 04:21:29'),\
(6, 2, 'Movin Software', 'test123', 'Westerlaan 51', '8011 CA', 'Zwolle', 'NL', '', 'info@movinsoftware.nl', NULL, '', 'www.movinsoftware.nl', '', '', '', 15, NULL, '2015-02-05 19:47:36', '2016-01-12 09:04:24'),\
(7, 2, 'Maarten Kuiper Business Technology', '', 'Windesheimstraat 18', '8012 WZ', 'Zwolle', 'NL', '', 'mail@maartenkuiper.nl', NULL, '', 'www.maartenkuiper.nl', '', '', '', 15, 2, '2015-02-05 19:56:41', '2015-02-12 05:00:14'),\
(8, 2, 'Sco-re', '', 'Westerlaan 51', '8011 CA', 'Zwolle', 'NL', '', 'jeroen@sco-re.nl', NULL, '', 'www.sco-re.nl', '', '', '', 15, 15, '2015-02-11 15:12:20', '2015-02-17 08:34:31'),\
(9, 0, 'Durieux BV', '', 'Snelliuslaan 2', '8024XE', 'Zwolle', 'NL', '0611', 'dirkjan@durieux.nl', NULL, '', 'www.durieux.nl', '', '', '', 15, 15, '2015-02-11 17:43:42', '2015-02-17 11:00:57'),\
(10, 2, 'NewWeb & Co', '', 'Molendwarsstraat 19', '8012TR', 'Zwolle', 'NL', '06-49196922', 'tim@newweb.co', NULL, '', 'www.newweb.co', '', '', '', 15, NULL, '2015-02-17 11:23:15', '2015-02-17 11:23:15'),\
(11, 0, 'Lijkendijk Communicatie', '', 'Sint Jurrienstraat 38', '7412XJ', 'Deventer', 'NL', '', 'info@lijkendijk.com', NULL, '', '', '', '', '', 15, NULL, '2015-02-17 12:14:47', '2015-02-17 12:14:47'),\
(12, 2, 'KADCO', '', 'P.O. Box 10', '', 'Kilimanjaro', 'Tanzania', '', 'bmurusuri@kadco.co.tz', NULL, '', '', '', '', '', 15, NULL, '2015-03-06 11:47:08', '2015-03-06 11:47:08'),\
(15, 4, 'IncZwolle ', '', 'Snelliuslaan 2', '8024XE', 'Zwolle', '', '06 15000630', 'info@inczwolle.nl', NULL, '', '', '', '', '', NULL, NULL, '2015-04-29 17:05:54', '2015-04-29 17:05:54'),\
(16, 2, 'SuperBuddy', '', 'Amsterdamseweg 8F', '3812 RS', 'Amersfoort', 'Nederland', '', 'info@superbuddy.nl', NULL, '', 'www.superbuddy.nl', '', '', '', NULL, NULL, '2015-05-11 06:29:59', '2015-05-11 06:29:59'),\
(17, 2, 'YA Marketing', '', 'Westerlaan 51', '8011 CA', 'Zwolle', 'Nederland', '', 'yspeert@gmail.com', '2760735506a5bc187a35f6c829fae70d.jpg', 'Arjan Yspeert', '', '', '', '', NULL, 15, '2015-05-19 04:45:45', '2015-08-05 10:48:40'),\
(19, 2, 'Cibap ', '', 'Postbus 868', '8000 AW', 'Zwolle', 'Nederland', '', 'info@cibap.nl', NULL, '', '', '', '', '', 15, NULL, '2015-06-30 06:42:36', '2016-08-17 05:07:46'),\
(20, 2, 'Christelijke Hogeschool Windesheim', '', 'Postbus 10090', '8000 GB ', 'Zwolle', '', '', '', NULL, '', '', '', '', '', 15, 15, '2015-07-01 11:48:46', '2015-07-01 11:49:43'),\
(22, 2, 'Ik Circuleer', '', 'Bilderdijkstraat 16', '8023 BR', 'Zwolle', '', '06-53838257', 'info@ikcirculeer.nl', NULL, '', 'www.ikcirculeer.nl', '', '', '', 15, NULL, '2015-09-24 13:07:24', '2015-09-24 13:07:24'),\
(23, 2, 'DC Vastgoed', '', 'Boreelplein 71', '7411 EH ', 'Deventer', '', '', 'info@dcvastgoed.nl', NULL, '', '', '', '', '', 15, 15, '2015-10-15 07:42:27', '2015-10-15 07:43:12'),\
(24, 2, 'Stichting Kennis &  Rendement ', '', 'Schrevenweg 2 ', '8024HA', 'Zwolle', 'Nederland', '', '', NULL, '', '', '', '', '', 15, 15, '2015-11-03 08:23:26', '2015-11-03 08:25:36'),\
(25, 4, 'Prospects Pressure Cooker', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-11-24 09:40:52', '2015-11-24 09:40:52'),\
(26, 2, 'Deloitte Group Support Center B.V.', '', 'Postbus 2031', '3000 CA ', 'Rotterdam', '', '', '', NULL, '', '', '', '', '', 15, 15, '2015-12-04 12:23:47', '2015-12-07 12:51:03'),\
(28, 2, 'Ijsselheem', '', 'Engelenbergplantsoen 3', '8266 AB ', 'Zwolle', '', '038 339 44 00 ', 'info@ijsselheem.nl', NULL, '', '', '', '', '', NULL, NULL, '2015-12-07 12:46:04', '2015-12-07 12:46:04'),\
(29, 7, 'Geen bedrijf', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-08 12:20:03', '2015-12-08 12:20:03'),\
(31, 2, 'Isala Academie', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-10 12:45:22', '2015-12-10 12:45:22'),\
(32, 2, 'Gemeente Zwolle', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-10 13:10:21', '2015-12-10 13:10:21'),\
(33, 2, 'Windesheim', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-10 13:49:38', '2015-12-10 13:49:38'),\
(34, 2, 'De Jong en Laan ', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-11 10:12:03', '2015-12-11 10:12:03'),\
(35, 2, 'Love to Fund', '', '', '', '', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-11 11:55:06', '2015-12-11 11:55:06'),\
(36, 2, 'ABN-AMRO', '', 'Grote Voort 247', '', 'Zwolle', '', '', '', NULL, '', '', '', '', '', NULL, NULL, '2015-12-18 11:37:31', '2015-12-18 11:37:31'),\
(37, 2, 'Pickthisup.nl', '', 'Padualaan 8', '', 'Utrecht', '', '', '', NULL, '', '', '', '', '', 15, NULL, '2015-12-30 07:23:04', '2015-12-30 07:23:04'),\
(38, 1, 'Deltion College', '', 'Mozartlaan 15', '8031 AA', 'Zwolle ', 'Nederland', '', '', NULL, 'Postbus 565, 8000 AN, Zwolle', 'www.deltion.nl', NULL, NULL, NULL, NULL, NULL, '2016-01-07 13:10:31', '2016-01-07 13:10:31'),\
(39, 2, 'Deltion College', '', 'Mozartlaan 15', '8031 AA', 'Zwolle ', 'Nederland', '', '', NULL, 'Postbus 565, 8000 AN, Zwolle', 'www.deltion.nl', NULL, NULL, NULL, NULL, NULL, '2016-01-07 13:12:04', '2016-01-07 13:12:04'),\
(42, 2, 'Van Hall Larenstein University of Applied Sciences', '', 'Postbus 9001', '6880 GB', 'Velp', 'Nederland', '', '', NULL, 'Postbus 9001\\r\\n6880 GB Velp', 'www.hogeschoolvhl.nl', '', '', '', 15, 15, '2016-01-15 11:23:01', '2021-07-01 17:25:40'),\
(43, 2, 'SenZ. Interim', '', '', '', 'Enschede', 'Nederland', '', '', NULL, 'Bedrijf Robin Fr\'f6lich', '', NULL, NULL, NULL, NULL, NULL, '2016-01-19 08:58:31', '2016-01-19 08:58:31'),\
(44, 2, 'Trenica', '', '', '', '', 'Nederland', '', '', NULL, 'Bedrij Ted Travers en Marjan van Lambalgen', '', NULL, NULL, NULL, NULL, NULL, '2016-01-20 14:33:49', '2016-01-20 14:33:49'),\
(45, 2, 'IJsselvliet', '', '', '', 'Zwolle', 'Nederland', '', '', NULL, '', '', NULL, NULL, NULL, NULL, NULL, '2016-01-21 11:42:19', '2016-01-21 11:42:19'),\
(46, 2, 'Rikkl', '', '', '', '', 'Nederland', '', '', NULL, '', '', NULL, NULL, NULL, NULL, NULL, '2016-01-22 10:05:06', '2016-01-22 10:05:06'),\
(47, 2, 'Mepschenbouw', '', 'Noordwijk 12', '7751 AJ', 'Dalen', '', '0683198587', 'info@mepschenbouw.nl', NULL, '', '', '', '', '', 15, 15, '2016-02-02 12:39:54', '2016-02-02 12:43:25'),\
(48, 2, 'Rijnconsult', '', '', '', 'Houten', 'Nederland', '', '', NULL, '', 'http://www.rijnconsultonderwijsict.nl/', NULL, NULL, NULL, NULL, NULL, '2016-02-04 17:50:03', '2016-02-04 17:50:03'),\
(49, 2, 'Fundatis B.V.', '', 'Zuid Hollandlaan 7', '2596 AL', 'Den Haag', 'Nederland', '', '', NULL, '', 'www.fundatis.nl', '', '', '', 15, 15, '2016-03-04 14:53:17', '2018-11-02 09:06:54'),\
(50, 2, ' Lucrasoft Solutions BV', '', 'De Zelling 8', '3342 GS', 'Hendrik Ido Ambacht', 'Nederland', '', 'info@lucrasoft.nl', NULL, '', '', '', '', '', 15, NULL, '2016-05-30 18:06:45', '2016-10-21 06:58:01'),\
(51, 2, 'Jenrick Nederland B.V.', '', 'Postbus 85426', '3508 AK', 'Utrecht', 'Nederland', '0345-516363', 'dirkjan75@gmail.com', NULL, 'Herculesplein 104a\\r\\n3584 AA Utrecht', 'www.jenrick.nl', '', '', '', 15, 15, '2016-07-01 06:52:47', '2017-04-03 09:38:29'),\
(52, 2, 'In Principo B.V.', '', 'Eemskanaal 24\\r\\n', '9713 AA ', 'Groningen', 'Nederland', '', '', NULL, '', '', NULL, NULL, NULL, NULL, NULL, '2016-09-12 12:51:13', '2016-09-12 12:51:13'),\
(53, 2, 'Lokaal lokaal', '', '', '', '', '', '', 'wellner@xs4all.nl', NULL, '', '', '', '', '', 15, NULL, '2017-12-08 09:12:32', '2017-12-08 09:12:32'),\
(54, 2, 'Myler B.V.', '', 'Postbus 85426', '3508 AK ', 'Utrecht', '', '+31 (0)30 711 4', 'facturen@myler.nl', NULL, '', '', '', '', '', 15, 15, '2018-04-05 13:23:22', '2018-04-05 13:24:56'),\
(55, 2, 'De Vliegende Onderzoeker', '', 'Mengerweg 19', '8124PG', 'Wesepe', 'Nederland', '', 'saskia@devliegendeonderzoeker.nl', NULL, 'Mengerweg 19, 8124PG Wesepe', '', '', '', '', 15, 15, '2019-01-06 09:34:17', '2021-01-30 14:15:15'),\
(56, 2, 'Stichting Hogeschool Utrecht', '', 'Postbus 85083', '3508 AB', 'Utrecht', '', '', '', NULL, '\\r\\n\\r\\n\\r\\n', '', '', '', '', 15, NULL, '2019-04-05 09:29:13', '2019-04-05 09:29:13'),\
(57, 2, 'HeadFirst IT BV', '', 'Polarisavenue 33', '2130 GE', 'Hoofddorp', 'Nederland', '', 'facturatie@headfirst.nl', NULL, '', 'www.headfirst.nl', '', '', '', 15, 15, '2019-09-02 06:57:40', '2020-12-02 15:26:33'),\
(58, 2, 'Technische Universiteit Eindhoven', '', 'Postbus 513', '5600 MB', 'Eindhoven', 'Nederland', '', 'factuuradministratie@tue.nl', NULL, '', '', '', '', '', 15, NULL, '2019-11-04 14:34:45', '2019-11-04 14:34:45'),\
(59, 2, 'Vrije Universiteit Amsterdam', '', 'De Boelelaan 1105', '1081 HV', 'Amsterdam', 'Nederland', '', 'invoice@vu.nl', NULL, '', 'ww.vu.nl', '', '', '', 15, NULL, '2020-02-02 09:22:44', '2020-02-02 09:22:44'),\
(60, 2, 'Van Velden Procesadvies', '', 'Koopvaardersplantsoen 49b', '1034 CC', 'Amsterdam', '', '', 'annapapillon@hotmail.com', NULL, '', '', '', '', '', 15, 15, '2020-02-29 08:13:05', '2020-02-29 08:21:14'),\
(61, 2, 'Technische Universiteit Delft', '', 'Stevinweg 1', '2628 CN', 'Delft', 'Nederland', '', 'inkoop-finance@tudelft.nl', NULL, '', '', '', '', '', 15, NULL, '2020-05-03 05:22:52', '2020-05-03 05:22:52'),\
(63, 2, 'Universiteit Leiden', '', 'Postbus 9500', '2300 RA', 'Leiden', '', '', '', NULL, '', '', '', '', '', 15, 15, '2020-07-04 05:40:11', '2020-07-04 10:20:20'),\
(64, 0, 'Radboud Universiteit', '', 'Postbus 6751', '6503 GG', 'NIJMEGEN', 'Nederland', '', '', NULL, '', '', '', '', '', 15, NULL, '2020-09-08 05:38:38', '2020-09-08 05:38:38'),\
(65, 2, 'Reijn Staffing B.V.', '', 'Postbus 748', '5700 AS', 'Helmond ', 'Nederland', '', 'facturen@reijnprofessionals.nl', NULL, ': Reijn Staffing B.V. Postbus 748 5700 AS Helmond', '', '', '', '', 15, 15, '2021-01-30 11:16:41', '2021-01-30 11:19:08'),\
(66, 2, 'Monyet Advies & Beheer', '', 'Voorhelmstraat 9 RD', '2012 ZM', 'Haarlem', 'Nederland', '+31 6 26 49 48 ', '', NULL, ',  ', '', '', '', '', 15, NULL, '2021-03-09 10:54:20', '2021-03-09 10:54:20'),\
(68, 2, 'Hogeschool voor de Kunsten Utrecht', '', 'Postbus 1520', '3500 BM ', 'Utrecht', 'Nederland', '', '', NULL, '', '', '', '', '', 15, 15, '2021-06-01 06:17:55', '2021-06-01 06:25:05'),\
(69, 0, 'Stichting Hanzehogeschool Groningen', '', 'Postbus 751', '9700 AT ', 'Groningen', '', '', 'facturen@org.hanze.nl', NULL, '\\r\\n\\r\\n', '', '', '', '', 15, NULL, '2021-06-06 03:24:45', '2021-06-06 03:24:45'),\
(70, 0, 'Hogeschool van Amsterdam', '', 'Postbus 516', '1000 AM', 'Amsterdam', '', '', 'digifactuur@hva.nl', NULL, '\\r\\n ', '', '', '', '', 15, NULL, '2021-06-06 04:05:00', '2021-06-06 04:05:00'),\
(71, 2, 'Hans Valkenburg BV', '', 'Lange Smeestraat 45', '3511 PV', 'Utrecht', '', '', '', NULL, '', '', '', '', '', 15, NULL, '2021-07-01 16:14:28', '2021-07-01 16:14:28'),\
(72, 2, 'Dummy', '', 'dummystraat', '8033 BK', 'Zwolle', 'Nederland', '', '', NULL, '', '', '', '', '', 77, 77, '2021-08-20 07:49:01', '2021-08-20 07:50:06'),\
(73, 0, 'Tilburg University / Accounts Payable', '', 'Postbus 90153', '5000 LE', 'Tilburg', 'Nederland', '', '', NULL, '', '', '', '', '', 77, NULL, '2021-09-27 09:38:05', '2021-09-27 09:38:05'),\
(74, 0, 'Academisch Medisch Centrum', '', 'Postbus 400', '1115 ZJ', 'Duivendrecht', '', '', 'c.meijer@amsterdamumc.nl', NULL, 't.a.v. crediteurenadministratie', '', '', '', '', 77, 77, '2021-11-03 10:17:30', '2021-11-03 10:18:33'),\
(75, 0, 'Universitair Medisch Centrum Groningen', '', 'Postbus 998', '9700 AZ', 'Groningen', '', '', 'crediteuren@umcg.nl', NULL, 't.a.v crediteurenadministratie', '', '', '', '', 77, NULL, '2021-12-03 12:39:51', '2021-12-03 12:39:51'),\
(76, 0, 'Fluo B.V.', '', 'Snelliuslaan 2', '8024 XE', 'Zwolle', 'NL', '', '', NULL, '', '', '', '', '', 77, 77, '2021-12-14 06:55:50', '2021-12-14 06:57:31'),\
(77, 2, 'Graafschap College', '', 'Julianaplein 2', '7001 HG', 'Doetinchem', '', '', 'crediteuren@graafschapcollege.nl', NULL, '', '', '', '', '', 77, NULL, '2022-02-02 12:00:33', '2022-02-02 12:00:33');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `company_notes`\
--\
\
CREATE TABLE `company_notes` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `user_id` int(10) UNSIGNED NOT NULL,\
  `company_id` int(11) NOT NULL,\
  `notes` text NOT NULL,\
  `created_datetime` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `company_notes`\
--\
\
INSERT INTO `company_notes` (`id`, `user_id`, `company_id`, `notes`, `created_datetime`) VALUES\
(7, 5, 1, 'test', '2015-03-27 09:23:16');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `contactperson_note`\
--\
\
CREATE TABLE `contactperson_note` (\
  `id` int(11) NOT NULL,\
  `contact_id` int(11) NOT NULL,\
  `added_by` int(11) NOT NULL,\
  `notes` text NOT NULL,\
  `created_datetime` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `contactperson_note`\
--\
\
INSERT INTO `contactperson_note` (`id`, `contact_id`, `added_by`, `notes`, `created_datetime`) VALUES\
(1, 4, 3, 'test123456', '2015-09-22 08:10:17'),\
(2, 23, 24, 'Vriendin van Nathalie Hagen, gaat Ondernemers in Bedrijf Harderwijk doen. Heeft handel in opknappen van Triptraps en andere marktplaats handel. Zoekt structuur en eigenlijk focus en een goed business model rondom haar talent. Tante doet nu administratie , oom helpt ook wat mee, PC lijkt haar daarom (nog) niet opportuun. Wellicht maart 2016', '2015-11-24 10:47:15'),\
(3, 22, 24, 'Dakdekkers bedrijf. Liefde voor het vak en vakmanschap', '2015-11-24 10:48:08'),\
(4, 22, 24, 'Zoekt ondernemershandvaten\\n', '2015-11-24 10:48:26'),\
(6, 3, 24, 'Note 1\\n', '2015-11-26 21:21:14'),\
(7, 3, 24, 'Note 2', '2015-11-26 21:21:23'),\
(8, 3, 24, 'De ambitie van IncZwolle is om de Zwolse startersmarkt een impuls te geven. Dit doet ze door potenti\'eble en beginnende starters in de omgeving te ondersteunen. Deze ondersteuning kan zijn in de vorm van coaching. Ook kunnen startups deelnemen aan workshops zoals de Pressure Cooker, een programma waarbij ze in twaalf interactieve avondsessies hun bedrijfsplan tegen het licht houden en herschrijven of (opnieuw) opstellen. IncZwolle biedt tevens flexplekken aan waar mensen aan hun plan kunnen werken. Tenslotte heeft de starter de mogelijkheid om gebruik te maken van het netwerk van IncZwolle om contacten te leggen. In de toekomst willen ze gaan werken met onder andere een mentorenprogramma, starterskapitaal en participatie in de startende ondernemingen. \\n\\nDe trainingsprogramma\'92s zijn op dit moment de hoofdbronnen van inkomen voor IncZwolle. \\nDe Pressure Cooker valt onder deze trainingsprogramma\'92s, maar ook bijvoorbeeld masterclasses die worden gegeven aan andere organisaties die starters ondersteunen, masterclasses voor ondernemers in veranderprocessen en workshops op scholen.\\n\\nDe communicatie van IncZwolle is vooral informerend. Op de website wordt naast de missie en de visie vooral aandacht geschonken aan de inhoud van de producten van IncZwolle. Over de huidige website is ontevredenheid, op dit moment worden problemen en mogelijke verbeterpunten in kaart gebracht. Twitter wordt vooral gebruikt voor het delen van nieuws voor starters terwijl Facebook vooral gericht is op nieuws van IncZwolle, zoals georganiseerde activiteiten. LinkedIn wordt nog weinig gebruikt, maar dit staat wel op de agenda.\\n\\n\\n', '2015-11-26 21:22:09'),\
(10, 4, 3, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ', '2015-11-30 12:32:54'),\
(11, 24, 24, 'Je is afgestudeerd SEO, online marketing en na tevergeefs solliciteren gaat ze voor zichzelf beginnen. Heeft onvoldoende geld om mee te doen aan PC en woont in Enschede regio.', '2015-12-01 08:23:37'),\
(12, 1, 51, 'test', '2015-12-09 10:24:27'),\
(14, 32, 24, 'Bep Bruggink en ... Bos werken nog steeds op stagebureau. Destijds betrokken bij geweest via Windesheim Verpleegkunde \\n', '2015-12-10 13:47:06'),\
(15, 35, 24, 'Standplaats H\\'wijk, doet diverse Jon en Laan vestigingen, waaronder Putten, Dronten, Zwolle enz. \\nIs zelf al bezig met het BMC om dit in te zetten als tool bij huidige klanten. \\nMet haar afgesproken dat ik eerst op bezoek ga, John de Vlieger zal ook bij het gesprek aanwezig zijn. Ingestoken op de Deloitte problematiek  , hoe een ander gesprek te voeren bij klanten. Tijdens presentatie iets laten zien over op welke wijze Inc BMC laat zien en ook vooruitblik naar andere modellen. Combinatie met 1 op 1 coaching sprak haar aan. ', '2015-12-11 11:16:01'),\
(16, 37, 24, 'Gesproken over gezamenlijk Peper en zout te organiseren. Hier vanaf gezien op haar voorstel omdat het onderwerp niet echt leeft bij starters. ', '2015-12-11 12:34:08'),\
(17, 37, 24, 'Afgesproken om feb / maart met haar in gesprek te gaan over gezamenlijke sessie voor na zomer 2016\\n', '2015-12-11 12:34:45'),\
(18, 40, 24, 'Mira Bloemen: heeft klus voor 2e jaar Wincubator studentbegeleiding zojuist ingevuld, maar gaf aan een archeif te hebben van mensen die op onderdelen (lessen, begeleiding enz.) ingehuurd worden. Afgesproken dat ik haar mijn CV mail met beschikbaarheid en inhoud zodat ze ik bij haar bekend ben. ', '2015-12-14 10:28:48'),\
(19, 40, 24, 'CV verstuurd, profiel Durieux dec 2015', '2015-12-14 12:39:45'),\
(20, 36, 24, 'Via John de Vlieger : Hans Lueks: hoofd educatie, zit in Vroomshoop 0546-660760, ieder jaar publiceren we in maart het nieuwe educatieaanbod binnen DJL. Wellicht kun je in dit aanbod meegenomen worden? Wij werken op basis van vrijwillige inschrijving, maar Carla heeft op deze wijze wel 4 trainingen verzorgt. Aan jou de taak om dan een goed aanbod neer te zetten (noem vooral je samenwerking met Deloitte). \\n', '2015-12-15 13:55:57'),\
(21, 35, 24, 'Via John de Vlieger:  Miranda Kruithof: recent bij ons gestart als strategisch HR adviseur. Voorstander van BMC en ziet hier veel mogelijkheden en toegevoegde waarde binnen DJL. 06-23697812. Wellicht kun je via haar een keer een presentatie geven aan het commerci\'eble team van een vestiging (daar zit dan vaak ook een partner bij).  \\n', '2015-12-15 13:57:02'),\
(22, 42, 24, '18012 afspraak gehad met Jan en Gera. \\nDeden mee met GEW op basis van persoonlijke relatie Eric vd Ham en hun baas Marcel...\\nJan is persoonblijk enthousiast geworden om met die starters wat te doen en vindt het een (maatschappelijke) verantwoordelijk om hier wat mee te doen vanuit de bank, maar ziet er verder geen commerciele waarde in voor de bank. De bank heeft overigens een andere tak (klein bedrijf, ipv klein zakelijk) die de eerste starters doet, Wico Vaartjes en Matthijs Fransen). Baas van Klein bedrijf is Kees Schomans. Afgesproken is om met hem en zijn twee adviseurs een vervolg afspraak te maken, om ', '2015-12-18 12:44:53'),\
(23, 42, 24, 'om, te kijken of ABN AMRO wil investeren in de starters in onze regio via IncZwolle. ABN AMRO werkt nu met intermediairs die doorverwijzen naar de bank, en IncZwolle zou sowieso intermediair kunnen worden. Verder is ABNAMRO recentelijk niet regionaal maar per sector ingedeeld, maar omdat in onze regio de sectoren te smal zijn, is dit weer wat verbreed\\nDe bank is er plat, wil weinig investeren in starters want daar verdienen ze niets aan en het eerst zaaien en dan oogsten werkt ook minder goed omdat bedrijven op latere leeftijd (wanneer ze volgroeit zijn) sneller wisselen van bank indien deze ze een beter aanbod doet. \\nJan en Gera werden getriggerd door de driehoek analogie van instututen-starters-jonge bedrijven- instituten. Toen ik vertelde wat incZwolle allemaal deed , ook voor Deloitte en wat we voor andere bedrijven zouden kunnen betekenen (product push) vonden ze dat interessant. \\n\\n', '2015-12-18 12:49:35'),\
(24, 28, 24, '4-1-2016: gevraagd of ze mij wil terugbellen. Collega gesproken\\n', '2016-01-04 14:22:04'),\
(25, 32, 24, 'rechtstreekse nummer 038 -424 5824?\\n', '2016-01-04 14:38:21'),\
(26, 46, 24, 'Anne-Jur vandaag op bezoek gehad bij IncZwolle, met hem gesproken over ondernemerschap in Zwolle, Deltion en welke rol IncZwolle hierin zou kunnen spelen. Afgesproken dat IncZwolle in Maart een themabijeenkomst/masterclass organiseert rondom een nog in te vullen thema, als begin van een mogelijke samenwerking met Deltion. Deze is gratis, en dient als pilot voor verder. \\n', '2016-01-07 14:15:30'),\
(27, 32, 24, 'En weer gebeld, maar niet aanwezig. volg week dinsdag zo kunnen ', '2016-01-19 13:26:18'),\
(28, 51, 24, 'Met Ted gesproken over samenwerking IncZwolle en Trenica. Ze zijn actief op aanvraag financiering, innovatie, marketing / sales. Willen aan de voorkant geen trainingen geven maar zien wel dat hun projecten / deelnemerds dat nodig hebben. Afgesproken om een (vrijblijvende) samenwerking aan te gaan waarbij zij ons hun klanten aanleveren om ge\'ednct\\' te worden . Wij attenderen hen op personen die ons programma hebben doorlopen en wellicht voor hun interessant zijn.', '2016-01-20 15:45:46'),\
(29, 53, 24, 'Gevraagd gesprek om Startbaan/GroeiXL te toetsen en wellicht samenwerking in relatie tot hun HR advies opdrachten (wij training, zij advies)\\n', '2016-01-21 12:47:45'),\
(30, 53, 24, 'Afspraak wordt ingepland met collega HR adviseur Anteun Braakman \\n', '2016-01-22 09:51:56'),\
(32, 35, 24, 'Vandaag gesprek met Miranda gehad. Was met name ge\'efnteresseerd in Groei XL. Zij zal met haar partner dit bespreken of groei xl, met name attitudeverandering , iets is wat ze met IncZwolle willen proberen. In feb of maart komt zij erop terug. ', '2016-02-02 13:37:10'),\
(33, 57, 24, 'Gesprek gehad in Houten, hij heeft mij het bedrijf uitgelegd. 5 personen vast in dienst, daaromheen een flexibele schil met ZZPers die wel ook Rijnconsult uitdragen. Zijn vooral bezig in VO en MBO, met digitale leermiddelen en didactiek. WIllen graag ook HBO doen. Heb hun aangegeven dat op HBO het gaat over LMS en SIS implementatie. VOoral de LMS kan interessant zijn omdat zij ook de inhoudelijke kennis hebben hierover (Blended leadning). Koppel dit aan een software systeem en je hebt een totaal aanpak. VOnd die erg interessant. Afgesproken voor de zomer 2016 nog een keer bij te praten. ', '2016-02-04 18:56:51'),\
(34, 54, 24, 'Gesprek gevoerd vandaag 27 mei 2016 om te bezien of Ijsselvliet iets kon betekenen in een gezamenlijke propositie voor GROEI XL. Kennis gemaakt met Anteun, slimme consultant, 30 jaar, net vader, wartsila gewerkt en bij CV ketel boer in Apeldoorn alvorens bij Ijsselvliet te komen. \\nBerend oosterhuis was bij gesprek aanwezig. Over twee weken contact. ', '2016-05-27 19:52:26');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `contacts`\
--\
\
CREATE TABLE `contacts` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `company_id` int(11) DEFAULT NULL,\
  `first_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,\
  `middle_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,\
  `last_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,\
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `mail_address` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `phone_number` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `function` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `mobile` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `memo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `zipcode` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `city` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `facebook_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `linkedin_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `twitter_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `contacts`\
--\
\
INSERT INTO `contacts` (`id`, `company_id`, `first_name`, `middle_name`, `last_name`, `image`, `mail_address`, `phone_number`, `address`, `function`, `mobile`, `memo`, `zipcode`, `city`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES\
(3, 1, 'Dirk Jan', '', 'Durieux', NULL, 'dirkjan@durieux.nl', '06 15000630', 'Snelliuslaan 2', '', '', '', '8024XE', 'Zwolle', '', 'linkedin.com/durieux', '', NULL, NULL, '2014-12-16 13:22:03', '2015-01-21 07:17:28'),\
(4, 6, 'Mathyn', '', 'Buiteveld', NULL, 'mathyn@movinsoftware.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2015-02-05 19:58:07', '2016-05-16 08:40:10'),\
(5, 7, 'Maarten', '', 'Kuiper', NULL, 'mail@maartenkuiper.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2015-02-05 19:58:28', '2015-02-05 19:58:28'),\
(6, 8, 'Jeroen', '', 'Doornbos', NULL, 'jeroen@sco-re.nl', '', '', '', '', '', '', 'Zwolle', '', '', '', 15, NULL, '2015-02-11 15:12:50', '2015-05-05 17:12:51'),\
(7, 9, 'Dirk Jan', '', 'Durieux', NULL, 'dirkjan@durieux.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2015-02-11 17:44:38', '2015-02-11 17:44:38'),\
(8, 10, 'Tim', '', 'Vogt', NULL, 'tim@newweb.co', '06-49196922', 'Molendwarsstraat 19', '', '', '', '8012TR', 'Zwolle', '', '', '', 15, NULL, '2015-02-17 11:24:28', '2015-02-17 11:24:28'),\
(9, 11, 'Lydia', '', 'Lijkendijk', NULL, 'info@lijkendijk.com', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2015-02-17 12:15:15', '2015-02-17 12:15:15'),\
(17, 17, 'Arjan', '', 'Yspeert', NULL, 'yspeert@gmail.com', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2015-08-05 10:48:08', '2015-08-05 10:48:08'),\
(19, 22, 'Liedewij', '', 'de Graaf', NULL, 'liedewij@ikcirculeer.nl', '06-53838257', '', '', '', '', '', '', '', '', '', 15, 15, '2015-09-24 13:08:31', '2015-09-24 13:17:54'),\
(22, 25, 'Ronald ', '', 'Rienties', NULL, 'RonaldRienties@xs4all.nl', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-11-24 09:40:16', '2015-11-24 09:41:24'),\
(23, 25, 'Liesbeth', '', 'Kasperink', NULL, 'liesbethkasperink@hotmail.com', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-11-24 09:43:47', '2015-11-24 09:43:47'),\
(26, 26, 'Petro', '', 'Vosselman', NULL, 'PVosselman@deloitte.nl', '(0)88 288 0996 ', '06 5204 8357', '', '', '', '', '', '', '', '', 15, NULL, '2015-12-04 12:38:40', '2015-12-04 12:38:40'),\
(32, 31, 'Maaike', '', 'Schievink', NULL, 'm.schievink@isala-academie.nl', '038  424 62 20', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-10 12:45:04', '2015-12-17 13:27:09'),\
(33, 32, 'Marcella', '', 'Rijkschroeff', NULL, '', '', 'Hoofd HRM', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-10 13:11:26', '2015-12-10 13:11:26'),\
(34, 33, 'Margot', '', 'Vrieswijk', NULL, '', '088 4699411', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-10 13:51:40', '2015-12-14 09:22:58'),\
(37, 33, 'Francien', '', 'Lange', NULL, 'f.lange@windesheim.nl', '088-4698489    ', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-11 10:46:43', '2015-12-11 10:46:43'),\
(38, 35, 'John', '', 'de Vlieger', NULL, 'john@lovetofund.com', '06 10 92 31 21', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-11 11:55:23', '2015-12-11 11:57:28'),\
(39, 35, 'Rudy', '', 'den Butter', NULL, 'rudy@lovetofund.com', '0650272274', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-11 11:56:28', '2015-12-11 11:56:28'),\
(40, 33, 'Mira', '', 'Bloemen-Bekx', NULL, 'wmjm.bloemen-bekx@windesheim.nl', '088 469 86 53', 'hogeschoolhoofddocent opleiding Small Bu', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-11 12:13:05', '2015-12-11 12:13:05'),\
(41, 32, 'Bianca', '', 'Meekers', NULL, '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-15 12:26:39', '2015-12-15 12:26:39'),\
(42, 36, 'Jan', '', 'Plender', NULL, 'jan.plender@nl.abnamro.com', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-18 11:39:58', '2015-12-18 11:39:58'),\
(43, 36, 'Gera', '', 'Pleysier', NULL, 'gera.pleysier@nl.abnamro.com', 'Klein zakelijk ', '', '', '', '', '', '', '', '', '', NULL, NULL, '2015-12-18 11:40:56', '2015-12-18 11:40:56'),\
(45, 37, 'Arjan ', '', 'van der Zee', NULL, 'arjan@pickthisup.nl', '0630116192', '', '', '', '', '', '', '', '', '', 15, 15, '2015-12-30 07:23:58', '2015-12-30 07:24:47'),\
(46, 39, 'Anne-Jur', '', 'Borg', NULL, 'aborg@deltion.nl', '(0) 38 853 4134', NULL, 'Ondernemerschap ', '(0) 6 13 94 62 41', 'Gebouw Geel, kamer 3.033', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-07 13:13:24', '2016-01-07 13:13:24'),\
(49, 42, 'De financi\'eble', '', 'administratie', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2016-01-15 11:23:37', '2016-01-15 11:23:37'),\
(50, 43, 'Robin', '', 'Fr\'f6lich', NULL, 'robin.frolich@senzinterim.nl', '', NULL, 'eigenaar', '+31 611198132', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-19 09:00:12', '2016-01-19 09:00:12'),\
(51, 44, 'Ted', '', 'Stravers', NULL, 'tedstravers@gmail.com', '', NULL, 'Managing Partner', '+31 6 24 92 27 93', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-20 14:35:12', '2016-01-20 14:35:12'),\
(52, 44, 'Marjan', '', 'Lambalgen', NULL, '', '', NULL, 'Manageing Partner', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-20 14:36:45', '2016-01-20 14:36:45'),\
(53, 45, 'Eric', '', 'Moen', NULL, 'ericmoen@ijsselvliet.nl', '+ 31 38 444 96 ', NULL, 'Partner', '+ 31 6 433 788 16', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-21 11:46:47', '2016-01-22 08:51:15'),\
(54, 45, 'Anteun', '', 'Braakman ', NULL, 'anteunbraakman@ijsselvliet.nl', '038 4449671', NULL, 'HR-adviseur', '0650899599', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-22 08:52:33', '2016-05-27 17:50:45'),\
(55, 46, 'Rik', '', 'van \\'t Klooster', NULL, 'info@rikkl.nl', '', NULL, '', '06 344 72 180', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-22 10:07:31', '2016-01-22 10:07:31'),\
(56, 47, 'Kevin', '', 'Mepschen', NULL, 'info@mepschenbouw.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2016-02-02 12:44:15', '2016-02-02 12:44:15'),\
(57, 48, 'Ad', '', 'Verborgt', NULL, '', '', NULL, 'DiIrecteur', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-02-04 17:50:55', '2016-02-04 17:50:55'),\
(58, 49, 'Walter', '', 'Groen', NULL, 'walter.groen@fundatis.nl', '0634488848', '', '', '', '', '', '', '', '', '', 15, NULL, '2016-03-04 14:54:29', '2016-03-04 14:54:29'),\
(59, 38, 'Anne-Jur ', '', 'Borg', NULL, '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-05-10 04:22:58', '2016-05-10 04:22:58'),\
(61, 50, 'Lucas', '', 'Vos', NULL, 'lucas@lucrasoft.nl', '0646297351', '', '', '', '', '', '', '', '', '', 15, NULL, '2016-05-30 18:07:35', '2016-05-30 18:07:35'),\
(62, 51, 'T.a.v.', '', 'de financi\'eble administratie', NULL, 'finadmin@Jenrick.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2016-07-01 06:53:38', '2016-07-01 06:53:38'),\
(63, 52, 'Erik', '', 'Jansen', NULL, 'e.jansen@inprincipo.nl', '', NULL, 'Eigenaar', '+31 6-15873249', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-09-12 12:52:16', '2016-09-12 12:52:16'),\
(64, 53, 'Erik', '', 'Wellner', NULL, 'wellner@xs4all.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2017-12-08 09:13:42', '2017-12-08 09:13:42'),\
(65, 54, ' Jeroen ', 'van ', 'Helden', NULL, 'jeroen.van.helden@myler.nl', '06-40412058', '', '', '', '', '', '', '', '', '', 15, NULL, '2018-04-05 13:24:28', '2018-04-05 13:24:28'),\
(66, 54, 'T.a.v.', '', ' de financi\'eble administratie', NULL, 'facturen@myler.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2018-04-05 13:27:17', '2018-04-05 13:27:17'),\
(67, 20, 'T.a.v. de', '', 'crediteurenadministratie', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, 15, '2018-09-21 06:46:12', '2018-09-21 06:50:35'),\
(68, 20, 'T.a.v. ', '', 'digitaleinkoopfacturen@windesheim.nl', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, 15, '2018-10-15 14:43:21', '2018-10-15 14:46:42'),\
(69, 49, 'Anne Floor', '', 'Erdman', NULL, 'annefloor.erdman@fundatis.nl', '0620421539', '', '', '', '', '', '', '', '', '', 15, NULL, '2018-11-02 09:08:40', '2018-11-02 09:08:40'),\
(70, 55, 'Saskia', '', 'de Munnik', NULL, 'saskia@devliegendeonderzoeker.nl', '+31641501699', '', '', '', '', '', '', '', '', '', 15, NULL, '2019-01-06 09:39:53', '2019-01-06 09:39:53'),\
(71, 56, 'T.a.v.', '', 'de financi\'eble administratie', NULL, 'facturen@hu.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2019-04-05 09:30:11', '2019-04-05 09:30:11'),\
(72, 57, 'T.a.v.', '', 'Financi\'eble administratie', NULL, 'facturatie@headfirst.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2019-09-02 06:58:26', '2019-09-02 06:58:26'),\
(73, 20, 'T.a.v.', '', 'WH Crediteurenadministratie', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2019-10-02 15:55:28', '2019-10-02 15:55:28'),\
(74, 58, 'T.a.v.', '', 'Factuurverwerking', NULL, 'factuuradministratie@tue.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2019-11-04 14:35:39', '2019-11-04 14:35:39'),\
(75, 59, 'T.a.v.', '', 'factuurverwerking', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2020-02-02 09:23:07', '2020-02-02 09:23:07'),\
(76, 60, 'Anne ', '', 'van Velden', NULL, 'annePapillon@hotmail.com', '+31 6 10537966', '', '', '', '', '', '', '', '', '', 15, NULL, '2020-02-29 08:14:10', '2020-02-29 08:14:10'),\
(77, 61, 'p/a ', '', 'SSC Finance', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2020-05-03 05:25:00', '2020-05-03 05:25:00'),\
(79, 63, 'Bestuursbureau/bedrijfsvoering ', '', 't.a.v. Financieel Shared Service Centre ', NULL, 'facturen@bb.leidenuniv.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2020-07-04 10:19:17', '2020-07-04 10:19:17'),\
(80, 64, 'CIS ', '', 't.a.v. Afdeling Crediteuren', NULL, 'facturen@cif.ru.nl', '', '', '', '', '', '', '', '', '', '', 15, 15, '2020-09-08 05:39:15', '2020-09-08 05:46:35'),\
(81, 65, 'T.a.v. de ', '', 'financi\'eble administratie. ', NULL, '', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2021-01-30 11:18:33', '2021-01-30 11:18:33'),\
(82, 66, 'Folkert', '', 'Hoogenstrijd', NULL, 'FolkertHoogenstrijd@gmail.com', '+31 6 26 49 48 ', '', '', '', '', '', '', '', '', '', 15, 15, '2021-03-09 10:55:03', '2021-03-09 10:56:26'),\
(83, 68, 'Directeur Centrum voor LLL en OI ', 'Mevrouw H.', 'Leeuw', NULL, 'hanke.leeuw@hku.nl', '', '', '', '', '', '', '', '', '', '', 15, 15, '2021-06-01 06:19:48', '2021-06-01 06:25:35'),\
(84, 69, 'T.a.v. ', '', 'Crediteurenadministratie', NULL, 'facturen@org.hanze.nl', '', '', '', '', '', '', '', '', '', '', 15, 15, '2021-06-06 03:25:02', '2021-06-06 03:29:00'),\
(85, 70, 'T.a.v.', '', 'de crediteurenadministratie', NULL, 'digifactuur@hva.nl', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2021-06-06 04:05:40', '2021-06-06 04:05:40'),\
(86, 71, 'Hans', '', 'Valkenburg', NULL, 'valkenburg.hans@gmail.com', '', '', '', '', '', '', '', '', '', '', 15, NULL, '2021-07-01 16:14:58', '2021-07-01 16:14:58'),\
(87, 42, 'Frank', '', 'Dekkers, Hoofd SSC a.i. ', NULL, 'frank.dekkers@hvhl.nl', '', '', '', '', '', '', '', '', '', '', 15, 15, '2021-07-01 17:16:35', '2021-07-01 17:26:23'),\
(88, 72, 'dummycontact', '', 'dummyachternaam', NULL, '', '', '', '', '', '', '', '', '', '', '', 77, NULL, '2021-08-20 07:52:00', '2021-08-20 07:52:00'),\
(89, 73, 'T.a.v.', '', 'de financiele administratie', NULL, '', '', '', '', '', '', '', '', '', '', '', 77, 77, '2021-10-15 13:02:14', '2021-10-16 05:27:12'),\
(90, 74, 't.a.v.', '', 'crediteurenadministratie', NULL, 'facturen@amc.uva.nl', '', '', '', '', '', '', '', '', '', '', 77, NULL, '2021-11-03 10:21:42', '2021-11-03 10:21:42'),\
(91, 75, 't.a.v. R.', '', 'Van Ouwerkerk', NULL, 'crediteuren@umcg.nl', '', '', '', '', '', '', '', '', '', '', 77, 77, '2021-12-03 12:40:53', '2021-12-03 12:43:15'),\
(92, 76, 'Dirk Jan', '', 'Durieux', NULL, 'dirkjan@durieux.nl', '', '', '', '', '', '', '', '', '', '', 77, NULL, '2021-12-14 06:58:36', '2021-12-14 06:58:36'),\
(93, 42, 'Hugo', 'van', 'Toor (manager facilitair en support)', NULL, 'hugo.vantoor@hvhl.nl', '', '', '', '', '', '', '', '', '', '', 77, NULL, '2022-01-05 11:34:41', '2022-01-05 11:34:41'),\
(94, 77, 'T.a.v.', '', 'Crediteurenadministratie', NULL, 'crediteuren@graafschapcollege.nl', '', '', '', '', '', '', '', '', '', '', 77, NULL, '2022-02-02 12:01:34', '2022-02-02 12:01:34');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `contexts`\
--\
\
CREATE TABLE `contexts` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) NOT NULL,\
  `icon_id` int(11) DEFAULT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `contexts`\
--\
\
INSERT INTO `contexts` (`id`, `name`, `icon_id`, `workspace_id`, `created_at`, `updated_at`, `updated_by`) VALUES\
(15, 'Bellen', NULL, 4, '2015-03-27 09:39:19', '0000-00-00 00:00:00', NULL),\
(16, 'Computer', NULL, 4, '2015-03-27 09:39:22', '0000-00-00 00:00:00', NULL),\
(17, 'In de stad', NULL, 4, '2015-03-27 09:39:27', '0000-00-00 00:00:00', NULL),\
(18, 'vergadering', NULL, 4, '2015-03-27 09:39:31', '0000-00-00 00:00:00', NULL),\
(19, 'Bespreeklijstje', NULL, 4, '2015-03-27 09:39:36', '0000-00-00 00:00:00', NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `conversations`\
--\
\
CREATE TABLE `conversations` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `workgroup_id` int(10) UNSIGNED NOT NULL,\
  `member_id` int(10) UNSIGNED DEFAULT NULL,\
  `comment` text COLLATE utf8_unicode_ci NOT NULL,\
  `image` text COLLATE utf8_unicode_ci,\
  `parent_conversation_id` int(10) UNSIGNED DEFAULT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `documents`\
--\
\
CREATE TABLE `documents` (\
  `id` int(11) NOT NULL,\
  `title` varchar(100) NOT NULL,\
  `project_id` int(11) UNSIGNED DEFAULT NULL,\
  `sequence` int(10) NOT NULL,\
  `is_completed` tinyint(1) NOT NULL,\
  `is_archive` tinyint(4) NOT NULL,\
  `library` tinyint(4) NOT NULL,\
  `workgroup_id` int(11) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `documents`\
--\
\
INSERT INTO `documents` (`id`, `title`, `project_id`, `sequence`, `is_completed`, `is_archive`, `library`, `workgroup_id`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES\
(7, ' .Wij zijn IncZwolle txt', NULL, 2, 1, 1, 0, 2, '2015-03-26 21:19:12', '2016-02-15 16:13:58', NULL, NULL),\
(8, 'huisstijl docs', NULL, 1, 0, 0, 0, 0, '2015-03-26 21:19:12', '2015-12-18 14:30:20', NULL, NULL),\
(11, 'Starterspakket', NULL, 4, 0, 0, 0, 0, '2015-04-19 19:21:26', '2015-12-18 14:30:28', NULL, NULL),\
(13, 'Pressure Cooker Week Documenten', NULL, 8, 0, 0, 0, 0, '2015-04-25 18:04:38', '2015-12-18 14:30:34', NULL, NULL),\
(29, 'Huiswerkopdracht ', NULL, 2, 0, 0, 0, 0, '2015-08-06 20:53:03', '2015-08-06 20:57:03', NULL, NULL),\
(35, 'Untitled', NULL, 7, 0, 1, 0, 1, '2015-09-30 13:00:13', '2016-05-09 06:44:48', NULL, NULL),\
(40, 'Untitled', NULL, 1, 0, 0, 0, 0, '2015-11-23 12:57:01', '2015-11-23 12:57:01', NULL, NULL),\
(42, 'Untitled', NULL, 3, 0, 0, 0, 0, '2015-12-15 10:01:03', '2015-12-15 10:01:03', NULL, NULL),\
(48, 'Un12345', NULL, 2, 0, 1, 1, 2, '2015-12-21 06:45:10', '2016-02-16 11:31:12', NULL, NULL),\
(50, 'Untitledd', NULL, 4, 0, 0, 0, 0, '2015-12-21 06:46:00', '2016-02-16 05:20:37', NULL, NULL),\
(51, 'Untitled', NULL, 5, 0, 0, 0, 0, '2015-12-21 06:46:00', '2015-12-21 06:46:00', NULL, NULL),\
(52, 'Untitled', NULL, 6, 0, 0, 0, 0, '2015-12-21 06:46:00', '2015-12-21 06:46:00', NULL, NULL),\
(53, 'Untitled', NULL, 0, 0, 1, 0, 2, '2016-01-06 10:58:22', '2016-04-25 05:37:05', NULL, NULL),\
(54, 'flyer startbaan', NULL, 0, 0, 1, 0, 2, '2016-01-06 11:55:40', '2016-06-01 18:52:32', NULL, NULL),\
(55, 'Untitled', NULL, 7, 0, 0, 0, 0, '2016-01-07 13:14:16', '2016-01-07 13:14:16', NULL, NULL),\
(58, 'Untitled', NULL, 8, 0, 0, 0, 0, '2016-01-13 13:20:35', '2016-01-13 13:20:35', NULL, NULL),\
(59, 'Untitled', NULL, 0, 0, 1, 0, 2, '2016-01-29 10:43:46', '2016-02-15 16:12:49', NULL, NULL),\
(60, 'Untitled', NULL, 0, 0, 1, 0, 2, '2016-02-02 07:40:48', '2016-05-16 09:57:28', NULL, NULL),\
(61, 'Test Edward', NULL, 0, 0, 1, 0, 2, '2016-02-06 06:50:42', '2016-05-16 09:58:27', NULL, NULL),\
(62, 'Test Edward 3', NULL, 0, 0, 0, 0, 0, '2016-02-06 07:13:08', '2016-07-28 06:29:24', NULL, NULL),\
(63, 'Arhived doc', NULL, 0, 0, 1, 0, 1, '2016-02-06 08:30:28', '2016-04-11 06:41:17', NULL, NULL),\
(64, 'Untitled', NULL, 9, 0, 0, 0, 0, '2016-02-06 09:53:03', '2016-02-06 09:53:03', NULL, NULL),\
(65, 'test', NULL, 0, 0, 1, 0, 2, '2016-02-06 10:47:37', '2016-05-16 11:44:15', NULL, NULL),\
(66, 'Untitled', NULL, 10, 0, 0, 0, 0, '2016-02-06 10:53:34', '2016-02-06 10:53:34', NULL, NULL),\
(67, 'Untitled', NULL, 11, 0, 0, 0, 0, '2016-02-06 10:54:45', '2016-02-06 10:54:45', NULL, NULL),\
(68, 'test123', NULL, 0, 0, 1, 0, 2, '2016-02-06 11:03:03', '2016-06-10 11:12:45', NULL, NULL),\
(71, 'Untitled123', NULL, 0, 0, 0, 0, 0, '2016-02-15 11:32:31', '2016-11-04 11:02:45', NULL, NULL),\
(72, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-03-29 15:21:04', '2016-03-29 15:21:04', NULL, NULL),\
(73, 'vu ketenplanning', NULL, 11, 0, 0, 0, 0, '2016-04-08 12:37:20', '2016-09-20 18:36:11', NULL, NULL),\
(74, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 07:21:16', '2016-04-25 07:21:16', NULL, NULL),\
(75, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 07:24:07', '2016-04-25 07:24:07', NULL, NULL),\
(76, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 07:43:08', '2016-04-25 07:43:08', NULL, NULL),\
(77, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 07:49:09', '2016-04-25 07:49:09', NULL, NULL),\
(78, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 07:51:30', '2016-04-25 07:51:30', NULL, NULL),\
(79, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 08:24:01', '2016-04-25 08:24:01', NULL, NULL),\
(80, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-04-25 08:35:04', '2016-04-25 08:35:04', NULL, NULL),\
(81, 'Untitled', NULL, 1, 0, 1, 0, 1, '2016-05-17 12:50:00', '2016-05-17 12:50:36', NULL, NULL),\
(82, 'Untitled', NULL, 2, 0, 1, 0, 1, '2016-05-18 06:45:37', '2016-05-18 06:46:08', NULL, NULL),\
(86, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 11:51:19', '2016-06-09 11:51:19', NULL, NULL),\
(87, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 11:53:13', '2016-06-09 11:53:13', NULL, NULL),\
(88, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 11:57:30', '2016-06-09 11:57:30', NULL, NULL),\
(89, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 12:00:33', '2016-06-09 12:00:33', NULL, NULL),\
(90, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 12:01:04', '2016-06-09 12:01:04', NULL, NULL),\
(91, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-09 12:54:01', '2016-06-09 12:54:01', NULL, NULL),\
(92, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-10 05:24:15', '2016-06-10 05:24:15', NULL, NULL),\
(93, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-10 06:38:50', '2016-06-10 06:38:50', NULL, NULL),\
(94, 'Untitled', NULL, 3, 0, 0, 0, 0, '2016-06-10 08:02:38', '2016-06-10 08:02:38', NULL, NULL),\
(95, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-10 08:03:11', '2016-06-10 08:03:11', NULL, NULL),\
(96, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-10 08:03:51', '2016-06-10 08:03:51', NULL, NULL),\
(97, 'Untitled', NULL, 0, 0, 0, 0, 0, '2016-06-10 11:23:32', '2016-06-10 11:23:32', NULL, NULL),\
(98, 'Untitled', NULL, 12, 0, 0, 0, 0, '2016-07-08 17:31:45', '2016-07-08 17:31:45', NULL, NULL),\
(99, 'Untitled copy', NULL, 4, 0, 0, 0, 0, '2016-06-09 12:00:33', '2016-06-09 12:00:33', NULL, NULL),\
(100, 'Untitled copy', NULL, 5, 0, 0, 0, 0, '2016-06-09 12:00:33', '2016-06-09 12:00:33', NULL, NULL),\
(101, 'Untitled copy', NULL, 6, 0, 0, 0, 0, '2016-06-09 12:00:33', '2016-06-09 12:00:33', NULL, NULL),\
(102, 'Test Edward 3 copy', NULL, 12, 0, 0, 0, 0, '2016-02-06 07:13:08', '2016-07-28 06:29:24', NULL, NULL),\
(105, 'Untitled', NULL, 13, 0, 0, 0, 0, '2016-09-16 05:37:04', '2016-09-16 05:37:04', NULL, NULL),\
(106, 'Untitled', NULL, 14, 0, 0, 0, 0, '2016-09-19 11:04:24', '2016-09-19 11:04:24', NULL, NULL),\
(107, 'Untitled', NULL, 15, 0, 0, 0, 0, '2016-09-19 11:30:29', '2016-09-19 11:30:29', NULL, NULL),\
(108, 'Untitled', NULL, 16, 0, 0, 0, 0, '2017-08-11 11:08:05', '2017-08-11 11:08:05', NULL, NULL),\
(109, 'Untitled', NULL, 17, 0, 0, 0, 0, '2017-08-11 11:09:33', '2017-08-11 11:09:33', NULL, NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `document_comments`\
--\
\
CREATE TABLE `document_comments` (\
  `id` int(11) NOT NULL,\
  `document_id` int(11) NOT NULL,\
  `comment` text NOT NULL,\
  `created_at` datetime NOT NULL,\
  `created_by` int(11) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `document_comments`\
--\
\
INSERT INTO `document_comments` (`id`, `document_id`, `comment`, `created_at`, `created_by`) VALUES\
(45, 8, 'comment', '2015-03-26 21:20:21', NULL),\
(46, 8, 'comment2', '2015-03-26 21:20:30', NULL),\
(47, 13, 'Alle documenten van de Pressure Cooker week november 2013 tijdens de GEW', '2015-04-25 18:06:16', NULL),\
(51, 53, 'test', '2016-01-21 10:36:44', NULL),\
(52, 62, 'dsdsddsdfs', '2016-07-28 06:28:00', NULL),\
(53, 62, 'dsadsdsads', '2016-09-19 04:55:04', NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `document_files`\
--\
\
CREATE TABLE `document_files` (\
  `id` int(11) NOT NULL,\
  `document_id` int(11) DEFAULT NULL,\
  `name` varchar(100) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `document_files`\
--\
\
INSERT INTO `document_files` (`id`, `document_id`, `name`, `created_at`, `updated_at`, `updated_by`) VALUES\
(19, 7, 'Wij_zijn_IncZwolle_A0.pdf', '2015-03-26 21:19:12', '2015-03-26 21:19:12', NULL),\
(20, 8, 'Wij_zijn_IncZwolle_A0.pdf', '2015-03-26 21:19:12', '2015-03-26 21:19:12', NULL),\
(21, 8, 'search_.png', '2015-03-26 21:20:03', '2015-03-26 21:20:03', NULL),\
(22, 8, 'IncZwolle_uitnodiging_19_nov.pdf', '2015-03-26 21:20:14', '2015-03-26 21:20:14', NULL),\
(32, 11, 'Starterspakket.docx', '2015-04-19 19:21:26', '2015-04-19 19:21:26', NULL),\
(35, 13, 'Pressure Cooker Van idee tot onderneming in een week.docx', '2015-04-25 18:04:38', '2015-04-25 18:04:38', NULL),\
(36, 13, 'Kickoff_pressure_cooker.pptx', '2015-04-25 18:05:08', '2015-04-25 18:05:08', NULL),\
(37, 13, 'DISC test.xlsx', '2015-04-25 18:05:16', '2015-04-25 18:05:16', NULL),\
(38, 13, 'Concept_tekst_pressure-cooker-week.docx', '2015-04-25 18:05:43', '2015-04-25 18:05:43', NULL),\
(39, 13, 'presentsatie landstede.pdf', '2015-04-25 18:05:43', '2015-04-25 18:05:43', NULL),\
(56, 29, 'Theorie_opdracht_ws1.pdf', '2015-08-06 20:53:03', '2015-08-06 20:53:03', NULL),\
(58, 29, 'invulformat_huiswerk_ws_1.docx', '2015-08-06 20:57:14', '2015-08-06 20:57:14', NULL),\
(63, 35, 'gespreksonderwerp Cor de Koning.docx', '2015-09-30 13:00:13', '2015-09-30 13:00:13', NULL),\
(68, 40, '/images.jpg', '2015-11-23 12:57:01', '2015-11-23 12:57:01', NULL),\
(70, 42, '/Business Plan KADCO_final.pdf', '2015-12-15 10:01:03', '2015-12-15 10:01:03', NULL),\
(90, 50, '/Schermafbeelding 2015-12-21 om 07.34.49.png', '2015-12-21 06:46:00', '2015-12-21 06:46:00', NULL),\
(91, 51, '/Schermafbeelding 2015-12-21 om 07.34.55.png', '2015-12-21 06:46:00', '2015-12-21 06:46:00', NULL),\
(92, 52, '/Schermafbeelding 2015-12-21 om 07.34.53.png', '2015-12-21 06:46:00', '2015-12-21 06:46:00', NULL),\
(93, 53, '/72dpi (3).jpg', '2016-01-06 10:58:24', '2016-01-06 10:58:24', NULL),\
(94, 54, '/flyer_info_startbaan.docx', '2016-01-06 11:55:42', '2016-01-06 11:55:42', NULL),\
(95, 55, '/72dpi (4).jpg', '2016-01-07 13:14:16', '2016-01-07 13:14:16', NULL),\
(97, 48, '/2016-01-13_0708.png', '2016-01-13 06:11:46', '2016-01-13 06:11:46', NULL),\
(102, 58, '/300dpi (3).jpg', '2016-01-13 13:20:35', '2016-01-13 13:20:35', NULL),\
(103, 59, '/SignAdiba.tiff', '2016-01-29 10:43:50', '2016-01-29 10:43:50', NULL),\
(105, 60, '/300dpi (8).jpg', '2016-02-02 07:40:53', '2016-02-02 07:40:53', NULL),\
(106, 62, 'Email_03-04-2015_RaviSharm.pdf', '2016-02-06 07:13:11', '2016-02-06 07:13:11', NULL),\
(107, 64, '/72dpi (7).jpg', '2016-02-06 09:53:03', '2016-02-06 09:53:03', NULL),\
(108, 65, '/300dpi (10).jpg', '2016-02-06 10:47:41', '2016-02-06 10:47:41', NULL),\
(109, 65, '/72dpi (9).jpg', '2016-02-06 10:47:41', '2016-02-06 10:47:41', NULL),\
(110, 66, '/300dpi (11).jpg', '2016-02-06 10:53:34', '2016-02-06 10:53:34', NULL),\
(111, 67, '/300dpi (12).jpg', '2016-02-06 10:54:45', '2016-02-06 10:54:45', NULL),\
(112, 68, '/300dpi (13).jpg', '2016-02-06 11:03:05', '2016-02-06 11:03:05', NULL),\
(113, 68, '/Email_09-04-2015_RaviSharm.pdf', '2016-02-06 11:03:08', '2016-02-06 11:03:08', NULL),\
(114, 71, '/Email_09-04-2015_RaviSharm (1).pdf', '2016-02-15 11:32:33', '2016-02-15 11:32:33', NULL),\
(115, 72, '/image002.png', '2016-03-29 15:21:08', '2016-03-29 15:21:08', NULL),\
(116, 72, '/image003.png', '2016-03-29 15:21:08', '2016-03-29 15:21:08', NULL),\
(117, 72, '/Email_10-02-2016_TestMan.pdf', '2016-03-29 15:21:11', '2016-03-29 15:21:11', NULL),\
(118, 73, '/4.1.1 Ketenplanning_roosteren_1617_v0 6.pdf', '2016-04-08 12:37:20', '2016-04-08 12:37:20', NULL),\
(119, 79, '/Email_25-04-2016_RaviSharm (6).pdf', '2016-04-25 08:24:04', '2016-04-25 08:24:04', NULL),\
(120, 80, '/Email_25-04-2016_RaviSharm (7).pdf', '2016-04-25 08:35:06', '2016-04-25 08:35:06', NULL),\
(121, 81, '/72dpi (10).jpg', '2016-05-17 12:50:00', '2016-05-17 12:50:00', NULL),\
(122, 82, '/72dpi (11).jpg', '2016-05-18 06:45:37', '2016-05-18 06:45:37', NULL),\
(130, 86, '/Email_24-05-2016_RaviSharm.pdf', '2016-06-09 11:51:22', '2016-06-09 11:51:22', NULL),\
(131, 87, '/Email_24-05-2016_RaviSharm (1).pdf', '2016-06-09 11:53:16', '2016-06-09 11:53:16', NULL),\
(132, 94, '/72dpi (12).jpg', '2016-06-10 08:02:38', '2016-06-10 08:02:38', NULL),\
(133, 97, '/1405318735-workshop_temlate.pdf', '2016-06-10 11:23:37', '2016-06-10 11:23:37', NULL),\
(134, 97, '/images (2).jpg', '2016-06-10 11:23:37', '2016-06-10 11:23:37', NULL),\
(135, 97, '/Email_22-09-2015_pratikpatel.pdf', '2016-06-10 11:23:39', '2016-06-10 11:23:39', NULL),\
(137, 98, '/16111 Vacature_SOZ_OKP_Projectmedewerker _ Data Analist.docx', '2016-07-08 17:31:45', '2016-07-08 17:31:45', NULL),\
(138, 73, '/Tentamens minder aangevraagd dan vorige jaar.docx', '2016-07-08 17:32:14', '2016-07-08 17:32:14', NULL),\
(139, 102, 'Email_03-04-2015_RaviSharm.pdf', '2016-02-06 07:13:11', '2016-02-06 07:13:11', NULL),\
(143, 105, '/ravi@devrepublic.nl/1474004220-300dpi.jpg', '2016-09-16 05:37:04', '2016-09-16 05:37:04', NULL),\
(144, 62, '/ravi@devrepublic.nl/1474260660-2016-09-19_0636.png', '2016-09-19 04:51:04', '2016-09-19 04:51:04', NULL),\
(145, 106, '/testwith date/1474283061-shanghai01.jpg', '2016-09-19 11:04:44', '2016-09-19 11:04:44', NULL),\
(146, 107, '/ravi@devrepublic.nl/1474284626-shanghai.JPG', '2016-09-19 11:30:29', '2016-09-19 11:30:29', NULL),\
(147, 8, '/dirkjan75@gmail.com/1477041937-white_shirt.png', '2016-10-21 09:25:41', '2016-10-21 09:25:41', NULL),\
(149, 74, '/ravi@devrepublic.nl/1481093906-shape-2.jpg', '2016-12-07 06:58:29', '2016-12-07 06:58:29', NULL),\
(150, 108, '/ravi@devrepublic.nl/1502449682-7 2 dpi.jpg', '2017-08-11 11:08:05', '2017-08-11 11:08:05', NULL),\
(151, 109, '/ravi@devrepublic.nl/1502449772-7 2 dpi.jpg', '2017-08-11 11:09:33', '2017-08-11 11:09:33', NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `events`\
--\
\
CREATE TABLE `events` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,\
  `description` text COLLATE utf8_unicode_ci,\
  `min_participants` int(11) NOT NULL,\
  `max_participants` int(11) NOT NULL,\
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `image_thumb` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `kind` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `event_days`\
--\
\
CREATE TABLE `event_days` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `event_id` int(10) UNSIGNED NOT NULL,\
  `date` date NOT NULL,\
  `time_from` time NOT NULL,\
  `time_to` time NOT NULL,\
  `location` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `address` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `zipcode` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `city` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `remarks` text COLLATE utf8_unicode_ci NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `event_day_modules`\
--\
\
CREATE TABLE `event_day_modules` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `event_id` int(10) UNSIGNED NOT NULL,\
  `event_day_id` int(11) UNSIGNED NOT NULL,\
  `title` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `time_from` time NOT NULL,\
  `time_to` time NOT NULL,\
  `description` text COLLATE utf8_unicode_ci NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `event_registrations`\
--\
\
CREATE TABLE `event_registrations` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `event_id` int(10) UNSIGNED NOT NULL,\
  `member_id` int(10) UNSIGNED NOT NULL,\
  `date` date NOT NULL,\
  `status` char(1) NOT NULL,\
  `created_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `event_workgroups`\
--\
\
CREATE TABLE `event_workgroups` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `event_id` int(10) UNSIGNED NOT NULL,\
  `workgroup_id` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `galleries`\
--\
\
CREATE TABLE `galleries` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,\
  `description` text COLLATE utf8_unicode_ci,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `galleries`\
--\
\
INSERT INTO `galleries` (`id`, `name`, `description`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES\
(1, 'Gallery 1', NULL, 2, NULL, '2014-12-17 06:33:10', '2014-12-17 06:33:10'),\
(2, 'Gallery 2', NULL, NULL, NULL, '2014-12-17 11:18:12', '2014-12-17 11:18:12');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `general_settings`\
--\
\
CREATE TABLE `general_settings` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `admin_mail` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `dropbox_access` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `dropbox_app` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `twitter_tag` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `linkedIn_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `facebook_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `twitter_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `tax` float(5,2) NOT NULL,\
  `invoice_upper_margin` int(10) NOT NULL,\
  `invoice_bottom_margin` int(10) NOT NULL,\
  `invoice_left_margin` int(10) NOT NULL,\
  `invoice_right_margin` int(10) NOT NULL,\
  `invoice_bottom_text` text COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_payment_term` int(10) NOT NULL,\
  `invoice_mistral_template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_mistral_tax` int(11) NOT NULL,\
  `invoice_mistral_upper_margin` int(11) NOT NULL,\
  `invoice_mistral_bottom_margin` int(11) NOT NULL,\
  `invoice_mistral_left_margin` int(11) NOT NULL,\
  `invoice_mistral_right_margin` int(11) NOT NULL,\
  `invoice_mistral_invoice_text` text COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_mistral_payment_term` int(11) NOT NULL,\
  `invoice_new_template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_new_tax` int(11) NOT NULL,\
  `invoice_new_upper_margin` int(11) NOT NULL,\
  `invoice_new_bottom_margin` int(11) NOT NULL,\
  `invoice_new_left_margin` int(11) NOT NULL,\
  `invoice_new_right_margin` int(11) NOT NULL,\
  `invoice_new_invoice_text` text COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_new_payment_term` int(11) NOT NULL,\
  `default_no_row` int(10) NOT NULL,\
  `color_context_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_project_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_area_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `menu_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `menu_font_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `priority_icon_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `inactive_priority_icon_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `filter_clicked_btn_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `counter_bedge_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL,\
  `color_filter` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_sub_texts` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `default_picture` longtext COLLATE utf8_unicode_ci NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `general_settings`\
--\
\
INSERT INTO `general_settings` (`id`, `admin_mail`, `dropbox_access`, `dropbox_app`, `twitter_tag`, `linkedIn_url`, `facebook_url`, `twitter_url`, `invoice_template`, `tax`, `invoice_upper_margin`, `invoice_bottom_margin`, `invoice_left_margin`, `invoice_right_margin`, `invoice_bottom_text`, `invoice_payment_term`, `invoice_mistral_template`, `invoice_mistral_tax`, `invoice_mistral_upper_margin`, `invoice_mistral_bottom_margin`, `invoice_mistral_left_margin`, `invoice_mistral_right_margin`, `invoice_mistral_invoice_text`, `invoice_mistral_payment_term`, `invoice_new_template`, `invoice_new_tax`, `invoice_new_upper_margin`, `invoice_new_bottom_margin`, `invoice_new_left_margin`, `invoice_new_right_margin`, `invoice_new_invoice_text`, `invoice_new_payment_term`, `default_no_row`, `color_context_btn`, `color_project_btn`, `color_area_btn`, `menu_color`, `menu_font_color`, `priority_icon_color`, `inactive_priority_icon_color`, `filter_clicked_btn_color`, `counter_bedge_color`, `color_filter`, `color_sub_texts`, `default_picture`, `updated_by`, `updated_at`) VALUES\
(1, 'info@inczwolle.nl', '5XgRSs-R_nAAAAAAAAAAVXiEIjukdb0CosOcnoQLGTfYegPP-KPQZpLnIWxMya77', 'Inczwolle-Live', '#inczwolle', 'http://google.com', 'https://www.facebook.com/inczwolle', 'https://twitter.com/inczwolle', 'invoice_01122017_144757.pdf', 21.00, 55, 0, 20, 0, 'Wilt u het bedrag voor de vervaldatum overmaken op NL46ABNA0467974195. Dank!', 28, 'invoice_28072021_065552.pdf', 21, 55, 0, 20, 0, 'Wilt u het bedrag voor de vervaldatum overmaken op NL44ABNA 0468 0292 30. Dank!', 28, 'invoice_09092021_123004.pdf', 21, 55, 0, 20, 0, 'Wilt u het bedrag voor de vervaldatum overmaken op NL98ABNA0102971862. Dank!', 28, 99999999, '#ef8e08', '#4e6de3', '#EC887B', '#000000', '#ffffff', '#f7c041', '#eeeeee', '#6dd8dd', '#9e9e9e', '#E9ECF3', '#bdb5b5', '1e6ae4ada992769567b71815f124fac5.jpg', 77, '0000-00-00 00:00:00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `general_settings_old`\
--\
\
CREATE TABLE `general_settings_old` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `admin_mail` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `dropbox_access` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `dropbox_app` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `twitter_tag` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `linkedIn_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `facebook_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `twitter_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `tax` float(5,2) NOT NULL,\
  `invoice_upper_margin` int(10) NOT NULL,\
  `invoice_bottom_margin` int(10) NOT NULL,\
  `invoice_left_margin` int(10) NOT NULL,\
  `invoice_right_margin` int(10) NOT NULL,\
  `invoice_bottom_text` text COLLATE utf8_unicode_ci NOT NULL,\
  `invoice_payment_term` int(10) NOT NULL,\
  `default_no_row` int(10) NOT NULL,\
  `color_context_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_project_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_area_btn` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `menu_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `menu_font_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `priority_icon_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `inactive_priority_icon_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `filter_clicked_btn_color` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `counter_bedge_color` varchar(20) COLLATE utf8_unicode_ci NOT NULL,\
  `color_filter` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `color_sub_texts` varchar(10) COLLATE utf8_unicode_ci NOT NULL,\
  `default_picture` longtext COLLATE utf8_unicode_ci NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `general_settings_old`\
--\
\
INSERT INTO `general_settings_old` (`id`, `admin_mail`, `dropbox_access`, `dropbox_app`, `twitter_tag`, `linkedIn_url`, `facebook_url`, `twitter_url`, `invoice_template`, `tax`, `invoice_upper_margin`, `invoice_bottom_margin`, `invoice_left_margin`, `invoice_right_margin`, `invoice_bottom_text`, `invoice_payment_term`, `default_no_row`, `color_context_btn`, `color_project_btn`, `color_area_btn`, `menu_color`, `menu_font_color`, `priority_icon_color`, `inactive_priority_icon_color`, `filter_clicked_btn_color`, `counter_bedge_color`, `color_filter`, `color_sub_texts`, `default_picture`, `updated_by`, `updated_at`) VALUES\
(1, 'info@inczwolle.nl', '5XgRSs-R_nAAAAAAAAAAVXiEIjukdb0CosOcnoQLGTfYegPP-KPQZpLnIWxMya77', 'Inczwolle-Live', '#inczwolle', 'http://google.com', 'https://www.facebook.com/inczwolle', 'https://twitter.com/inczwolle', 'invoice_01122017_144757.pdf', 21.00, 55, 0, 20, 0, 'Wilt u het bedrag voor de vervaldatum overmaken op NL46ABNA0467974195. Dank!', 28, 99999999, '#ef8e08', '#4e6de3', '#EC887B', '#000000', '#ffffff', '#f7c041', '#eeeeee', '#6dd8dd', '#9e9e9e', '#E9ECF3', '#bdb5b5', '7c6acdbdc0dcfd232769702fd70749f7.png', 15, '0000-00-00 00:00:00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `groups`\
--\
\
CREATE TABLE `groups` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `permissions` text COLLATE utf8_unicode_ci,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `groups`\
--\
\
INSERT INTO `groups` (`id`, `name`, `permissions`, `created_at`, `updated_at`) VALUES\
(1, 'default.admin', '', '2014-12-06 05:53:50', '2014-12-06 05:53:50'),\
(2, 'default.member', '', '2014-12-06 05:53:50', '2014-12-06 05:53:50'),\
(3, 'Conversations', '\{\\"manage_user_profile\\":1,\\"workgroup_conversation\\":1,\\"workgroup_event\\":1,\\"workspace\\":1,\\"workgroup_members\\":1\}', '2014-12-19 06:03:44', '2015-11-25 17:20:49'),\
(4, 'Full ', '\{\\"workgroup_projects\\":1,\\"manage_user_profile\\":1,\\"workgroup_companies_contacts\\":1,\\"workgroup_members\\":1,\\"workgroup_tasks\\":1,\\"workgroup_inbox\\":1,\\"workgroup_lists\\":1,\\"workgroup_library\\":1,\\"workgroup_archive\\":1\}', '2015-01-22 07:17:47', '2017-05-01 03:56:47');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `groups_list`\
--\
\
CREATE TABLE `groups_list` (\
  `id` int(11) UNSIGNED NOT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `name` varchar(100) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `icons`\
--\
\
CREATE TABLE `icons` (\
  `id` int(11) NOT NULL,\
  `name` varchar(60) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `icons`\
--\
\
INSERT INTO `icons` (`id`, `name`) VALUES\
(2, 'fa-male'),\
(3, 'fa-file'),\
(5, 'fa-copy'),\
(6, 'fa-desktop'),\
(7, 'fa-pause '),\
(8, 'fa-phone'),\
(9, 'fa-shopping-cart'),\
(11, 'fa-gavel'),\
(13, 'fa-credit-card'),\
(15, 'fa-money '),\
(16, 'fa-home'),\
(17, 'fa-stethoscope '),\
(18, 'fa-female'),\
(19, 'fa-cart-plus'),\
(20, 'fa-coffee'),\
(21, 'fa-cogs'),\
(22, 'fa-calendar'),\
(23, 'fa-binoculars '),\
(24, '           fa-archive'),\
(25, 'fa-camera'),\
(26, 'fa-child '),\
(27, 'fa-tachometer'),\
(28, 'fa-birthday-cake'),\
(29, 'fa-book'),\
(30, 'fa-briefcase'),\
(31, 'fa-clock-o'),\
(32, 'fa-envelope-o '),\
(34, 'fa-user-plus '),\
(35, 'fa-search-plus'),\
(37, 'fa-calendar-plus-o'),\
(38, 'fa-map-pin'),\
(39, 'fa-check-circle'),\
(40, 'fa-exclamation-circle'),\
(41, 'fa-check-square'),\
(42, 'fa-square-o'),\
(43, 'fa-square'),\
(44, 'fa-calendar-times-x'),\
(45, 'fa-inbox');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `images`\
--\
\
CREATE TABLE `images` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `gallery_id` int(10) UNSIGNED NOT NULL,\
  `path` varchar(100) COLLATE utf8_unicode_ci NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `images`\
--\
\
INSERT INTO `images` (`id`, `gallery_id`, `path`) VALUES\
(1, 1, 'add_event_day_20141217_121752.png'),\
(2, 2, 'Edit member_20141217_121829.png'),\
(3, 2, 'edit_page - Copy_20141217_121832.png'),\
(4, 1, 'Edit Contact_20141217_122042.png'),\
(5, 1, 'Masterclass_apri_2014_20150220_182641.jpg');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `inbox_mail`\
--\
\
CREATE TABLE `inbox_mail` (\
  `id` int(11) UNSIGNED NOT NULL,\
  `user_id` int(10) UNSIGNED NOT NULL,\
  `UID` varchar(200) NOT NULL,\
  `from_email` varchar(100) NOT NULL,\
  `subject` text NOT NULL,\
  `message` text NOT NULL,\
  `attachments` text NOT NULL,\
  `created_at` datetime NOT NULL,\
  `received_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `inbox_mail`\
--\
\
INSERT INTO `inbox_mail` (`id`, `user_id`, `UID`, `from_email`, `subject`, `message`, `attachments`, `created_at`, `received_at`) VALUES\
(1, 2, '6992', 'jaykesh@devrepublic.nl', 'inczwolle-task', 'hi task\\r\\n\\r\\nadded newksdjf;\\r\\nsdklfjkl\\r\\n', '', '0000-00-00 00:00:00', '2015-07-30 08:01:20'),\
(3, 28, '6995', 'pratik@devrepublic.nl', 'Inczwolle - Task', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>Hi</p>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-30 09:32:39'),\
(4, 2, '7017', 'ravi@devrepublic.nl', 'inczwolle - task1 mail', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>task mail from my bod</p>\\r\\n<div>&nbsp;</div>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-31 11:56:26'),\
(5, 2, '7018', 'ravi@devrepublic.nl', 'inczwolle - task 2', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>this is tasks 2</p>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-31 12:07:24'),\
(6, 3, '7019', 'ravi@devrepublic.nl', 'inczwolle - task 1', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>this is task 1</p>\\r\\n<div>&nbsp;</div>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-31 12:19:28'),\
(7, 3, '7020', 'ravi@devrepublic.nl', 'inczwolle- task 2', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>this task 2</p>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-31 12:19:56'),\
(8, 3, '2', 'ravi@devrepublic.nl', 'Need help', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>Hi i need help to read mail from tasks@inczwolle.nl</p>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', '', '0000-00-00 00:00:00', '2015-07-31 13:19:01'),\
(9, 3, '3', 'ravi@devrepublic.nl', 'inczwolle tasks', '<!DOCTYPE html PUBLIC \\"-//W3C//DTD XHTML 1.0 Transitional//EN\\">\\r\\n<html><body>\\r\\n<p>hi&nbsp;</p>\\r\\n<p>with attachment tasks</p>\\r\\n<p>&nbsp;</p>\\r\\n<p>Thanks</p>\\r\\n<div>&nbsp;</div>\\r\\n</body></html>\\r\\n', 'a:4:\{i:0;a:4:\{s:4:\\"name\\";s:16:\\"Gino-Wouters.jpg\\";s:4:\\"path\\";s:16:\\"Gino-Wouters.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}i:1;a:4:\{s:4:\\"name\\";s:12:\\"IMG_5031.JPG\\";s:4:\\"path\\";s:12:\\"IMG_5031.JPG\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}i:2;a:4:\{s:4:\\"name\\";s:26:\\"Pop-Ups-Product-nieuws.jpg\\";s:4:\\"path\\";s:26:\\"Pop-Ups-Product-nieuws.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}i:3;a:4:\{s:4:\\"name\\";s:27:\\"Smaak-van-de-maand-juli.jpg\\";s:4:\\"path\\";s:27:\\"Smaak-van-de-maand-juli.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}\}', '0000-00-00 00:00:00', '2015-08-04 06:33:01'),\
(10, 3, '4', 'ravi@devrepublic.nl', 'task with attachment', '<html xmlns:v=\\"urn:schemas-microsoft-com:vml\\" xmlns:o=\\"urn:schemas-microsoft-com:office:office\\" xmlns:w=\\"urn:schemas-microsoft-com:office:word\\" xmlns:m=\\"http://schemas.microsoft.com/office/2004/12/omml\\" xmlns=\\"http://www.w3.org/TR/REC-html40\\"><head><META HTTP-EQUIV=\\"Content-Type\\" CONTENT=\\"text/html; charset=us-ascii\\"><meta name=Generator content=\\"Microsoft Word 15 (filtered medium)\\"><!--[if !mso]><style>v\\\\:* \{behavior:url(#default#VML);\}\\r\\no\\\\:* \{behavior:url(#default#VML);\}\\r\\nw\\\\:* \{behavior:url(#default#VML);\}\\r\\n.shape \{behavior:url(#default#VML);\}\\r\\n</style><![endif]--><style><!--\\r\\n/* Font Definitions */\\r\\n@font-face\\r\\n	\{font-family:Helvetica;\\r\\n	panose-1:2 11 6 4 2 2 2 2 2 4;\}\\r\\n@font-face\\r\\n	\{font-family:Mangal;\\r\\n	panose-1:2 4 5 3 5 2 3 3 2 2;\}\\r\\n@font-face\\r\\n	\{font-family:\\"Cambria Math\\";\\r\\n	panose-1:2 4 5 3 5 4 6 3 2 4;\}\\r\\n@font-face\\r\\n	\{font-family:Calibri;\\r\\n	panose-1:2 15 5 2 2 2 4 3 2 4;\}\\r\\n/* Style Definitions */\\r\\np.MsoNormal, li.MsoNormal, div.MsoNormal\\r\\n	\{margin:0in;\\r\\n	margin-bottom:.0001pt;\\r\\n	font-size:11.0pt;\\r\\n	font-family:\\"Calibri\\",sans-serif;\}\\r\\na:link, span.MsoHyperlink\\r\\n	\{mso-style-priority:99;\\r\\n	color:#0563C1;\\r\\n	text-decoration:underline;\}\\r\\na:visited, span.MsoHyperlinkFollowed\\r\\n	\{mso-style-priority:99;\\r\\n	color:#954F72;\\r\\n	text-decoration:underline;\}\\r\\nspan.EmailStyle17\\r\\n	\{mso-style-type:personal-compose;\\r\\n	font-family:\\"Calibri\\",sans-serif;\\r\\n	color:windowtext;\}\\r\\n.MsoChpDefault\\r\\n	\{mso-style-type:export-only;\\r\\n	font-family:\\"Calibri\\",sans-serif;\}\\r\\n@page WordSection1\\r\\n	\{size:8.5in 11.0in;\\r\\n	margin:1.0in 1.0in 1.0in 1.0in;\}\\r\\ndiv.WordSection1\\r\\n	\{page:WordSection1;\}\\r\\n--></style><!--[if gte mso 9]><xml>\\r\\n<o:shapedefaults v:ext=\\"edit\\" spidmax=\\"1026\\" />\\r\\n</xml><![endif]--><!--[if gte mso 9]><xml>\\r\\n<o:shapelayout v:ext=\\"edit\\">\\r\\n<o:idmap v:ext=\\"edit\\" data=\\"1\\" />\\r\\n</o:shapelayout></xml><![endif]--></head><body lang=EN-US link=\\"#0563C1\\" vlink=\\"#954F72\\"><div class=WordSection1><p class=MsoNormal>Hi Jaykesh<o:p></o:p></p><p class=MsoNormal>Blah blah blah..<o:p></o:p></p><p class=MsoNormal>Please find attached.<o:p></o:p></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><p class=MsoNormal>--<o:p></o:p></p><p class=MsoNormal>Thanks &amp; Regards<o:p></o:p></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><p class=MsoNormal><b><span style=\\'font-size:12.0pt\\'>Ravi Sharma<o:p></o:p></span></b></p><p class=MsoNormal><span style=\\'color:black\\'>Sr. Php Developer</span><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:black\\'><br>m: 8306710585<br><br></span><a href=\\"https://www.facebook.com/ravi441988\\"><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:blue;text-decoration:none\\'><img border=0 width=25 height=25 id=\\"_x0000_i1028\\" src=\\"http://i59.tinypic.com/20avr6g.png\\" alt=\\"http://i59.tinypic.com/20avr6g.png\\"></span></a><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:black\\'>&nbsp;</span><a href=\\"skype:ravi.devrepublic?chat\\"><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:blue;text-decoration:none\\'><img border=0 width=25 height=25 id=\\"_x0000_i1027\\" src=\\"http://i61.tinypic.com/2ed1bar.png\\" alt=\\"http://i61.tinypic.com/2ed1bar.png\\"></span></a><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:black\\'>&nbsp;</span><a href=\\"https://www.linkedin.com/in/ravisharma4\\"><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:blue;text-decoration:none\\'><img border=0 width=25 height=25 id=\\"_x0000_i1026\\" src=\\"http://i61.tinypic.com/2ueim4g.png\\" alt=\\"http://i61.tinypic.com/2ueim4g.png\\"></span></a><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:black\\'><br></span><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:blue\\'><img border=0 width=257 height=52 id=\\"_x0000_i1025\\" src=\\"http://www.jongensvandemedia.nl/dr/Concept1.png\\" alt=\\"http://www.jongensvandemedia.nl/dr/Concept1.png\\"></span><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:black\\'><br>Check our website:&nbsp;</span><a href=\\"http://www.devrepublic.nl\\"><span style=\\'font-size:10.0pt;font-family:\\"Helvetica\\",sans-serif;color:blue\\'>www.devrepublic.nl</span></a><o:p></o:p></p><p class=MsoNormal><o:p>&nbsp;</o:p></p></div></body></html>', 'a:3:\{i:0;a:4:\{s:4:\\"name\\";s:27:\\"6219074997_d61118e7dd_o.jpg\\";s:4:\\"path\\";s:27:\\"6219074997_d61118e7dd_o.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}i:1;a:4:\{s:4:\\"name\\";s:33:\\"railroads-wallpaper-1920x1080.jpg\\";s:4:\\"path\\";s:33:\\"railroads-wallpaper-1920x1080.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}i:2;a:4:\{s:4:\\"name\\";s:19:\\"Train-Wallpaper.jpg\\";s:4:\\"path\\";s:19:\\"Train-Wallpaper.jpg\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}\}', '0000-00-00 00:00:00', '2015-08-05 07:07:07'),\
(11, 24, '5', 'dirkjan75@gmail.com', 'Dit is taak 1', '<div dir=\\"ltr\\">t</div>\\r\\n', 'a:1:\{i:0;a:4:\{s:4:\\"name\\";s:32:\\"bespreeklijst_edward_13-8-15.png\\";s:4:\\"path\\";s:32:\\"bespreeklijst_edward_13-8-15.png\\";s:4:\\"type\\";N;s:11:\\"disposition\\";s:10:\\"attachment\\";\}\}', '0000-00-00 00:00:00', '2015-08-13 14:07:46'),\
(12, 24, '11', 'dirkjan75@gmail.com', 'Fwd: Draft disbursement schedule MDF -ESIA', '<div dir=\\"ltr\\"><br><div class=\\"gmail_quote\\">---------- Doorgestuurd bericht ----------<br>Van: <b class=\\"gmail_sendername\\">Okker, drs. K.P. (Kris)</b> <span dir=\\"ltr\\">&lt;<a href=\\"mailto:kris.okker@rvo.nl\\">kris.okker@rvo.nl</a>&gt;</span><br>Datum: 25 augustus 2015 15:48<br>Onderwerp: RE: Draft disbursement schedule MDF -ESIA<br>Aan: &quot;<a href=\\"mailto:dirkjan75@gmail.com\\">dirkjan75@gmail.com</a>&quot; &lt;<a href=\\"mailto:dirkjan75@gmail.com\\">dirkjan75@gmail.com</a>&gt;<br><br><br><div lang=\\"NL\\" vlink=\\"purple\\" link=\\"blue\\"><div><p class=\\"MsoNormal\\"><span style=\\"color:rgb(31,73,125);font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;font-size:11pt\\">Ha Dirk Jan, <u></u><u></u></span></p><p class=\\"MsoNormal\\"><span style=\\"color:rgb(31,73,125);font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;font-size:11pt\\"><u></u>\'a0<u></u></span></p><p class=\\"MsoNormal\\"><span style=\\"color:rgb(31,73,125);font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;font-size:11pt\\">Ik zou je willen adviseren om het even om te zetten naar het nieuwe format, zoals ook gebruikt bij addendum 4. Als je het me dan nog een keer stuurt dan kan ik er wel even naar kijken. <u></u><u></u></span></p><p class=\\"MsoNormal\\"><span style=\\"color:rgb(31,73,125);font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;font-size:11pt\\"><u></u>\'a0<u></u></span></p><p class=\\"MsoNormal\\"><span style=\\"color:rgb(31,73,125);font-family:&quot;Calibri&quot;,&quot;sans-serif&quot;;font-size:11pt\\">Mvg, Kris<u></u><u></u></span></p><p class=\\"MsoNormal\\"><u></u>\'a0<u></u></p><p class=\\"MsoNormal\\"><b><span style=\\"font-family:&quot;Tahoma&quot;,&quot;sans-serif&quot;;font-size:10pt\\">Van:</span></b><span style=\\"font-family:&quot;Tahoma&quot;,&quot;sans-serif&quot;;font-size:10pt\\"> Dirk Jan Durieux [mailto:<a href=\\"mailto:dirkjan75@gmail.com\\" target=\\"_blank\\">dirkjan75@gmail.com</a>] <br><b>Verzonden:</b> dinsdag 25 augustus 2015 9:58<br><b>Aan:</b> Okker, drs. K.P. (Kris)<br><b>Onderwerp:</b> Draft disbursement schedule MDF -ESIA<u></u><u></u></span></p><div><div class=\\"h5\\"><p class=\\"MsoNormal\\"><u></u>\'a0<u></u></p><div><div><p class=\\"MsoNormal\\">Ha Kris<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">\'a0<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">Bijgevoegd zoals gisteren besproken, de draft payment schedule voor MDF-ESIA. Zou je op basis van de veranderingen bij Schiphol, het schema desgewenst kunnen aanpassen?<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">\'a0<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">Dank<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">\'a0<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">Vrgr<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">\'a0<u></u><u></u></p></div><div><p class=\\"MsoNormal\\">Dirk Jan Durieux<u></u><u></u></p></div></div></div></div></div>De Rijksdienst voor Ondernemend Nederland (RVO.nl) stimuleert Duurzaam, Agrarisch, Innovatief en Internationaal ondernemen. RVO.nl is per 2014 ontstaan uit de fusie van Agentschap NL en Dienst Regelingen. <br><br>Dit bericht kan informatie bevatten die niet voor u is bestemd. Indien u<br>niet de geadresseerde bent of dit bericht abusievelijk aan u is gezonden,<br>wordt u verzocht dat aan de afzender te melden en het bericht te <br>verwijderen. <br>De Staat aanvaardt geen aansprakelijkheid voor schade, van welke aard <br>ook, die verband houdt met risico&#39;s verbonden aan het elektronisch <br>verzenden van berichten.<br>This message may contain information that is not intended for you. If you<br>are not the addressee or if this message was sent to you by mistake, you<br>are requested to inform the sender and delete the message.<br>The State accepts no liability for damage of any kind resulting from the<br>risks inherent in the electronic transmission of messages.</div></div><br></div>\\r\\n', 'a:0:\{\}', '0000-00-00 00:00:00', '2015-08-25 18:53:35');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invite_workgroup_members`\
--\
\
CREATE TABLE `invite_workgroup_members` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `workgroup_id` int(10) UNSIGNED NOT NULL,\
  `member_id` int(10) UNSIGNED NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoicelines`\
--\
\
CREATE TABLE `invoicelines` (\
  `id` int(11) NOT NULL,\
  `invoice_id` int(11) DEFAULT NULL,\
  `subscription_id` int(11) NOT NULL,\
  `subject` varchar(100) NOT NULL,\
  `quantity` decimal(10,2) NOT NULL,\
  `price_per_quantity` decimal(10,2) NOT NULL,\
  `tax_rate` float(5,2) NOT NULL,\
  `price` decimal(10,2) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoicelines`\
--\
\
INSERT INTO `invoicelines` (`id`, `invoice_id`, `subscription_id`, `subject`, `quantity`, `price_per_quantity`, `tax_rate`, `price`) VALUES\
(29, 13, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(30, 15, 4, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(31, 16, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(32, 16, 1, 'Lunch jan 2015', '26.00', '2.00', 21.00, '52.00'),\
(33, 17, 9, 'Secretari\'eble ondersteuning', '15.00', '35.00', 21.00, '525.00'),\
(34, 18, 10, 'Bijdrage aan borrel dd. 19-2-2015', '1.00', '100.00', 21.00, '100.00'),\
(37, 19, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(38, 20, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(39, 21, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(40, 21, 4, 'korting op pressure cooker', '1.00', '-500.00', 21.00, '-500.00'),\
(41, 19, 4, 'korting op pressure cooker', '1.00', '-200.00', 21.00, '-200.00'),\
(42, 23, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(43, 24, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(44, 24, 4, 'R10 korting op pressure cooker', '1.00', '-100.00', 21.00, '-100.00'),\
(45, 25, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(46, 26, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(47, 27, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(48, 27, 4, 'R10 korting op pressure cooker', '1.00', '-100.00', 21.00, '-100.00'),\
(49, 28, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(50, 29, 4, 'Pressure Cooker #1, voorjaar 2015. deelbetaling 1', '1.00', '250.00', 21.00, '250.00'),\
(51, 22, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(52, 30, 4, 'Pressure Cooker #1, voorjaar 2015', '1.00', '500.00', 21.00, '500.00'),\
(54, 22, 4, '25% korting op pressure cooker traject ', '1.00', '-125.00', 21.00, '-125.00'),\
(55, 31, 10, 'Bijdrage aan event, dd. 23-1-2015', '1.00', '40.00', 21.00, '40.00'),\
(56, 32, 11, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(57, 33, 4, 'Secretari\'eble ondersteuning', '19.00', '35.00', 21.00, '665.00'),\
(58, 34, 4, 'Lunch', '83.00', '2.00', 21.00, '166.00'),\
(59, 36, 1, 'Project Management jan & feb 2015 ', '3.00', '850.00', 0.00, '2550.00'),\
(60, 34, 1, 'Koffie', '1.00', '12.50', 21.00, '12.50'),\
(61, 35, 1, 'Lunches januari  - maart 2015 bij IncZwolle', '16.00', '2.00', 21.00, '32.00'),\
(62, 37, 1, 'Lunches maart 2015 ', '84.00', '2.00', 21.00, '168.00'),\
(63, 37, 1, 'Koffie ', '1.00', '25.00', 21.00, '25.00'),\
(64, 38, 8, 'Altijd Welkom lidmaatschap april 2015', '1.00', '350.00', 21.00, '350.00'),\
(65, 39, 9, 'Secretari\'eble ondersteuning tm 13 maart', '12.00', '35.00', 21.00, '437.50'),\
(66, 39, 9, 'Secretari\'eble ondersteuning na 13 maart', '8.00', '40.00', 21.00, '280.00'),\
(67, 40, 15, 'Project management March', '1.00', '850.00', 0.00, '850.00'),\
(68, 41, 0, 'Secretari\'eble ondersteuning', '2.00', '40.00', 21.00, '80.00'),\
(69, 42, 4, 'Pressure Cooker #1, voorjaar 2015, deelbetaling 2 ', '1.00', '250.00', 21.00, '250.00'),\
(70, 43, 4, 'Pressure Cooker #1, voorjaar 2015', '2.00', '500.00', 21.00, '1000.00'),\
(71, 44, 1, 'Lunch', '6.00', '2.00', 21.00, '12.00'),\
(72, 45, 1, 'Lunch en koffie april 2015', '66.00', '2.00', 21.00, '132.00'),\
(73, 46, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(74, 47, 15, 'Bijeenkomst tbv Van Wijnen', '1.00', '150.00', 21.00, '150.00'),\
(75, 48, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(77, 49, 1, 'Lunch mei', '54.00', '2.00', 21.00, '108.00'),\
(79, 51, 1, 'Lunch', '24.00', '2.00', 21.00, '48.00'),\
(80, 49, 16, 'Koffie/Thee abonnement april', '1.00', '30.00', 21.00, '30.00'),\
(81, 49, 16, 'Koffie/Thee abonnement mei', '1.00', '30.00', 21.00, '30.00'),\
(82, 52, 17, 'Masterclasses ondernemen basis april - mei 2015', '2.00', '1200.00', 0.00, '2400.00'),\
(83, 52, 18, 'Masterclass Ondernemen gevorderd juni 2015', '1.00', '1200.00', 0.00, '1200.00'),\
(84, 53, 19, 'Flexplekken juni @IncZwolle', '4.00', '100.00', 21.00, '400.00'),\
(85, 53, 19, 'Flexplekken juli @ IncZwolle', '4.00', '100.00', 21.00, '400.00'),\
(86, 53, 19, 'Korting', '1.00', '-200.00', 21.00, '-200.00'),\
(87, 54, 15, 'Contract management June \\'15 for MDF & Schiphol', '1.00', '850.00', 0.00, '850.00'),\
(88, 55, 17, 'Bootcamp ondernemerschap juni 2015', '1.00', '2000.00', 0.00, '2000.00'),\
(89, 50, 16, 'Koffie/Thee abonnement', '1.00', '30.00', 21.00, '30.00'),\
(90, 50, 1, 'Lunch', '61.00', '2.00', 21.00, '122.00'),\
(91, 56, 16, 'Koffie/Thee abonnement', '1.00', '30.00', 21.00, '30.00'),\
(92, 56, 1, 'Lunch', '84.00', '2.00', 21.00, '168.00'),\
(93, 57, 10, 'Bijdrage aan event', '1.00', '100.00', 21.00, '100.00'),\
(94, 58, 15, 'advanced payment development business plan 25percent  of 13.950', '1.00', '3487.50', 0.00, '3487.50'),\
(95, 58, 20, 'Flight KLM AMS-JRO 5-7 july ', '1.00', '2373.00', 0.00, '2373.00'),\
(96, 58, 20, 'Visa Tanzania', '1.00', '45.00', 0.00, '45.00'),\
(97, 59, 8, 'Altijd Welkom lidmaatschap  aug 2015', '1.00', '350.00', 21.00, '350.00'),\
(98, 60, 8, 'Altijd Welkom lidmaatschap aug 2015', '1.00', '350.00', 21.00, '350.00'),\
(99, 61, 21, 'Pressure Cooker (najaar 2015)', '1.00', '750.00', 21.00, '750.00'),\
(100, 62, 21, 'Pressure Cooker (najaar 2015)', '1.00', '750.00', 21.00, '750.00'),\
(101, 63, 21, 'Pressure Cooker (najaar 2015)', '1.00', '750.00', 21.00, '750.00'),\
(102, 65, 21, 'Pressure Cooker', '1.00', '750.00', 21.00, '750.00'),\
(103, 65, 21, 'Bijdrage stichting ondersteuning ondernemerschap', '1.00', '-250.00', 21.00, '-250.00'),\
(104, 64, 21, 'Pressure Cooker', '1.00', '750.00', 21.00, '750.00'),\
(105, 66, 21, 'Pressure Cooker', '1.00', '750.00', 21.00, '750.00'),\
(106, 67, 21, 'Pressure Cooker', '1.00', '750.00', 21.00, '750.00'),\
(107, 67, 21, 'Bijdrage stichting Ondersteuning Ondernemerschap', '1.00', '-300.00', 21.00, '-300.00'),\
(108, 68, 15, 'contract management july / august', '2.50', '850.00', 0.00, '2125.00'),\
(109, 69, 15, 'interim payment business plan 50%', '1.00', '6975.00', 0.00, '6975.00'),\
(110, 70, 8, 'Altijd Welkom lidmaatschap sept 2015', '1.00', '350.00', 21.00, '350.00'),\
(111, 71, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(112, 72, 19, 'Flexplek @ IncZwolle sept \\'15', '1.00', '100.00', 21.00, '100.00'),\
(113, 73, 21, 'Pressure Cooker #2, sept \\'15', '1.00', '750.00', 21.00, '750.00'),\
(114, 74, 22, 'Coachsgesprekken 24/8 en 18/9 ', '2.00', '80.00', 21.00, '160.00'),\
(115, 75, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(117, 75, 23, 'Bijgemaakte sleutels', '7.00', '-4.75', 21.00, '-33.25'),\
(118, 76, 8, 'Altijd Welkom lidmaatschap okt 2015', '1.00', '350.00', 21.00, '350.00'),\
(119, 78, 15, 'Contract management Sept 2015', '2.00', '850.00', 0.00, '1700.00'),\
(120, 79, 15, '25% final payment business plan', '1.00', '3487.50', 0.00, '3487.50'),\
(121, 79, 20, 'Ticket AMS-JRO 7 - 9 october', '1.00', '3403.88', 0.00, '3403.88'),\
(122, 79, 20, 'visa', '1.00', '45.00', 0.00, '45.00'),\
(123, 80, 19, 'Flexplek @ IncZwolle Okt 2015', '1.00', '100.00', 21.00, '100.00'),\
(124, 81, 23, 'Kosten Gamma tbv spreekkamer H1', '1.00', '222.51', 21.00, '222.51'),\
(125, 82, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(126, 83, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(127, 84, 19, 'Flexplek @ IncZwolle', '1.00', '100.00', 21.00, '100.00'),\
(128, 85, 21, 'Tegemoetkoming deelnemers tbv Pressure Cooker programma', '1.00', '1600.00', 21.00, '1600.00'),\
(129, 86, 15, 'Consultancy', '7.00', '850.00', 0.00, '5950.00'),\
(130, 86, 20, 'Ticket AMS - JRO 27-20 nov', '1.00', '2785.83', 0.00, '2785.83'),\
(131, 86, 20, 'Visa Tanzania', '1.00', '45.00', 0.00, '45.00'),\
(132, 87, 17, 'Masterclass Ondernemen basis najaar 2015', '1.00', '2000.00', 0.00, '2000.00'),\
(133, 88, 23, 'Samenwerkingsovereenkomst 150520 v2.', '1.00', '4000.00', 21.00, '4000.00'),\
(134, 89, 8, 'Altijd Welkom lidmaatschap dec\\'15', '1.00', '350.00', 21.00, '350.00'),\
(135, 91, 8, 'Altijd Welkom lidmaatschap dec \\'15', '1.00', '350.00', 21.00, '350.00'),\
(136, 90, 19, 'Flexplek @ IncZwolle dec \\'15', '1.00', '100.00', 21.00, '100.00'),\
(137, 92, 17, 'Masterclasses GEW Get in the RIng competitie', '1.00', '300.00', 21.00, '300.00'),\
(138, 94, 21, 'Pressure Cooker#3, workshop 1-6', '1.00', '375.00', 21.00, '375.00'),\
(139, 93, 21, 'Pressure Cooker#3, workshop 1-6', '1.00', '375.00', 21.00, '375.00'),\
(140, 95, 21, 'Pressure Cooker#3, deelfactuur 1', '1.00', '100.00', 21.00, '100.00'),\
(143, 96, 21, 'Pressure Cooker#3', '1.00', '795.00', 21.00, '795.00'),\
(144, 97, 21, 'Pressure Cooker #3, deelfactuur 1', '1.00', '100.00', 21.00, '100.00'),\
(146, 98, 21, 'Verkort traject Pressure Cooker3', '1.00', '150.00', 21.00, '150.00'),\
(148, 99, 21, 'Pressure Cooker#3', '1.00', '795.00', 21.00, '795.00'),\
(149, 99, 23, 'Bijdrage C Honing trainingfee', '1.00', '-125.00', 21.00, '-125.00'),\
(150, 101, 8, 'Altijd Welkom lidmaatschap Jan 2016', '1.00', '350.00', 21.00, '350.00'),\
(151, 102, 8, 'Altijd Welkom lidmaatschap Jan 2016', '1.00', '350.00', 21.00, '350.00'),\
(152, 103, 19, 'Flexplek @ IncZwolle stippenkaart', '6.00', '15.00', 21.00, '90.00'),\
(153, 104, 19, 'Flexplek @ IncZwolle jan 2016', '1.00', '100.00', 21.00, '100.00'),\
(154, 105, 21, 'Tegemoetkoming deelnemers tbv Pressure Cooker programma, zie excel sheet', '1.00', '900.00', 21.00, '900.00'),\
(155, 100, 1, 'Lunch', '1.00', '2.00', 21.00, '2.00'),\
(156, 106, 15, 'Migratie en update decanendatabase', '3.50', '110.00', 21.00, '385.00'),\
(157, 107, 22, 'Coaching & begeleiding jan 2016', '1.00', '150.00', 21.00, '150.00'),\
(158, 108, 21, 'Pressure Cooker eindafrekening', '1.00', '100.00', 21.00, '100.00'),\
(159, 109, 21, 'Pressure Cooker deelfactuur jan. ', '1.00', '132.00', 21.00, '132.00'),\
(160, 110, 8, 'Altijd Welkom lidmaatschap feb 2016', '1.00', '350.00', 21.00, '350.00'),\
(161, 111, 8, 'Altijd Welkom lidmaatschap feb 2016', '1.00', '350.00', 21.00, '350.00'),\
(162, 112, 15, 'Revisions on Business Plan based on Board review', '1.50', '850.00', 0.00, '1275.00'),\
(163, 113, 8, 'Altijd Welkom lidmaatschap maart 2016', '1.00', '350.00', 21.00, '350.00'),\
(164, 114, 8, 'Altijd Welkom lidmaatschap maart 2016', '1.00', '350.00', 21.00, '350.00'),\
(165, 115, 21, 'Pressure Cooker deelfactuur feb 2016', '1.00', '132.00', 21.00, '132.00'),\
(166, 116, 24, 'Interim/project management VU feb 2016', '104.50', '104.38', 21.00, '10907.71'),\
(167, 117, 24, 'Interim/project management VU', '119.00', '104.38', 21.00, '12421.22'),\
(168, 118, 8, 'Altijd Welkom lidmaatschap april 2016', '1.00', '350.00', 21.00, '350.00'),\
(169, 118, 8, 'Altijd Welkom lidmaatschap additionele ruimte 1/2 maand', '1.00', '150.00', 21.00, '150.00'),\
(170, 119, 8, 'Altijd Welkom lidmaatschap maart 2016', '1.00', '350.00', 21.00, '350.00'),\
(171, 120, 22, 'Coaching & begeleiding feb 2016', '1.00', '150.00', 21.00, '150.00'),\
(172, 121, 17, 'Masterclass Ondernemen basis voorjaar 2016', '1.00', '2000.00', 0.00, '2000.00'),\
(173, 122, 24, 'Interim/project management VU', '148.50', '104.38', 21.00, '15500.43'),\
(174, 123, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(175, 123, 8, 'Additionele bijdrage ivm gebruik IncZwolle HQ', '1.00', '300.00', 21.00, '300.00'),\
(176, 124, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(177, 125, 22, 'Coaching & begeleiding Mepschenbouw april 2016', '1.00', '150.00', 21.00, '150.00'),\
(178, 126, 23, 'Tegemoetkoming verhuiskosten ivm overname ruimte 1e verdieping', '1.00', '500.00', 21.00, '500.00'),\
(179, 127, 24, 'Interim/project management VU', '114.00', '104.38', 21.00, '11899.32'),\
(180, 129, 8, 'Altijd Welkom lidmaatschap', '1.00', '350.00', 21.00, '350.00'),\
(181, 128, 8, 'Altijd Welkom lidmaatschap', '1.00', '650.00', 21.00, '650.00'),\
(182, 130, 22, 'Coaching & begeleiding Mepschenbouw mei 2016', '1.00', '120.00', 21.00, '120.00'),\
(183, 131, 8, 'Altijd Welkom lidmaatschap juli', '1.00', '650.00', 21.00, '650.00'),\
(184, 132, 8, 'Altijd Welkom lidmaatschap juli 2016', '1.00', '350.00', 21.00, '350.00'),\
(185, 133, 24, 'Interim/project management VU', '140.50', '100.00', 21.00, '14050.00'),\
(186, 134, 24, 'Interim/project management VU', '71.50', '100.00', 21.00, '7150.00'),\
(187, 135, 24, 'Interim/project management VU', '86.00', '100.00', 21.00, '8600.00'),\
(188, 136, 24, 'Interim/project management VU', '132.50', '100.00', 21.00, '13250.00'),\
(189, 137, 15, 'Reparatie decanendatabase i.o.v. Floor Diekema-Van Os, afgerond 26-10-2016', '5.00', '125.00', 21.00, '625.00'),\
(190, 138, 24, 'Interim/project management VU Oktober 2016', '136.00', '100.00', 21.00, '13600.00'),\
(191, 137, 15, 'Additionele wijzigingen op verzoek Tjitske Keidel d.d. 31-10-16', '3.00', '125.00', 21.00, '375.00'),\
(192, 139, 8, 'Correctie 1 week huur april 2016', '-1.00', '75.00', 21.00, '-75.00'),\
(193, 140, 24, 'Interim/project management VU november 2016', '151.00', '100.00', 21.00, '15100.00'),\
(194, 142, 24, 'Interim/project management VU', '97.50', '100.00', 21.00, '9750.00'),\
(195, 143, 23, 'KLM ticket AMS-AUS mrt 2017', '1.00', '908.61', 21.00, '908.61'),\
(196, 144, 24, 'Interim/project management VU jan \\'17', '116.50', '100.00', 21.00, '11650.00'),\
(197, 145, 24, 'Interim/project management VU feb \\'17', '117.00', '100.00', 21.00, '11700.00'),\
(199, 146, 24, 'Interim/project management VU', '138.50', '100.00', 21.00, '13850.00'),\
(200, 147, 24, 'Interim/project management VU april 2017', '101.00', '100.00', 21.00, '10100.00'),\
(201, 148, 17, 'Masterclass Ondernemen 5 sessies', '1.00', '2000.00', 21.00, '2000.00'),\
(202, 149, 24, 'Interim/project management VU mei 2017', '154.00', '100.00', 21.00, '15400.00'),\
(203, 150, 24, 'Interim/project management VU Juni 2017', '145.50', '100.00', 21.00, '14550.00'),\
(204, 151, 24, 'Interim/project management VU juli 17', '85.00', '100.00', 21.00, '8500.00'),\
(205, 152, 24, 'Interim/project management VU augustus 17', '49.50', '100.00', 21.00, '4950.00'),\
(206, 153, 24, 'Interim/project management VU sept 2017', '142.50', '100.00', 21.00, '14250.00'),\
(207, 154, 22, 'Coachsessies incl. voorbereiding op 2 jun, 23 jun, 11 jul,  1 sept', '10.00', '100.00', 21.00, '1000.00'),\
(208, 155, 24, 'Interim/project management VU okt 2017', '140.00', '100.00', 21.00, '14000.00'),\
(209, 156, 23, 'Overdracht activa laptop , iPhone 6S, Fiets, scooter Thomos, webapplicatie ', '1.00', '6500.00', 21.00, '6500.00'),\
(210, 157, 24, 'Interim/project management VU', '157.00', '100.00', 21.00, '15700.00'),\
(211, 158, 22, 'Coaching & begeleiding', '1.00', '250.00', 21.00, '250.00'),\
(212, 159, 24, 'Interim/project management VU december 2017', '81.00', '100.00', 21.00, '8100.00'),\
(214, 161, 24, 'Interim/project management VU jan 2018', '147.00', '100.00', 21.00, '14700.00'),\
(215, 162, 24, 'Interim/project management VU feb 2018', '140.00', '100.00', 21.00, '14000.00'),\
(216, 163, 24, 'Interim/project management VU maart 2018', '148.00', '100.00', 21.00, '14800.00'),\
(217, 164, 24, 'Interim/project management VU', '143.00', '100.00', 21.00, '14300.00'),\
(218, 165, 24, 'Interim/project management VU', '110.50', '100.00', 21.00, '11050.00'),\
(219, 166, 24, 'Interim/project management VU juni 2018', '149.00', '100.00', 21.00, '14900.00'),\
(220, 167, 24, 'Interim/project management VU juli 2018', '119.50', '100.00', 21.00, '11950.00'),\
(221, 168, 24, 'Interim/project management VU aug 2018', '70.50', '100.00', 21.00, '7050.00'),\
(222, 169, 23, 'Gebruik \\'SIR\\' inzetplannig software', '1.00', '1500.00', 21.00, '1500.00'),\
(223, 170, 24, 'Interim/project management VU sept \\'18', '138.00', '100.00', 21.00, '13800.00'),\
(224, 171, 23, 'Ontwikkelen scherm Expertises Team binnen SirWeb', '1.00', '300.00', 21.00, '300.00'),\
(225, 171, 23, 'Licentie  SirWeb van 1 maart 2019 t/m 29 februari 2020', '1.00', '3000.00', 21.00, '3000.00'),\
(226, 172, 24, 'Project management Oktober \\'18', '51.00', '120.00', 21.00, '6120.00'),\
(227, 172, 23, 'Treinreizen', '1.00', '165.60', 21.00, '165.60'),\
(228, 173, 23, 'Project management November \\'18', '45.50', '120.00', 21.00, '5460.00'),\
(229, 173, 23, 'Treinreizen  4/5 en 19/20 nov', '2.00', '165.60', 21.00, '331.20'),\
(230, 174, 24, 'Interim/project management VU okt 2018', '149.50', '100.00', 21.00, '14950.00'),\
(231, 175, 24, 'Interim/project management VU Nov. 2018', '135.00', '100.00', 21.00, '13500.00'),\
(232, 176, 1, 'Creditfactuur voor 2018012', '1.00', '-3300.00', 21.00, '-3300.00'),\
(233, 177, 0, 'Licentie SIR  van Pegasus 1 maart - 31 augustus 2019', '1.00', '1500.00', 21.00, '1500.00'),\
(234, 178, 0, 'Licentie SIR  van Pegasus 1 Sept 2019 - 29 februari 2020', '1.00', '1500.00', 21.00, '1500.00'),\
(235, 179, 0, 'Treinreizen 3/4  en 17/18 dec  ', '2.00', '165.60', 21.00, '331.20'),\
(236, 179, 0, 'Projectmanagement december 2018', '53.00', '120.00', 21.00, '6360.00'),\
(238, 181, 11, 'Bemiddeling data analyse UGent dec 18', '40.00', '20.00', 21.00, '800.00'),\
(239, 182, 24, 'Interim/project management VU Dec. 2018', '76.00', '100.00', 21.00, '7600.00'),\
(240, 184, 24, 'project management roostering Ugent jan 2019', '55.00', '120.00', 21.00, '6600.00'),\
(241, 184, 0, 'Treinreizen 7/8 en 28/29 jan', '2.00', '165.00', 21.00, '330.00'),\
(242, 183, 24, 'Interim/project management VU jan 2019', '110.50', '100.00', 21.00, '11050.00'),\
(243, 185, 24, 'Projectmanagement Onderwijslogistiek UGent', '52.00', '120.00', 21.00, '6240.00'),\
(244, 185, 0, 'Treinreizen 4/5 en 18/19 feb', '2.00', '165.00', 21.00, '330.00'),\
(245, 186, 24, 'Interim/project management VU feb 2019', '105.00', '100.00', 21.00, '10500.00'),\
(246, 187, 23, 'Project management Onderwijslogistiek', '54.50', '120.00', 21.00, '6540.00'),\
(247, 187, 1, 'treinreizen 7/8 en 25/26 mrt', '2.00', '165.00', 21.00, '330.00'),\
(249, 188, 24, 'Interim/project management VU mrt 2019', '122.00', '100.00', 21.00, '12200.00'),\
(250, 189, 1, 'Future State Process offerte', '1.00', '5200.00', 21.00, '5200.00'),\
(251, 189, 1, 'Additionele werkzaamheden: 42 uur @ 50%', '21.00', '100.00', 21.00, '2100.00'),\
(252, 190, 23, 'Project management Onderwijslogistiek', '53.50', '120.00', 21.00, '6420.00'),\
(253, 190, 0, 'treinreizen 17/18 en 29/30 april', '2.00', '165.00', 21.00, '330.00'),\
(254, 191, 11, 'Bemiddeling voor diensten', '1.00', '800.00', 21.00, '800.00'),\
(255, 192, 24, 'Interim/project management VU', '56.50', '100.00', 21.00, '5650.00'),\
(256, 193, 25, 'Projectmanagement UGent', '78.00', '120.00', 21.00, '9360.00'),\
(257, 193, 26, 'Treinreizen van & naar Gent  13/14 en 27/28 mei', '2.00', '165.00', 21.00, '330.00'),\
(258, 193, 23, 'borrel Citizen M 14 mei', '1.00', '48.50', 21.00, '48.50'),\
(259, 194, 24, 'Interim/project management VU mei 19', '100.00', '100.00', 21.00, '10000.00'),\
(260, 195, 25, 'Projectmanagement UGent juni 2019', '53.50', '120.00', 21.00, '6420.00'),\
(261, 195, 26, 'Treinreizen van & naar Gent', '2.00', '165.00', 21.00, '330.00'),\
(262, 196, 24, 'Interim/project management VU juni 19', '109.50', '100.00', 21.00, '10950.00'),\
(263, 197, 25, 'Projectmanagement UGent', '31.00', '120.00', 21.00, '3720.00'),\
(264, 197, 26, 'Treinreizen van & naar Gent 4/5 juli', '1.00', '165.00', 21.00, '165.00'),\
(265, 198, 24, 'Interim/project management VU juli 2019', '84.00', '100.00', 21.00, '8400.00'),\
(266, 199, 24, 'Project management VU', '107.00', '100.00', 21.00, '10700.00'),\
(267, 200, 25, 'Projectmanagement UGent augustus 2019', '20.00', '120.00', 21.00, '2400.00'),\
(268, 200, 26, 'Treinreizen van & naar Gent 27-29 augustus', '1.00', '165.00', 21.00, '165.00'),\
(269, 201, 25, 'Projectmanagement UGent', '33.50', '120.00', 21.00, '4020.00'),\
(270, 201, 23, 'Treinreis 18-19/9', '1.00', '165.00', 21.00, '165.00'),\
(271, 202, 24, 'Project management OO3 sept 2019', '87.00', '100.00', 21.00, '8700.00'),\
(272, 202, 0, 'Projectmanagement Opt Zaal Utilisatie', '23.00', '100.00', 21.00, '2300.00'),\
(273, 203, 0, 'Licentie SirWeb 1 maart 2020 tot 1 oktober 2020', '1.00', '750.00', 21.00, '750.00'),\
(274, 204, 24, 'Project management VU  OO3', '48.50', '100.00', 21.00, '4850.00'),\
(275, 204, 0, 'Project management Optimale ZaalUtil.', '30.00', '100.00', 21.00, '3000.00'),\
(276, 205, 25, 'Advies project onderwijslogistiek okt 2019', '23.00', '120.00', 21.00, '2760.00'),\
(277, 205, 26, 'Treinreizen van & naar Gent 11 okt & 25 okt', '2.00', '165.00', 21.00, '330.00'),\
(278, 206, 23, 'Projectadvies Roostering okt 2019', '12.50', '135.00', 21.00, '1687.50'),\
(279, 207, 23, 'Voorgeschoten vliegticket Easyjet AMS-EDI, zie bijlage', '1.00', '160.82', 21.00, '160.82'),\
(280, 208, 25, 'Projectmanagement UGent niov 19', '16.00', '120.00', 21.00, '1920.00'),\
(281, 208, 26, 'Treinreizen van & naar Gent 13/11', '1.00', '165.00', 21.00, '165.00'),\
(282, 209, 23, 'Projectadvies Roostering nov 2019', '26.00', '135.00', 21.00, '3510.00'),\
(283, 210, 24, 'Opt Zaal Util 5380023 nov 2019', '24.00', '100.00', 21.00, '2400.00'),\
(284, 210, 0, 'OO3 nov 2019 5380017', '78.00', '100.00', 21.00, '7800.00'),\
(285, 211, 23, 'Projectadvies roostering dec 2019', '18.00', '135.00', 21.00, '2430.00'),\
(286, 212, 25, 'Projectmanagement UGent dec 2019', '25.00', '120.00', 21.00, '3000.00'),\
(287, 212, 26, 'Treinreizen van & naar Gent 10/11 dec', '1.00', '165.00', 21.00, '165.00'),\
(288, 214, 0, 'Project Optimale Onderwijsplanning 5380017', '44.50', '100.00', 21.00, '4450.00'),\
(289, 214, 24, 'Project Optimale Zaalutilisatie 5380023', '13.00', '100.00', 21.00, '1300.00'),\
(290, 215, 23, 'Maatwerk SIR sem 1 2019/2020', '1.00', '300.00', 21.00, '300.00'),\
(291, 216, 25, 'Projectadvisering  UGent Jan 2020', '19.50', '120.00', 21.00, '2340.00'),\
(292, 216, 26, 'Treinreizen van & naar Gent 17/1', '1.00', '165.00', 21.00, '165.00'),\
(293, 217, 15, 'Projectadvisering januari 2020', '34.50', '135.00', 21.00, '4657.50'),\
(294, 218, 24, 'Project management VU inzake Opt. Zaal Utilisatie', '27.00', '125.00', 21.00, '3375.00'),\
(295, 219, 24, 'Project management VU OO3 Jan 2020', '29.00', '100.00', 21.00, '2900.00'),\
(297, 220, 0, 'Projectadvisering roostering  feb 2020', '20.00', '135.00', 21.00, '2700.00'),\
(298, 221, 0, 'Project Optimale Zaalutilisatie feb 2020', '30.00', '125.00', 21.00, '3750.00'),\
(299, 222, 24, 'project management VU OO3 feb 2020', '41.00', '100.00', 21.00, '4100.00'),\
(300, 223, 0, 'Ondersteuning in februari 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(301, 224, 0, 'Advies maart 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(302, 224, 0, 'Projectbemiddeling (43*10)', '1.00', '430.00', 21.00, '430.00'),\
(303, 225, 24, 'Projectmanagement VU, maart 2020', '30.50', '100.00', 21.00, '3050.00'),\
(304, 226, 0, 'Projectadvisering roostering  maart 2020', '17.00', '135.00', 21.00, '2295.00'),\
(305, 227, 24, 'Project management OZU mrt 2020', '36.50', '125.00', 21.00, '4562.50'),\
(306, 228, 24, 'Project management Opt ZaalUtilisatie april 2020', '29.50', '125.00', 21.00, '3687.50'),\
(307, 229, 0, 'Advies april 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(308, 230, 0, 'Advies april 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(309, 231, 0, 'Inzet El Shafiy voor project Proctoring april 2020', '80.00', '85.00', 21.00, '6800.00'),\
(310, 232, 0, 'Projectadvies roostering april 2020', '6.00', '135.00', 21.00, '810.00'),\
(311, 233, 0, 'Strategisch roosteradvies April 2020', '6.00', '135.00', 21.00, '810.00'),\
(312, 234, 25, 'Projectadvisering UGent mei 2020', '16.00', '120.00', 21.00, '1920.00'),\
(313, 235, 24, 'Projectmanagement Opt. Zaal utilisatie mei 2020 ', '23.50', '125.00', 21.00, '2937.50'),\
(314, 236, 0, 'Strategisch roosteradvies Mei 2020', '4.50', '135.00', 21.00, '607.50'),\
(315, 237, 0, 'Advies mei 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(316, 238, 0, 'Advies mei 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(317, 239, 0, 'Inzet El Shafiy voor project Proctoring mei2020 ', '50.00', '85.00', 21.00, '4250.00'),\
(328, 244, 0, 'Advies juni 2020 (960*20/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(330, 245, 0, 'Advies juni 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(331, 246, 0, 'Projectmanagement  Optimale Zaalutilisatie juni 2020', '16.50', '125.00', 21.00, '2062.50'),\
(332, 247, 0, 'Projectadvisering roostering juni 2020 ', '7.50', '135.00', 21.00, '1012.50'),\
(333, 248, 0, 'Tool Curr Voorber. Inzet Dirk Jan juni 2020 ', '7.00', '135.00', 21.00, '945.00'),\
(334, 248, 0, 'Tool Curr VOorb. Inzet Anne juni 2020 ', '4.00', '100.00', 21.00, '400.00'),\
(336, 249, 0, 'Projectmanagement Vooronderzoek UAS juni 2020', '10.00', '95.00', 21.00, '950.00'),\
(338, 250, 0, 'Projectmanagement Optimale Zaalutilisatie juli 2020', '3.50', '125.00', 21.00, '437.50'),\
(339, 251, 0, 'Advies juli 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(340, 252, 0, 'Advies juli 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(341, 253, 0, 'Tool Curr Voorber. Inzet Dirk Jan juli 2020 ', '14.50', '135.00', 21.00, '1822.50'),\
(342, 253, 0, 'Tool Curr Voorber. Inzet Anne junl 2020 ', '7.00', '100.00', 21.00, '700.00'),\
(343, 254, 0, 'Programma advisering digital excellence for Education juli 2020', '3.00', '135.00', 21.00, '405.00'),\
(344, 255, 0, 'Projectmanagement Vooronderzoek UAS juli 2020', '114.00', '95.00', 21.00, '10830.00'),\
(345, 256, 0, 'Advies augustus 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(346, 257, 0, 'Advies augustus 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(347, 258, 0, 'Projectmanagement Vooronderzoek UAS aug 2020', '83.00', '95.00', 21.00, '7885.00'),\
(348, 259, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan Aug 2020 ', '20.50', '135.00', 21.00, '2767.50'),\
(349, 259, 0, 'Onderwijsvoorbereidingappl. Inzet Anne Aug 2020', '13.00', '100.00', 21.00, '1300.00'),\
(350, 260, 0, 'Opstellen PID optimale onderwijsplanning t/m 7-9-2020', '70.00', '127.50', 21.00, '8925.00'),\
(351, 261, 25, 'Projectmanagement UGent', '2.50', '120.00', 21.00, '300.00'),\
(352, 262, 27, 'Programma advisering digital excellence for Education sept 2020', '3.00', '135.00', 21.00, '405.00'),\
(353, 263, 0, 'Projectadvisering roostering september 2020', '6.00', '135.00', 21.00, '810.00'),\
(354, 264, 0, 'Opstellen PID optimale onderwijsplanning 7-9 t/m 1-10-2020', '29.00', '127.50', 21.00, '3697.50'),\
(355, 265, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan sept 2020', '41.00', '135.00', 21.00, '5535.00'),\
(356, 265, 0, 'Onderwijsvoorbereidingappl. Inzet Anne Sept 2020', '24.00', '100.00', 21.00, '2400.00'),\
(357, 266, 0, 'Advies september 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(358, 267, 0, 'Advies september2020', '1.00', '1600.00', 21.00, '1600.00'),\
(359, 268, 0, 'Afrondend: rapportages PowerBi tbv OO3 sept 2020', '7.50', '125.00', 21.00, '937.50'),\
(360, 269, 0, 'Project management aanbesteding UAS sept 2020', '60.00', '95.00', 21.00, '5700.00'),\
(361, 270, 0, 'Project management aanbesteding UAS okt 2020', '93.00', '95.00', 21.00, '8835.00'),\
(362, 271, 0, 'Programma management Opt. Onderwijsplanning okt 2020', '29.00', '135.00', 21.00, '3915.00'),\
(363, 272, 0, 'Advies oktober 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(364, 273, 0, 'Advies oktober 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(365, 274, 0, 'Project management aanbesteding UAS nov 2020', '120.00', '95.00', 21.00, '11400.00'),\
(366, 275, 0, 'Advies november 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(367, 276, 0, 'Advies november 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(368, 277, 0, 'Projectadvisering nov 2020', '5.00', '135.00', 21.00, '675.00'),\
(369, 278, 0, 'Programma management Opt. Onderwijsplanning nov 2020', '32.00', '135.00', 21.00, '4320.00'),\
(370, 279, 0, 'Project management aanbesteding UAS dec 2020 ', '78.00', '95.00', 21.00, '7410.00'),\
(373, 280, 0, 'Programma man. Optimale Onderwijsplanning fase 1. dec 2020', '30.00', '135.00', 21.00, '4050.00'),\
(374, 281, 0, 'Projectmanagement DIrk Jan Durieux', '33.50', '115.00', 21.00, '3852.50'),\
(375, 281, 0, 'Projectmanagemt Shadya el Shafiy', '37.50', '115.00', 21.00, '4312.50'),\
(377, 282, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan dec 2020 ', '3.00', '135.00', 21.00, '405.00'),\
(378, 282, 0, 'Onderwijsvoorbereidingappl. Inzet Anne dec 2020', '1.50', '100.00', 21.00, '150.00'),\
(379, 283, 0, 'Advies dec 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(380, 284, 0, 'Advies december 2020', '1.00', '1600.00', 21.00, '1600.00'),\
(382, 286, 0, 'Projectbegeleiding adviesopdracht Aarhus GNK. nov/dec 2020', '8.00', '129.00', 21.00, '1032.00'),\
(383, 287, 0, 'DJ Durieux jan 2021', '38.50', '135.00', 21.00, '5197.50'),\
(384, 288, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan 2021 jan.', '7.50', '135.00', 21.00, '1012.50'),\
(385, 288, 0, 'Onderwijsvoorbereidingappl. Inzet Anne Jan  2021', '5.00', '100.00', 21.00, '500.00'),\
(386, 289, 0, 'Projectadvisering jan 2021', '3.00', '135.00', 21.00, '405.00'),\
(387, 290, 0, 'Programma advisering digital excellence for Education jan 2021 ', '4.00', '135.00', 21.00, '540.00'),\
(388, 291, 0, 'Inzet DJ Durieux jan 2021', '45.50', '115.00', 21.00, '5232.50'),\
(389, 291, 0, 'Inzet S. El Shafiy jan 2021', '105.00', '115.00', 21.00, '12075.00'),\
(390, 292, 0, 'Inzet DJ Durieux Aanbest UAS jan 2021', '44.00', '100.00', 21.00, '4400.00'),\
(392, 292, 0, 'Inzet de Kock Aanbest UAS jan 2021', '90.00', '100.00', 21.00, '9000.00'),\
(393, 294, 0, 'Advies januari 2021', '1.00', '1600.00', 21.00, '1600.00'),\
(394, 293, 0, 'Advies Januari A', '1.00', '1600.00', 21.00, '1600.00'),\
(395, 293, 0, 'Advies januari B', '1.00', '1600.00', 21.00, '1600.00'),\
(396, 295, 0, 'Projectmanagement DIrk Jan Durieux', '46.50', '115.00', 21.00, '5347.50'),\
(397, 295, 0, 'Projectmanagement Shadya el Shafiy', '118.50', '115.00', 21.00, '13627.50'),\
(398, 296, 0, 'Inzet DJ Durieux Aanbest UAS feb 2021', '30.00', '100.00', 21.00, '3000.00'),\
(399, 296, 0, 'Inzet de Kock Aanbest UAS feb 2021 ', '91.00', '100.00', 21.00, '9100.00'),\
(400, 297, 0, 'DJ Durieux feb 2021 ', '20.00', '135.00', 21.00, '2700.00'),\
(401, 298, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan 2021 feb.', '13.00', '135.00', 21.00, '1755.00'),\
(402, 299, 0, 'Advies feb A', '1.00', '1600.00', 21.00, '1600.00'),\
(403, 299, 0, 'Advies feb B', '1.00', '1600.00', 21.00, '1600.00'),\
(404, 300, 0, 'Advies 12 van 12', '1.00', '1600.00', 21.00, '1600.00'),\
(405, 300, 0, 'Advies jan en feb 76-46', '30.00', '20.00', 21.00, '600.00'),\
(406, 301, 0, 'Fee feb 2021', '46.00', '20.00', 21.00, '920.00'),\
(407, 302, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk  Jan mrt 2021', '21.00', '135.00', 21.00, '2835.00'),\
(408, 303, 0, 'Durieux maart 2021', '47.00', '135.00', 21.00, '6345.00'),\
(409, 304, 0, 'Inzet de Kock Aanbest UAS mrt 2021', '84.00', '100.00', 21.00, '8400.00'),\
(410, 304, 0, 'Inzet DJ Durieux Aanbest UAS mrt 2021', '27.00', '100.00', 21.00, '2700.00'),\
(411, 305, 0, 'Projectmanagement Shadya el Shafiy', '92.00', '115.00', 21.00, '10580.00'),\
(412, 305, 0, 'Projectmanagement DIrk Jan Durieux', '49.50', '115.00', 21.00, '5692.50'),\
(413, 306, 0, 'advies  maart A (12/12)', '1.00', '1600.00', 21.00, '1600.00'),\
(414, 306, 0, 'Advies maart B (3/10)', '1.00', '1600.00', 21.00, '1600.00'),\
(415, 307, 0, 'Fee maart 2021', '81.00', '20.00', 21.00, '1620.00'),\
(416, 308, 0, 'Fee Q1 2021 RU ', '73.50', '5.00', 21.00, '367.50'),\
(417, 309, 0, 'Bemiddeling maart 2021', '20.50', '20.00', 21.00, '410.00'),\
(418, 310, 0, 'Advies april 2021 (4/10)', '1.00', '1600.00', 21.00, '1600.00'),\
(419, 311, 0, 'Fee Q2 2021 RU', '39.00', '5.00', 21.00, '195.00'),\
(420, 311, 0, 'Fee Q1 RU additioneel ', '5.00', '5.00', 21.00, '25.00'),\
(421, 312, 0, 'Inzet Shadya april 2021 ', '60.00', '92.50', 21.00, '5550.00'),\
(422, 313, 0, 'Inzet DJ Durieux Aanbest UAS apr 2021', '21.00', '100.00', 21.00, '2100.00'),\
(423, 313, 0, 'Inzet de Kock Aanbest UAS apr 2021 ', '83.00', '100.00', 21.00, '8300.00'),\
(424, 314, 0, 'Projectmanagement Shadya el Shafiy', '65.00', '115.00', 21.00, '7475.00'),\
(425, 314, 0, 'Projectmanagement DIrk Jan Durieux', '23.00', '115.00', 21.00, '2645.00'),\
(426, 315, 0, 'Projectadvisering feb-april', '4.50', '135.00', 21.00, '607.50'),\
(427, 316, 0, 'Durieux april 2021', '55.50', '135.00', 21.00, '7492.50'),\
(428, 317, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan mrt 2021 ', '14.00', '135.00', 21.00, '1890.00'),\
(429, 318, 0, 'Projectmanagement Bart  Overbeek april 2021', '100.00', '125.00', 21.00, '12500.00'),\
(430, 319, 0, 'Inzet DJ Durieux Aanbest UAS mei 2021', '21.00', '100.00', 21.00, '2100.00'),\
(431, 319, 0, 'Inzet M. de Kock Aanbest UAS mei 2021', '84.00', '100.00', 21.00, '8400.00'),\
(432, 320, 0, 'Inzet Bart Overbeek in mei 2021', '24.00', '125.00', 21.00, '3000.00'),\
(433, 321, 0, 'Inzet Shadya mei2021', '67.00', '92.50', 21.00, '6197.50'),\
(434, 322, 0, 'Projectmanagement DIrk Jan Durieux', '29.50', '115.00', 21.00, '3392.50'),\
(435, 322, 0, 'Projectmanagement Shadya el Shafiy', '80.00', '115.00', 21.00, '9200.00'),\
(436, 323, 0, 'Onderwijsvoorbereidingappl. Inzet Dirk Jan mei 2021', '5.00', '135.00', 21.00, '675.00'),\
(437, 324, 0, 'Durieux mei 2021', '51.50', '135.00', 21.00, '6952.50'),\
(438, 325, 0, 'Projectmanagement Bart Overbeek mei 2021', '119.50', '125.00', 21.00, '14937.50'),\
(439, 326, 0, 'Inzet Dirk Jan mei 2021', '6.50', '125.00', 21.00, '812.50'),\
(441, 327, 0, 'Advies marktbewerking en positionering (5/10)', '1.00', '1600.00', 21.00, '1600.00'),\
(442, 328, 0, 'Bemiddeling april 57', '28.50', '20.00', 21.00, '570.00'),\
(443, 328, 0, 'Bemiddeling mei 57', '28.50', '20.00', 21.00, '570.00'),\
(444, 329, 0, 'Inzet Laura Martens mei 2021', '81.75', '70.00', 21.00, '5722.50'),\
(445, 330, 0, 'Inzet Marloes van Gent mei 2021', '44.00', '75.00', 21.00, '3300.00'),\
(446, 331, 0, 'Inzet DJ Durieux Aanbest UAS juni 2021', '15.00', '100.00', 21.00, '1500.00'),\
(447, 331, 0, 'Inzet M de Kock  Aanbest UAS juni 2021', '102.50', '100.00', 21.00, '10250.00'),\
(448, 332, 0, 'Inzet Bart Overbeek in juni 2021', '56.00', '125.00', 21.00, '7000.00'),\
(449, 333, 0, 'Projectmanagement Bart Overbeek juni 2021 (fase 2)', '105.50', '125.00', 21.00, '13187.50'),\
(450, 334, 0, 'Inzet Durieux Opt Onderwijsplanning juni 2021 (fase 2)', '51.00', '135.00', 21.00, '6885.00'),\
(451, 335, 0, 'Inzet Shadya mei2021', '64.00', '92.50', 21.00, '5920.00'),\
(452, 336, 0, 'Projectmanagement DIrk Jan Durieux', '28.50', '115.00', 21.00, '3277.50'),\
(453, 336, 0, 'Projectmanagement Shadya el Shafiy', '80.00', '115.00', 21.00, '9200.00'),\
(454, 337, 0, 'Advieswerkzaamheden Anne van Velden juni 2021', '9.00', '120.00', 21.00, '1080.00'),\
(455, 338, 0, 'bemiddeling juni |  26', '13.00', '20.00', 21.00, '260.00'),\
(456, 339, 0, 'Inzet Michiel Visser mei/juni 2021', '50.50', '90.00', 21.00, '4545.00'),\
(457, 339, 0, 'Reiskostenvergoeding', '950.00', '0.28', 21.00, '266.00'),\
(458, 340, 0, 'Advies marktbewerking en positionering (6/10) ', '1.00', '1600.00', 21.00, '1600.00'),\
(459, 341, 0, 'Inzet Laura Martens juni 2021', '110.00', '70.00', 21.00, '7700.00'),\
(460, 342, 0, 'Projectmanagement David ter Kuile juni 2021 ', '68.00', '120.00', 21.00, '8160.00'),\
(461, 343, 0, 'Inzet Marloes van Gent juni 2021 ', '72.00', '75.00', 21.00, '5400.00'),\
(462, 344, 0, 'Inzet Michiel Visser juli 2021', '26.00', '90.00', 21.00, '2340.00'),\
(463, 344, 0, 'Reiskostenvergoeding', '190.00', '0.28', 21.00, '53.20'),\
(464, 345, 0, 'Inzet DJ Durieux Aanbest UAS juli 2021', '12.00', '100.00', 21.00, '1200.00'),\
(465, 345, 0, 'Inzet M de Kock Aanbest UAS juli 2021', '60.00', '100.00', 21.00, '6000.00'),\
(466, 346, 0, 'Inzet Bart Overbeek in juli 2021 ', '11.00', '125.00', 21.00, '1375.00'),\
(467, 347, 0, 'Inzet Marloes van Gent juni 2021 ', '69.00', '75.00', 21.00, '5175.00'),\
(468, 348, 0, 'Projectmanagement DIrk Jan Durieux jul 21', '28.00', '115.00', 21.00, '3220.00'),\
(469, 348, 0, 'Projectmanagement Shadya el Shafiy jul 21', '100.00', '115.00', 21.00, '11500.00'),\
(470, 349, 0, 'Advies marktbewerking en positionering (6/10) ', '1.00', '1600.00', 21.00, '1600.00'),\
(471, 350, 0, 'Projectmanagement David ter Kuile juli 2021', '64.00', '120.00', 21.00, '7680.00'),\
(472, 351, 0, 'Inzet Petra ter Bekke Opt Ondplanning fase 3 juli 2021', '55.00', '100.00', 21.00, '5500.00'),\
(474, 352, 0, 'Inzet Bart Overbeek opt ondplanning juli 2021 fase 3', '102.50', '125.00', 21.00, '12812.50'),\
(475, 353, 0, 'Inzet Dirk Jan proj Opt Onderwijsplanning juli 2021 fase 3', '25.00', '135.00', 21.00, '3375.00'),\
(476, 354, 0, 'Inzet Laura Martens juli 2021', '86.00', '70.00', 21.00, '6020.00'),\
(477, 355, 0, 'Bemiddeling juli | 23', '11.50', '20.00', 21.00, '230.00'),\
(478, 356, 0, 'Inzet Petra Opt Ondplanning fase 3 inj juni 2021', '28.00', '100.00', 21.00, '2800.00'),\
(482, 358, 0, 'Advies marktbewerking en positionering (7/10)', '1.00', '1600.00', 21.00, '1600.00'),\
(483, 359, 0, 'Inzet Shadya aug 2021', '54.00', '92.50', 21.00, '4995.00'),\
(484, 360, 0, 'Projectmanagement Shadya el Shafiy aug 2021', '45.00', '115.00', 21.00, '5175.00'),\
(485, 360, 0, 'Projectmanagement Dirk Jan Durieux aug 2021', '35.00', '115.00', 21.00, '4025.00'),\
(486, 361, 0, 'Projectmanagement David ter Kuile aug 2021', '55.00', '120.00', 21.00, '6600.00'),\
(487, 362, 0, 'Inzet M de Kock Aanbest UAS aug 2021', '80.00', '100.00', 21.00, '8000.00'),\
(488, 362, 0, 'Inzet DJ Durieux Aanbest UAS aug 2021', '15.00', '100.00', 21.00, '1500.00'),\
(489, 363, 0, 'Inzet Laura Martens aug 2021', '77.50', '70.00', 21.00, '5425.00'),\
(490, 364, 0, 'Inzet Durieux Opt Onderwijsplanning aug 2021 (fase 3)', '37.00', '135.00', 21.00, '4995.00'),\
(491, 365, 0, 'Inzet Petra ter Bekke Opt Onderwijsplanning aug 2021 (fase 3)', '22.00', '100.00', 21.00, '2200.00'),\
(492, 366, 0, 'Inzet Bart Overbeek augustus 2021', '5.50', '125.00', 21.00, '687.50'),\
(493, 367, 0, 'Inzet Bart Overbeek project Aanbesteding Roosterapplicatie aug 2021', '33.00', '125.00', 21.00, '4125.00'),\
(494, 368, 0, 'Bemiddeling aug | 46', '23.00', '20.00', 21.00, '460.00'),\
(495, 369, 0, 'Inzet Marloes van Gent aug 2021', '48.00', '75.00', 21.00, '3600.00'),\
(496, 370, 28, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - sept 2021', '84.00', '100.00', 21.00, '8400.00'),\
(497, 371, 0, 'Inzet Shadya sept 2021', '20.00', '92.50', 21.00, '1850.00'),\
(498, 371, 0, 'Inzet Shadya sept 2021', '44.00', '95.00', 21.00, '4180.00'),\
(499, 372, 0, 'Projectmanagement Shadya el Shafiy sept 2021', '96.00', '115.00', 21.00, '11040.00'),\
(500, 373, 0, 'Inzet Bart Overbeek project Aanbesteding Roosterapplicatie sept 2021', '102.00', '125.00', 21.00, '12750.00'),\
(501, 374, 0, 'Projectmanagement David ter Kuile sept 2021', '65.00', '120.00', 21.00, '7800.00'),\
(502, 375, 0, 'Inzet M de Kock Aanbest UAS sept 2021', '72.00', '100.00', 21.00, '7200.00'),\
(503, 376, 0, 'Bemiddeling september | 30', '15.00', '20.00', 21.00, '300.00'),\
(504, 377, 0, 'Inzet Marloes van Gent sept 2021', '80.00', '75.00', 21.00, '6000.00'),\
(505, 378, 0, 'Inzet Laura Martens sept 2021', '108.00', '70.00', 21.00, '7560.00'),\
(506, 379, 0, 'Inzet DJ Durieux Aanbest UAS sept 2021', '11.00', '100.00', 21.00, '1100.00'),\
(507, 380, 0, 'Inzet Durieux Opt Onderwijsplanning sept 2021 (fase 3)', '34.00', '135.00', 21.00, '4590.00'),\
(510, 381, 0, 'Inzet Natalio Simon project Roostering in sept 2021', '104.00', '82.50', 21.00, '8580.00'),\
(511, 381, 0, 'Reiskosten Natalio Simon in sept 2021', '1242.00', '0.19', 21.00, '235.98'),\
(512, 382, 28, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - okt 2021', '89.00', '100.00', 21.00, '8900.00'),\
(513, 383, 0, 'Inzet M de Kock Aanbest UAS okt 2021', '92.00', '100.00', 21.00, '9200.00'),\
(514, 384, 0, 'Projectmanagement David ter Kuile okt 2021', '17.00', '120.00', 21.00, '2040.00'),\
(515, 385, 0, 'Inzet Marloes van Gent okt 2021', '67.00', '75.00', 21.00, '5025.00'),\
(516, 386, 0, 'Inzet Laura Martens okt 2021', '7.00', '70.00', 21.00, '490.00'),\
(517, 387, 0, 'Inzet Petra ter Bekke sept 2021', '22.00', '100.00', 21.00, '2200.00'),\
(518, 387, 0, 'Inzet Petra ter Bekke okt 2021', '38.00', '100.00', 21.00, '3800.00'),\
(519, 388, 0, 'Inzet DJ Durieux Aanbest UAS okt 2021', '11.00', '100.00', 21.00, '1100.00'),\
(520, 389, 0, 'Inzet Shadya okt 2021', '111.50', '115.00', 21.00, '12822.50'),\
(521, 390, 0, 'Inzet Shadya okt 2021', '48.50', '95.00', 21.00, '4607.50'),\
(522, 391, 0, 'Inzet Durieux Opt Onderwijsplanning okt 2021 (fase 3)', '19.50', '135.00', 21.00, '2632.50'),\
(523, 392, 0, 'Bemiddeling oktober | 31,00', '15.50', '20.00', 21.00, '310.00'),\
(530, 393, 0, 'Inzet Natalio Simon project Roostering in okt 2021', '156.00', '82.50', 21.00, '12870.00'),\
(531, 393, 0, 'Reiskosten Natalio Simon in okt 2021', '828.00', '0.19', 21.00, '157.32'),\
(532, 394, 0, 'Advies marktbewerking en positionering september', '1.00', '1600.00', 21.00, '1600.00'),\
(533, 395, 0, 'Inzet Bart Overbeek project Aanbesteding Roosterapplicatie okt 2021', '71.00', '125.00', 21.00, '8875.00'),\
(534, 396, 0, 'Inzet Bart Overbeek oktober 2021', '17.00', '125.00', 21.00, '2125.00'),\
(535, 396, 0, 'Inzet Bart Overbeek september 2021', '16.50', '125.00', 21.00, '2062.50'),\
(536, 394, 0, 'Advies marktbewerking en positionering oktober', '1.00', '1600.00', 21.00, '1600.00'),\
(537, 397, 0, 'Inzet Petra ter Bekke nov 2021', '51.00', '100.00', 21.00, '5100.00'),\
(538, 398, 0, 'Inzet Marloes van Gent nov 2021', '75.00', '75.00', 21.00, '5625.00'),\
(539, 399, 0, 'Inzet Bart Overbeek november 2021', '22.50', '125.00', 21.00, '2812.50'),\
(540, 400, 0, 'Inzet Bart Overbeek november 2021', '95.50', '125.00', 21.00, '11937.50'),\
(541, 401, 0, 'Advies marktbewerking en positionering november', '1.00', '1600.00', 21.00, '1600.00'),\
(542, 401, 0, 'Advies marktbewerking en positionering december (slot)', '1.00', '1600.00', 21.00, '1600.00'),\
(543, 402, 0, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - nov 2021', '106.00', '100.00', 21.00, '10600.00'),\
(544, 403, 0, 'Inzet Shadya nov 2021', '22.00', '95.00', 21.00, '2090.00'),\
(545, 404, 0, 'Projectmanagement Shadya el Shafiy nov 2021', '130.00', '115.00', 21.00, '14950.00'),\
(546, 405, 0, 'Inzet Natalio Simon project Roostering in nov 2021', '194.00', '82.50', 21.00, '16005.00'),\
(547, 405, 0, 'Reiskosten Natalio Simon in nov 2021', '828.00', '0.19', 21.00, '157.32'),\
(548, 406, 0, 'Inzet DJ Durieux nov 2021', '35.00', '135.00', 21.00, '4725.00'),\
(549, 407, 0, 'Projectmanagement Dirk Jan Durieux sept 2021', '20.50', '115.00', 21.00, '2357.50'),\
(550, 407, 0, 'Projectmanagement Dirk Jan Durieux okt 2021', '25.50', '115.00', 21.00, '2932.50'),\
(551, 407, 0, 'Projectmanagement Dirk Jan Durieux nov 2021', '10.00', '115.00', 21.00, '1150.00'),\
(552, 408, 0, 'Inzet DJ Durieux nov 2021', '10.00', '100.00', 21.00, '1000.00'),\
(553, 409, 0, 'Inzet M de Kock Aanbest UAS nov 2021', '96.00', '100.00', 21.00, '9600.00'),\
(554, 412, 0, 'Project management Shadya el Shafiy dec 2021', '82.00', '115.00', 21.00, '9430.00'),\
(555, 411, 0, 'Inzet Shadya dec 2021', '17.00', '95.00', 21.00, '1615.00'),\
(556, 413, 0, 'Inzet M de Kock Aanbest UAS dec 2021', '94.00', '100.00', 21.00, '9400.00'),\
(557, 414, 0, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - dec 2021', '88.00', '100.00', 21.00, '8800.00'),\
(558, 415, 0, 'Inzet Marloes van Gent dec 2021', '70.00', '75.00', 21.00, '5250.00'),\
(559, 416, 0, 'Inzet Bart Overbeek december 2021', '24.50', '125.00', 21.00, '3062.50'),\
(560, 417, 0, 'Inzet Bart Overbeek project Aanbesteding Roosterapplicatie dec 2021', '74.50', '125.00', 21.00, '9312.50'),\
(561, 418, 0, 'Projectmanagement Dirk Jan Durieux dec 2021', '10.50', '115.00', 21.00, '1207.50'),\
(562, 419, 0, 'Inzet DJ Durieux dec 2021', '7.00', '100.00', 21.00, '700.00'),\
(563, 420, 0, 'Inzet DJ Durieux dec 2021', '30.00', '135.00', 21.00, '4050.00'),\
(564, 421, 0, 'Inzet Petra ter Bekke nov 2021', '30.00', '100.00', 21.00, '3000.00'),\
(566, 422, 0, 'Inzet Natalio Simon project Roostering dec 2021', '140.00', '82.50', 21.00, '11550.00'),\
(567, 423, 0, 'Bemiddeling december | 24,00', '12.00', '20.00', 21.00, '240.00'),\
(568, 424, 0, 'Bemiddeling november | 20,00', '10.00', '20.00', 21.00, '200.00'),\
(569, 425, 0, 'Project management Shadya el Shafiy jan 2022', '68.00', '115.00', 21.00, '7820.00'),\
(570, 426, 0, 'Inzet Shadya Programma uitbreiding digitale toetscapaciteit jan 2021', '40.00', '97.50', 21.00, '3900.00'),\
(571, 427, 0, 'Inzet M de Kock Aanbest UAS jan 2022', '111.00', '105.00', 21.00, '11655.00'),\
(572, 428, 0, 'Inzet DJ Durieux jan 2022', '28.50', '135.00', 21.00, '3847.50'),\
(573, 429, 0, 'Inzet Bart Overbeek project Aanbesteding Roosterapplicatie jan 2022', '83.00', '125.00', 21.00, '10375.00'),\
(574, 430, 0, 'Inzet Bart Overbeek januari 2022', '10.00', '125.00', 21.00, '1250.00'),\
(575, 431, 0, 'Inzet Marloes van Gent jan 2022', '87.00', '75.00', 21.00, '6525.00'),\
(576, 432, 0, 'Inzet Tessa Jansen jan 2022', '18.50', '75.00', 21.00, '1387.50'),\
(577, 432, 0, 'Inzet DJ Durieux jan 2022', '12.00', '135.00', 21.00, '1620.00'),\
(578, 433, 0, 'Projectmanagement Dirk Jan Durieux jan 2022', '16.00', '115.00', 21.00, '1840.00'),\
(579, 434, 0, 'Inzet Natalio Simon project Roostering jan 2022', '103.00', '82.50', 21.00, '8497.50'),\
(580, 434, 0, 'Reiskosten Natalio Simon in jan 2022', '414.00', '0.19', 21.00, '78.66'),\
(581, 435, 0, 'Inzet DJ Durieux Aanbest UAS jan 2022', '10.00', '105.00', 21.00, '1050.00'),\
(582, 437, 0, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - jan 2022', '98.00', '97.50', 21.00, '9555.00'),\
(583, 436, 0, 'Inzet Tessa Jansen jan 2022', '78.00', '105.00', 21.00, '8190.00'),\
(585, 438, 23, 'TESTOverigen', '-1.00', '20.00', 24.00, '-20.00'),\
(586, 438, 23, 'Overigen Test 2', '1.00', '-20.00', 21.00, '-20.00'),\
(587, 439, 0, 'Test', '1.00', '1.00', 2.00, '1.00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoiceline_mistral`\
--\
\
CREATE TABLE `invoiceline_mistral` (\
  `id` int(11) NOT NULL,\
  `invoice_id` int(11) DEFAULT NULL,\
  `subscription_id` int(11) NOT NULL,\
  `subject` varchar(100) NOT NULL,\
  `quantity` decimal(10,2) NOT NULL,\
  `price_per_quantity` decimal(10,2) NOT NULL,\
  `tax_rate` float(5,2) NOT NULL,\
  `price` decimal(10,2) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoiceline_mistral`\
--\
\
INSERT INTO `invoiceline_mistral` (`id`, `invoice_id`, `subscription_id`, `subject`, `quantity`, `price_per_quantity`, `tax_rate`, `price`) VALUES\
(2, 2, 0, 'inzet DJ Durieux juni 2021', '53.00', '125.00', 21.00, '6625.00'),\
(3, 2, 0, 'inzet P. ter Bekke juni 2021', '18.00', '105.00', 21.00, '1890.00'),\
(4, 2, 0, 'inzet L. Martens juni 2021', '28.50', '75.00', 21.00, '2137.50'),\
(5, 3, 0, 'Inzet DJD Durieux juli 2021', '40.50', '125.00', 21.00, '5062.50'),\
(6, 3, 0, 'inzet P. ter Bekke juli 2021', '48.00', '105.00', 21.00, '5040.00'),\
(7, 3, 0, 'Inzet L. Martens juli 2021', '40.50', '75.00', 21.00, '3037.50'),\
(8, 4, 0, 'Inzet DJ Durieux aug 2021', '38.00', '125.00', 21.00, '4750.00'),\
(9, 4, 0, 'Inzet L Martens aug 2021', '24.50', '75.00', 21.00, '1837.50'),\
(10, 5, 0, 'Inzet Petra ter Bekke Project Onderwijsplanning 2030 ', '18.00', '105.00', 21.00, '1890.00'),\
(11, 6, 0, 'Inzet Laura Martens sept 2021', '44.00', '75.00', 21.00, '3300.00'),\
(12, 7, 0, 'management fee 3e kwartaal 2021', '1.00', '15000.00', 21.00, '15000.00'),\
(13, 7, 0, 'management fee 4e kwartaal 2021', '1.00', '15000.00', 21.00, '15000.00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoiceline_new`\
--\
\
CREATE TABLE `invoiceline_new` (\
  `id` int(11) NOT NULL,\
  `invoice_id` int(11) DEFAULT NULL,\
  `subscription_id` int(11) NOT NULL,\
  `subject` varchar(100) NOT NULL,\
  `quantity` decimal(10,2) NOT NULL,\
  `price_per_quantity` decimal(10,2) NOT NULL,\
  `tax_rate` float(5,2) NOT NULL,\
  `price` decimal(10,2) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoiceline_new`\
--\
\
INSERT INTO `invoiceline_new` (`id`, `invoice_id`, `subscription_id`, `subject`, `quantity`, `price_per_quantity`, `tax_rate`, `price`) VALUES\
(1, 1, 0, 'Test product', '2.00', '0.01', 21.00, '0.02'),\
(2, 2, 0, 'Projectinzet Saskia de Munnik in sept 2021', '1.00', '100.00', 21.00, '100.00'),\
(3, 3, 0, 'Inzet M Visser Procesregisseur Tentaminering sept 2021', '47.50', '110.00', 21.00, '5225.00'),\
(4, 4, 0, 'Inzet DJ Durieux sept 2021', '59.00', '125.00', 21.00, '7375.00'),\
(5, 5, 0, 'Inzet Janneke van Esch sept 2021', '32.00', '75.00', 21.00, '2400.00'),\
(6, 6, 0, 'Inzet Saskia de Munnik sept 2021', '5.00', '100.00', 21.00, '500.00'),\
(7, 7, 0, 'Inzet DJ Durieux project Audit Impl. Roosterapplicatie sept/okt 2021', '20.50', '140.00', 21.00, '2870.00'),\
(8, 7, 0, 'Inzet P. ter Bekker project Audit Impl. Roosterapplicatie sept/okt 2021', '21.00', '75.00', 21.00, '1575.00'),\
(9, 8, 0, 'Inzet Laura Martens okt 2021', '46.00', '75.00', 21.00, '3450.00'),\
(10, 8, 0, 'Inzet Saskia de Munnik okt 2021', '7.00', '100.00', 21.00, '700.00'),\
(11, 9, 0, 'Inzet Saskia de Munnik okt 2021', '1.00', '100.00', 21.00, '100.00'),\
(12, 8, 0, 'Inzet Janneke van Esch okt 2021', '78.00', '75.00', 21.00, '5850.00'),\
(13, 8, 0, 'inzet Saskia de Munnik okt 2021 (LLO)', '7.00', '100.00', 21.00, '700.00'),\
(15, 8, 0, 'Inzet Petra ter Bekke okt 2021', '33.00', '105.00', 21.00, '3465.00'),\
(16, 10, 0, 'Inzet Petra ter Bekke sept 2021', '29.00', '105.00', 21.00, '3045.00'),\
(17, 11, 0, 'Inzet Janneke van Esch okt 2021', '15.00', '75.00', 21.00, '1125.00'),\
(18, 8, 0, 'Inzet DJ Durieux okt 2021', '44.00', '125.00', 21.00, '5500.00'),\
(19, 12, 0, 'Inzet M Visser Procesregisseur Tentaminering okt 2021', '38.50', '110.00', 21.00, '4235.00'),\
(20, 13, 0, 'Inzet Petra ter Bekke nov 2021', '49.00', '105.00', 21.00, '5145.00'),\
(21, 13, 0, 'Inzet Saskia de Munnik november 2021', '3.00', '100.00', 21.00, '300.00'),\
(22, 14, 0, 'Inzet Saskia de Munnik november 2021', '4.00', '100.00', 21.00, '400.00'),\
(23, 13, 0, 'inzet Saskia de Munnik nov 2021 (LLO)', '17.00', '100.00', 21.00, '1700.00'),\
(25, 15, 0, 'Inzet Saskia de Munnik nov 2021', '25.00', '100.00', 21.00, '2500.00'),\
(26, 13, 0, 'Inzet Laura Martens nov 2021', '93.50', '75.00', 21.00, '7012.50'),\
(27, 13, 0, 'Inzet Janneke van Esch nov 2021', '84.00', '75.00', 21.00, '6300.00'),\
(28, 16, 0, 'Inzet Janneke van Esch nov 2021', '24.00', '75.00', 21.00, '1800.00'),\
(29, 17, 0, 'Inzet M Visser Procesregisseur Tentaminering nov 2021', '61.50', '110.00', 21.00, '6765.00'),\
(30, 13, 0, 'Inzet DJ Durieux nov 2021', '69.00', '125.00', 21.00, '8625.00'),\
(31, 18, 0, 'Inzet P Rotteveel Project vervanging LMS nov 2021', '56.00', '125.00', 21.00, '7000.00'),\
(32, 19, 0, 'Inzet M Visser Procesregisseur Tentaminering dec 2021', '49.00', '110.00', 21.00, '5390.00'),\
(33, 20, 0, 'Inzet DJ Durieux dec 2021', '53.00', '125.00', 21.00, '6625.00'),\
(34, 20, 0, 'Inzet Janneke van Esch dec 2021', '88.00', '75.00', 21.00, '6600.00'),\
(35, 21, 0, 'Inzet Janneke van Esch dec 2021', '12.00', '75.00', 21.00, '900.00'),\
(36, 20, 0, 'Inzet Laura Martens dec 2021', '143.00', '75.00', 21.00, '10725.00'),\
(37, 20, 0, 'Inzet Petra ter Bekke dec 2021', '21.00', '105.00', 21.00, '2205.00'),\
(38, 20, 0, 'Inzet Saskia de Munnik dec 2021', '13.00', '100.00', 21.00, '1300.00'),\
(39, 22, 0, 'Inzet Saskia de Munnik dec 2021', '6.00', '100.00', 21.00, '600.00'),\
(40, 23, 0, 'Inzet P Rotteveel Project vervanging LMS dec 2021', '64.00', '125.00', 21.00, '8000.00'),\
(41, 24, 0, 'Inzet M Visser Procesregisseur Tentaminering jan 2022', '55.00', '110.00', 21.00, '6050.00'),\
(42, 25, 0, 'Inzet Laura Martens jan 2022', '158.50', '75.00', 21.00, '11887.50'),\
(43, 25, 0, 'Inzet DJ Durieux jan 2022', '59.00', '125.00', 21.00, '7375.00'),\
(44, 25, 0, 'inzet Saskia de Munnik jan 2022 (LLO)', '15.00', '100.00', 21.00, '1500.00'),\
(45, 26, 0, 'Inzet Saskia de Munnik jan 2022', '16.00', '100.00', 21.00, '1600.00'),\
(46, 25, 0, 'Inzet Janneke van Esch jan 2022', '94.00', '75.00', 21.00, '7050.00'),\
(47, 27, 0, 'Inzet Janneke van Esch jan 2022', '10.00', '75.00', 21.00, '750.00'),\
(48, 28, 0, 'Inzake rapport Oplossingsrichtingen capaciteitstekort ....', '22.00', '100.00', 21.00, '2200.00'),\
(49, 29, 0, 'Inzet P Rotteveel Project vervanging LMS jan 2022', '43.00', '125.00', 21.00, '5375.00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoices`\
--\
\
CREATE TABLE `invoices` (\
  `id` int(11) NOT NULL,\
  `invoice_type` tinyint(1) NOT NULL COMMENT '''0 FOR MEMBER'',''1 FOR COMPANY''',\
  `member_id` int(11) UNSIGNED DEFAULT NULL,\
  `subscription_id` varchar(255) DEFAULT NULL,\
  `date` datetime NOT NULL,\
  `number` varchar(20) NOT NULL,\
  `amount` decimal(10,2) NOT NULL,\
  `amount_tax` decimal(10,2) NOT NULL,\
  `reference` varchar(200) NOT NULL,\
  `payment_date` datetime NOT NULL,\
  `mollie_payment_id` varchar(50) NOT NULL,\
  `company_id` int(10) UNSIGNED DEFAULT NULL,\
  `contact_person_id` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoices`\
--\
\
INSERT INTO `invoices` (`id`, `invoice_type`, `member_id`, `subscription_id`, `date`, `number`, `amount`, `amount_tax`, `reference`, `payment_date`, `mollie_payment_id`, `company_id`, `contact_person_id`) VALUES\
(15, 1, NULL, NULL, '2015-02-16 00:00:00', '2015001', '350.00', '423.50', 'Abonnement jan 2015 ', '2015-01-08 00:00:00', '', 6, 4),\
(16, 1, NULL, NULL, '2015-02-17 00:00:00', '2015002', '402.00', '486.42', 'Abonnement feb + lunch jan 2015 ', '2015-02-23 00:00:00', '', 6, 4),\
(17, 1, NULL, NULL, '2015-02-17 00:00:00', '2015003', '525.00', '635.25', 'Uren ondersteuning in januari 2015', '2015-02-27 00:00:00', '', 7, 5),\
(18, 1, NULL, NULL, '2015-02-17 00:00:00', '2015004', '100.00', '121.00', 'Bijdrage aan Borrel 19-2-2015', '2015-02-24 00:00:00', '', 8, 6),\
(31, 1, NULL, NULL, '2015-02-17 00:00:00', '2015017', '40.00', '48.40', 'Gezamenlijke netwerkbijeenkomst 23-1-2015', '2015-04-10 00:00:00', '', 10, 8),\
(32, 1, NULL, NULL, '2015-03-01 00:00:00', '2015018', '350.00', '423.50', 'Abonnement maart 2015', '2015-04-20 00:00:00', '', 6, 11),\
(33, 1, NULL, NULL, '2015-03-01 00:00:00', '2015019', '665.00', '804.65', 'Ondersteuning febr 2015', '2015-04-12 00:00:00', 'tr_6gSRPadvSu', 7, 5),\
(34, 1, NULL, NULL, '2015-02-18 00:00:00', '2015020', '178.50', '215.99', 'Lunch en koffie feb 2015', '2015-04-20 00:00:00', 'tr_QCGRpL9pjy', 6, 11),\
(36, 1, NULL, NULL, '2015-03-01 00:00:00', '2015022', '2550.00', '2550.00', 'Project Management Jan & Feb 2015 ', '0000-00-00 00:00:00', 'tr_3XBXAPqXhX', 12, 10),\
(37, 1, NULL, NULL, '2015-04-01 00:00:00', '2015023', '193.00', '233.53', 'Lunches & koffie mrt 2015', '2015-04-08 00:00:00', '', 6, 4),\
(38, 1, NULL, NULL, '2015-04-01 00:00:00', '2015024', '350.00', '423.50', 'lidmaatschap april 2015', '2015-04-08 00:00:00', '', 6, 4),\
(39, 1, NULL, NULL, '2015-04-01 00:00:00', '2015025', '717.50', '868.18', 'Secr. ondersteuning maart 2015', '2015-04-07 00:00:00', '', 7, 5),\
(40, 1, NULL, NULL, '2015-04-01 00:00:00', '2015026', '850.00', '850.00', 'Final invoice Project management ', '0000-00-00 00:00:00', '', 12, 10),\
(41, 1, NULL, NULL, '2015-05-11 00:00:00', '2015027', '80.00', '96.80', 'secr. ondersteuning', '2015-05-18 00:00:00', '', 7, 5),\
(44, 1, NULL, NULL, '2015-05-11 00:00:00', '2015030', '12.00', '14.52', 'lunches april', '2015-05-20 00:00:00', '', 16, 12),\
(45, 1, NULL, NULL, '2015-05-11 00:00:00', '2015031', '132.00', '159.72', 'lunch en koffie april 2015', '2015-05-22 00:00:00', '', 6, 4),\
(46, 1, NULL, NULL, '2015-05-12 00:00:00', '2015032', '350.00', '423.50', 'Abonnement mei 2015', '0000-00-00 00:00:00', '', 6, 11),\
(47, 1, NULL, NULL, '2015-06-05 00:00:00', '2015033', '150.00', '181.50', 'Unblocking Experience Tour', '2015-06-18 00:00:00', '', 18, 14),\
(48, 1, NULL, NULL, '2015-05-29 00:00:00', '2015034', '350.00', '423.50', 'Abonnement juni 2015', '2015-06-08 00:00:00', '', 6, 11),\
(49, 1, NULL, NULL, '2015-05-29 00:00:00', '2015035', '168.00', '203.28', 'Lunches en koffie april & mei 2015', '2015-06-08 00:00:00', '', 6, 11),\
(50, 1, NULL, NULL, '2015-07-06 00:00:00', '2015036', '152.00', '183.92', 'Lunches en koffie juni', '0000-00-00 00:00:00', '', 6, 11),\
(51, 1, NULL, NULL, '2015-05-29 00:00:00', '2015037', '48.00', '58.08', 'Lunches mei', '2015-06-15 00:00:00', '', 16, 12),\
(52, 1, NULL, NULL, '2015-06-30 00:00:00', '2015038', '3600.00', '3600.00', 'Masterclasses voorjaar 2015', '0000-00-00 00:00:00', '', 19, 15),\
(53, 1, NULL, NULL, '2015-06-30 00:00:00', '2015039', '600.00', '726.00', 'gebruik flexplekken juni - juli 2015', '0000-00-00 00:00:00', '', 16, 12),\
(54, 1, NULL, NULL, '2015-06-30 00:00:00', '2015040', '850.00', '850.00', 'Contract management ORIO ', '0000-00-00 00:00:00', '', 12, 10),\
(55, 1, NULL, NULL, '2015-07-01 00:00:00', '2015041', '2000.00', '2000.00', 'Bootcamp ondernemerschap iLab ', '0000-00-00 00:00:00', '', 20, 16),\
(56, 1, NULL, NULL, '2015-07-06 00:00:00', '2015042', '198.00', '239.58', 'Lunches en koffie juni 2015', '0000-00-00 00:00:00', '', 16, 12),\
(57, 1, NULL, NULL, '2015-07-06 00:00:00', '2015043', '100.00', '121.00', 'Bijdrage borrel 2-7-1015', '0000-00-00 00:00:00', '', 8, 6),\
(58, 1, NULL, NULL, '2015-07-15 00:00:00', '2015044', '5905.50', '5905.50', 'Downpayment business plan development', '0000-00-00 00:00:00', '', 12, 10),\
(59, 1, NULL, NULL, '2015-08-01 00:00:00', '2015045', '350.00', '423.50', 'Altijd welkom lidmaatschap augustus 2015', '0000-00-00 00:00:00', '', 16, 12),\
(60, 1, NULL, NULL, '2012-08-01 00:00:00', '2015046', '350.00', '423.50', 'Altijd welkom Lidmaatschap aug 2015', '0000-00-00 00:00:00', '', 17, 17),\
(68, 1, NULL, NULL, '2015-09-02 00:00:00', '2015054', '2125.00', '2125.00', 'contract management juli-aug 2015', '0000-00-00 00:00:00', '', 12, 10),\
(69, 1, NULL, NULL, '2015-09-02 00:00:00', '2015055', '6975.00', '6975.00', '50 percent interim payment business plan', '0000-00-00 00:00:00', '', 12, 10),\
(70, 1, NULL, NULL, '2015-09-01 00:00:00', '2015056', '350.00', '423.50', 'Lidmaatschap september 2015', '0000-00-00 00:00:00', '', 16, 12),\
(71, 1, NULL, NULL, '2015-09-01 00:00:00', '2015057', '350.00', '423.50', 'Lidmaatschap september 2015', '0000-00-00 00:00:00', '', 17, 17),\
(72, 1, NULL, NULL, '2015-09-03 00:00:00', '2015058', '100.00', '121.00', 'Flexplek sept 2015', '0000-00-00 00:00:00', '', 21, 18),\
(74, 1, NULL, NULL, '2015-09-24 00:00:00', '2015060', '160.00', '193.60', 'Coachgesprekken', '0000-00-00 00:00:00', '', 22, 19),\
(75, 1, NULL, NULL, '2015-10-05 00:00:00', '2015061', '316.75', '383.27', 'Lidmaatschap oktober 2015', '0000-00-00 00:00:00', '', 16, 12),\
(76, 1, NULL, NULL, '2015-10-05 00:00:00', '2015062', '350.00', '423.50', 'Lidmaatschap Oktober 2015', '0000-00-00 00:00:00', '', 17, 17),\
(78, 1, NULL, NULL, '2015-10-06 00:00:00', '2015064', '1700.00', '1700.00', 'Contract management September 2015', '0000-00-00 00:00:00', '', 12, 10),\
(79, 1, NULL, NULL, '2015-10-09 00:00:00', '2015065', '6936.38', '6936.38', '25% final payment + ticket', '0000-00-00 00:00:00', '', 12, 10),\
(80, 1, NULL, NULL, '2015-10-13 00:00:00', '2015066', '100.00', '121.00', 'Flexplek oktober 2015', '0000-00-00 00:00:00', '', 21, 18),\
(81, 1, NULL, NULL, '2015-10-15 00:00:00', '2015067', '222.51', '269.24', 'Materialen opknap spreekkamer H1', '0000-00-00 00:00:00', '', 23, 20),\
(82, 1, NULL, NULL, '2015-11-02 00:00:00', '2015068', '350.00', '423.50', 'Lidmaatschap november 2015', '0000-00-00 00:00:00', '', 16, 12),\
(83, 1, NULL, NULL, '2015-11-02 00:00:00', '2015069', '350.00', '423.50', 'Lidmaatschap november 2015', '0000-00-00 00:00:00', '', 17, 17),\
(84, 1, NULL, NULL, '2015-11-02 00:00:00', '2015070', '100.00', '121.00', 'Flexplek oktober 2015', '0000-00-00 00:00:00', '', 21, 18),\
(85, 1, NULL, NULL, '2015-11-03 00:00:00', '2015071', '1600.00', '1936.00', 'Bijdrage begeleiding starters Pressure Cooker', '0000-00-00 00:00:00', '', 24, 21),\
(86, 1, NULL, NULL, '2015-11-23 00:00:00', '2015072', '8780.83', '8780.83', 'works oct-nov 2015', '0000-00-00 00:00:00', '', 12, 10),\
(87, 1, NULL, NULL, '2015-12-04 00:00:00', '2015073', '2000.00', '2000.00', 'Masterclass Ondernemen Basis', '0000-00-00 00:00:00', '', 19, 15),\
(88, 1, NULL, NULL, '2015-12-04 00:00:00', '2015074', '4000.00', '4840.00', 'Startersplatform Deloitte-IncZwolle', '0000-00-00 00:00:00', '', 26, 29),\
(89, 1, NULL, NULL, '2015-12-07 00:00:00', '2015075', '350.00', '423.50', 'Lidmaatschap december 2015', '0000-00-00 00:00:00', '', 17, 17),\
(90, 1, NULL, NULL, '2015-12-07 00:00:00', '2015076', '100.00', '121.00', 'Flexplek dec 2015', '0000-00-00 00:00:00', '', 21, 18),\
(91, 1, NULL, NULL, '2015-12-07 00:00:00', '2015077', '350.00', '423.50', 'Lidmaatschap december 2015', '0000-00-00 00:00:00', '', 16, 12),\
(92, 1, NULL, NULL, '2015-12-07 00:00:00', '2015078', '300.00', '363.00', 'Bijdrage masterclasses Starterscompetitie', '0000-00-00 00:00:00', '', 27, 27),\
(101, 1, NULL, NULL, '2016-01-01 00:00:00', '2015087', '350.00', '423.50', 'Lidmaatschap januari 2016', '0000-00-00 00:00:00', '', 16, 12),\
(102, 1, NULL, NULL, '2016-01-01 00:00:00', '2015088', '350.00', '423.50', 'Lidmaatschap januari 2016', '0000-00-00 00:00:00', '', 17, 17),\
(103, 1, NULL, NULL, '2016-01-01 00:00:00', '2015089', '90.00', '108.90', 'Stippenkaart 6 flexplek ', '0000-00-00 00:00:00', '', 37, 45),\
(104, 1, NULL, NULL, '2016-01-01 00:00:00', '2015090', '100.00', '121.00', 'Lidmaatschap jan 2016', '0000-00-00 00:00:00', '', 21, 18),\
(105, 1, NULL, NULL, '2016-01-04 00:00:00', '201600001', '900.00', '1089.00', 'Bijdrage begeleiding starters Pressure Cooker', '0000-00-00 00:00:00', '', 24, 21),\
(106, 1, NULL, NULL, '2016-01-08 00:00:00', '2016001', '385.00', '465.85', 'Gerard de Jong, ICT', '0000-00-00 00:00:00', '', 42, 49),\
(107, 1, NULL, NULL, '2016-02-02 00:00:00', '2016002', '150.00', '181.50', 'Coachingstraject januari 2016', '0000-00-00 00:00:00', '', 47, 56),\
(110, 1, NULL, NULL, '2016-02-02 00:00:00', '2016005', '350.00', '423.50', 'Lidmaatschap feb 2016', '0000-00-00 00:00:00', '', 17, 17),\
(111, 1, NULL, NULL, '2016-02-02 00:00:00', '2016006', '350.00', '423.50', 'Lidmaatschap feb 2016', '0000-00-00 00:00:00', '', 16, 12),\
(112, 1, NULL, NULL, '2016-02-04 00:00:00', '2016007', '1275.00', '1275.00', 'Revisions business plan', '0000-00-00 00:00:00', '', 12, 10),\
(113, 1, NULL, NULL, '2016-03-04 00:00:00', '2016008', '350.00', '423.50', 'Lidmaatschap maart 2016', '0000-00-00 00:00:00', '', 17, 17),\
(114, 1, NULL, NULL, '2016-03-04 00:00:00', '2016009', '350.00', '423.50', 'Lidmaatschap maart 2016', '0000-00-00 00:00:00', '', 16, 12),\
(116, 1, NULL, NULL, '2016-03-04 00:00:00', '2016011', '10907.71', '13198.33', 'Interim opdracht VU Amsterdam feb 2016', '0000-00-00 00:00:00', '', 49, 58),\
(117, 1, NULL, NULL, '2016-04-01 00:00:00', '2016012', '12421.22', '15029.68', 'Interim opdracht VU Amsterdam maart-16', '0000-00-00 00:00:00', '', 49, 58),\
(118, 1, NULL, NULL, '2016-04-01 00:00:00', '2016013', '500.00', '605.00', 'Lidmaatschap april 2016', '0000-00-00 00:00:00', '', 16, 12),\
(119, 1, NULL, NULL, '2016-04-01 00:00:00', '2016014', '350.00', '423.50', 'Lidmaatschap april 2016', '0000-00-00 00:00:00', '', 17, 17),\
(120, 1, NULL, NULL, '2016-04-01 00:00:00', '2016015', '150.00', '181.50', 'coaching feb 2016', '0000-00-00 00:00:00', '', 47, 56),\
(121, 1, NULL, NULL, '2016-04-25 00:00:00', '2016016', '2000.00', '2000.00', 'Masterclass Ondernemen voorjaar 2016', '0000-00-00 00:00:00', '', 19, 15),\
(122, 1, NULL, NULL, '2016-05-01 00:00:00', '2016017', '15500.43', '18755.52', 'Interim opdracht VU Amsterdam', '0000-00-00 00:00:00', '', 49, 58),\
(123, 1, NULL, NULL, '2016-05-01 00:00:00', '2016018', '650.00', '786.50', 'Lidmaatschap mei 2016', '0000-00-00 00:00:00', '', 16, 12),\
(124, 1, NULL, NULL, '2016-05-01 00:00:00', '2016019', '350.00', '423.50', 'Lidmaatschap mei 2016', '0000-00-00 00:00:00', '', 17, 17),\
(125, 1, NULL, NULL, '2016-05-01 00:00:00', '2016020', '150.00', '181.50', 'Coaching april 2016', '0000-00-00 00:00:00', '', 47, 56),\
(126, 1, NULL, NULL, '2016-05-30 00:00:00', '2016021', '500.00', '605.00', 'Afspraken mail 8 april 2016', '0000-00-00 00:00:00', '', 50, 61),\
(127, 1, NULL, NULL, '2016-06-01 00:00:00', '2016022', '11899.32', '14398.18', 'Werkzaamheden mei 2016', '0000-00-00 00:00:00', '', 49, 58),\
(128, 1, NULL, NULL, '2016-06-06 00:00:00', '2016023', '650.00', '786.50', 'Lidmaatschap juni 2016', '0000-00-00 00:00:00', '', 16, 12),\
(129, 1, NULL, NULL, '2016-06-06 00:00:00', '2016024', '350.00', '423.50', 'Lidmaatschap juni 2016', '0000-00-00 00:00:00', '', 17, 17),\
(130, 1, NULL, NULL, '2016-06-07 00:00:00', '2016025', '120.00', '145.20', 'Coaching mei 2016', '0000-00-00 00:00:00', '', 47, 56),\
(131, 1, NULL, NULL, '2016-07-01 00:00:00', '2016026', '650.00', '786.50', 'Lidmaatschap juli 2016', '0000-00-00 00:00:00', '', 16, 12),\
(132, 1, NULL, NULL, '2016-07-01 00:00:00', '2016027', '350.00', '423.50', 'Lidmaatschap juli 2016', '0000-00-00 00:00:00', '', 17, 17),\
(133, 1, NULL, NULL, '2016-07-01 00:00:00', '2016028', '14050.00', '17000.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(134, 1, NULL, NULL, '2016-08-01 00:00:00', '2016029', '7150.00', '8651.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(135, 1, NULL, NULL, '2016-09-01 00:00:00', '2016030', '8600.00', '10406.00', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(136, 1, NULL, NULL, '2016-10-01 00:00:00', '2016031', '13250.00', '16032.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(137, 1, NULL, NULL, '2016-10-26 00:00:00', '2016032', '1000.00', '1210.00', 'Reparatie en onderhoud decanendatabase', '0000-00-00 00:00:00', '', 42, 49),\
(138, 1, NULL, NULL, '2016-11-01 00:00:00', '2016033', '13600.00', '16456.00', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(139, 1, NULL, NULL, '2016-11-23 00:00:00', '2016034', '-75.00', '-90.75', 'Credit nota op 2016013', '0000-00-00 00:00:00', '', 16, 12),\
(140, 1, NULL, NULL, '2016-12-01 00:00:00', '2016035', '15100.00', '18271.00', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(141, 0, 15, NULL, '2017-01-03 00:00:00', '201700001', '0.00', '0.00', 'vervallen factuur ivm doornummering', '0000-00-00 00:00:00', '', NULL, NULL),\
(142, 1, NULL, NULL, '2017-01-01 00:00:00', '2017001', '9750.00', '11797.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(143, 1, NULL, NULL, '2016-01-30 00:00:00', '2017002', '908.61', '1099.42', 'Ticket Austin mrt 2017', '0000-00-00 00:00:00', '', 7, 5),\
(144, 1, NULL, NULL, '2017-02-01 00:00:00', '2017003', '11650.00', '14096.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(145, 1, NULL, NULL, '2017-03-01 00:00:00', '2017004', '11700.00', '14157.00', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(146, 1, NULL, NULL, '2017-04-01 00:00:00', '2017005', '13850.00', '16758.50', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(147, 1, NULL, NULL, '2017-05-01 00:00:00', '2017006', '10100.00', '12221.00', 'Project VU - Dirk Jan Durieux (007976/01)', '0000-00-00 00:00:00', '', 51, 62),\
(148, 1, NULL, NULL, '2017-05-29 00:00:00', '2017007', '2000.00', '2420.00', 'Masterclass Ondernemen maart-april-mei 2017', '0000-00-00 00:00:00', '', 19, 15),\
(149, 1, NULL, NULL, '2017-06-01 00:00:00', '2017008', '15400.00', '18634.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(150, 1, NULL, NULL, '2017-07-01 00:00:00', '2017009', '14550.00', '17605.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(151, 1, NULL, NULL, '2017-07-31 00:00:00', '2017010', '8500.00', '10285.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(152, 1, NULL, NULL, '2017-09-01 00:00:00', '2017011', '4950.00', '5989.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(153, 1, NULL, NULL, '2017-10-02 00:00:00', '2017012', '14250.00', '17242.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(154, 1, NULL, NULL, '2017-10-16 00:00:00', '2017013', '1000.00', '1210.00', 'Coaching traject Lida/Annemiek', '0000-00-00 00:00:00', '', 19, 15),\
(155, 1, NULL, NULL, '2017-10-31 00:00:00', '2017014', '14000.00', '16940.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(156, 1, NULL, NULL, '2017-11-28 00:00:00', '2017015', '6500.00', '7865.00', 'Overdracht activa IncZwolle', '0000-00-00 00:00:00', '', 9, 7),\
(157, 1, NULL, NULL, '2017-12-01 00:00:00', '2017016', '15700.00', '18997.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(158, 1, NULL, NULL, '2017-12-08 00:00:00', '2017017', '250.00', '302.50', 'Strategie sessie 8 dec 2017', '0000-00-00 00:00:00', '', 53, 64),\
(159, 1, NULL, NULL, '2018-01-03 00:00:00', '201800001', '8100.00', '9801.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(160, 1, NULL, NULL, '2018-01-31 00:00:00', '2018001', '14700.00', '17787.00', 'Vervallen', '0000-00-00 00:00:00', '', 15, 62),\
(161, 1, NULL, NULL, '2018-01-31 00:00:00', '2018002', '14700.00', '17787.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(162, 1, NULL, NULL, '2018-03-02 00:00:00', '2018003', '14000.00', '16940.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 51, 62),\
(163, 1, NULL, NULL, '2018-04-05 00:00:00', '2018004', '14800.00', '17908.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(164, 1, NULL, NULL, '2018-05-01 00:00:00', '2018005', '14300.00', '17303.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(165, 1, NULL, NULL, '2018-06-03 00:00:00', '2018006', '11050.00', '13370.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(166, 1, NULL, NULL, '2018-07-01 00:00:00', '2018007', '14900.00', '18029.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(167, 1, NULL, NULL, '2018-08-02 00:00:00', '2018008', '11950.00', '14459.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(168, 1, NULL, NULL, '2018-09-03 00:00:00', '2018009', '7050.00', '8530.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(169, 1, NULL, NULL, '2018-09-21 00:00:00', '2018010', '1500.00', '1815.00', 'Ordernr: 35501  Betreft: Licentie Pegasus software SIR', '0000-00-00 00:00:00', '', 20, 68),\
(170, 1, NULL, NULL, '2018-10-01 00:00:00', '2018011', '13800.00', '16698.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(171, 1, NULL, NULL, '2018-10-28 00:00:00', '2018012', '3300.00', '3993.00', 'Ordernr: 35501  Betreft: Licentie Pegasus software SIR', '0000-00-00 00:00:00', '', 20, 68),\
(172, 1, NULL, NULL, '2018-11-02 00:00:00', '2018013', '6285.60', '7605.58', 'Projectondersteuning UGent oktbober 2018', '0000-00-00 00:00:00', '', 49, 69),\
(173, 1, NULL, NULL, '2018-12-01 00:00:00', '2018014', '5791.20', '7007.35', 'Projectondersteuning UGent november 2018', '0000-00-00 00:00:00', '', 49, 69),\
(174, 1, NULL, NULL, '2018-12-01 00:00:00', '2018015', '14950.00', '18089.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(175, 1, NULL, NULL, '2018-12-03 00:00:00', '2018016', '13500.00', '16335.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(176, 1, NULL, NULL, '2018-12-28 00:00:00', '2018017', '-3300.00', '-3993.00', 'Creditfactuur ordernr 35501', '0000-00-00 00:00:00', '', 20, 68),\
(177, 1, NULL, NULL, '2018-12-28 00:00:00', '2018018', '1500.00', '1815.00', 'Licentie SIR ordernummer 36370 ', '0000-00-00 00:00:00', '', 20, 68),\
(178, 1, NULL, NULL, '2018-12-28 00:00:00', '2018019', '1500.00', '1815.00', 'Licentie SIR ordernummer 36371', '0000-00-00 00:00:00', '', 20, 68),\
(179, 1, NULL, NULL, '2018-12-28 00:00:00', '2018020', '6691.20', '8096.35', 'Projectondersteuning UGent dec 18', '0000-00-00 00:00:00', '', 49, 69),\
(180, 1, NULL, NULL, '2018-12-31 00:00:00', '201900001', '800.00', '968.00', 'VOID ', '2019-01-01 00:00:00', '', 9, 7),\
(181, 1, NULL, NULL, '2018-12-31 00:00:00', '2019001', '800.00', '968.00', 'Data analyse UGent', '0000-00-00 00:00:00', '', 55, 70),\
(182, 1, NULL, NULL, '2019-01-07 00:00:00', '2019002', '7600.00', '9196.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(183, 1, NULL, NULL, '2019-02-01 00:00:00', '2019003', '11050.00', '13370.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(184, 1, NULL, NULL, '2019-02-01 00:00:00', '2019004', '6930.00', '8385.30', 'Projectondersteuning UGent jan 2019', '0000-00-00 00:00:00', '', 49, 69),\
(185, 1, NULL, NULL, '2019-03-01 00:00:00', '2019005', '6570.00', '7949.70', 'Projectondersteuning UGent feb 2019', '0000-00-00 00:00:00', '', 49, 69),\
(186, 1, NULL, NULL, '2019-03-01 00:00:00', '2019006', '10500.00', '12705.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(187, 1, NULL, NULL, '2019-04-01 00:00:00', '2019007', '6870.00', '8312.70', 'Projectondersteuning UGent mrt 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(188, 1, NULL, NULL, '2019-04-01 00:00:00', '2019008', '12200.00', '14762.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(189, 1, NULL, NULL, '2019-04-05 00:00:00', '2019009', '7300.00', '8833.00', 'activiteitencode 70300000', '0000-00-00 00:00:00', '', 56, 71),\
(190, 1, NULL, NULL, '2019-04-30 00:00:00', '2019010', '6750.00', '8167.50', 'Projectondersteuning UGent april 2019', '0000-00-00 00:00:00', '', 49, 69),\
(191, 1, NULL, NULL, '2019-04-30 00:00:00', '2019011', '800.00', '968.00', 'Data analyse UGent', '0000-00-00 00:00:00', '', 55, 70),\
(192, 1, NULL, NULL, '2019-05-03 00:00:00', '2019012', '5650.00', '6836.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(193, 1, NULL, NULL, '2019-06-03 00:00:00', '2019013', '9738.50', '11783.59', 'Projectmanagement UGent mei 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(194, 1, NULL, NULL, '2019-06-04 00:00:00', '2019014', '10000.00', '12100.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(195, 1, NULL, NULL, '2019-06-30 00:00:00', '2019015', '6750.00', '8167.50', 'Projectondersteuning UGent juni 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(196, 1, NULL, NULL, '2019-07-03 00:00:00', '2019016', '10950.00', '13249.50', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(197, 1, NULL, NULL, '2019-07-31 00:00:00', '2019017', '3885.00', '4700.85', 'Projectmanagement UGent juli2019	', '0000-00-00 00:00:00', '', 49, 69),\
(198, 1, NULL, NULL, '2019-07-31 00:00:00', '2019018', '8400.00', '10164.00', 'Project VU - Dirk Jan Durieux (008879-02)', '0000-00-00 00:00:00', '', 54, 66),\
(199, 1, NULL, NULL, '2019-09-02 00:00:00', '2019019', '10700.00', '12947.00', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(200, 1, NULL, NULL, '2019-09-02 00:00:00', '2019020', '2565.00', '3103.65', 'Projectondersteuning UGent aug 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(201, 1, NULL, NULL, '2019-09-30 00:00:00', '2019021', '4185.00', '5063.85', 'Projectmanagement UGent sept 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(202, 1, NULL, NULL, '2019-10-01 00:00:00', '2019022', '11000.00', '13310.00', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(203, 1, NULL, NULL, '2019-10-02 00:00:00', '2019023', '750.00', '907.50', 'Ordernummer 43950 Kostenplaats 6051', '0000-00-00 00:00:00', '', 20, 73),\
(204, 1, NULL, NULL, '2019-10-31 00:00:00', '2019024', '7850.00', '9498.50', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(205, 1, NULL, NULL, '2019-11-04 00:00:00', '2019025', '3090.00', '3738.90', 'Projectondersteuning UGent okt 2019', '0000-00-00 00:00:00', '', 49, 69),\
(206, 1, NULL, NULL, '2019-11-04 00:00:00', '2019026', '1687.50', '2041.88', 'Ordernr: 30097731-064040.', '0000-00-00 00:00:00', '', 58, 74),\
(207, 1, NULL, NULL, '2019-11-15 00:00:00', '2019027', '160.82', '194.59', 'easyjet doorbelasting', '0000-00-00 00:00:00', '', 52, 63),\
(208, 1, NULL, NULL, '2019-12-02 00:00:00', '2019028', '2085.00', '2522.85', 'Projectondersteuning UGent november 2019', '0000-00-00 00:00:00', '', 49, 69),\
(209, 1, NULL, NULL, '2019-12-02 00:00:00', '2019029', '3510.00', '4247.10', 'Ordernr: 30097731-064040.', '0000-00-00 00:00:00', '', 58, 74),\
(210, 1, NULL, NULL, '2019-12-02 00:00:00', '2019030', '10200.00', '12342.00', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(211, 1, NULL, NULL, '2019-12-21 00:00:00', '2019031', '2430.00', '2940.30', 'Ordernr: 30097731-064040.', '0000-00-00 00:00:00', '', 58, 74),\
(212, 1, NULL, NULL, '2019-12-27 00:00:00', '2019032', '3165.00', '3829.65', 'Projectondersteuning UGent dec 2019	', '0000-00-00 00:00:00', '', 49, 69),\
(213, 1, NULL, NULL, '2020-01-08 00:00:00', '202000001', '0.00', '0.00', 'Void?', '0000-00-00 00:00:00', '', 9, 7),\
(214, 1, NULL, NULL, '2020-01-08 00:00:00', '2020001', '5750.00', '6957.50', 'OO. nr. HFIT20198035 uren december 2019', '0000-00-00 00:00:00', '', 57, 72),\
(215, 1, NULL, NULL, '2020-01-28 00:00:00', '2020002', '300.00', '363.00', 'Ordernummer 48410', '0000-00-00 00:00:00', '', 20, 73),\
(216, 1, NULL, NULL, '2020-02-02 00:00:00', '2020003', '2505.00', '3031.05', 'Projectadvisering Onderwijslogistiek UGent jan 2020', '0000-00-00 00:00:00', '', 49, 69),\
(217, 1, NULL, NULL, '2020-02-02 00:00:00', '2020004', '4657.50', '5635.58', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(218, 1, NULL, NULL, '2020-02-02 00:00:00', '2020005', '3375.00', '4083.75', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(219, 1, NULL, NULL, '2020-02-05 00:00:00', '2020006', '2900.00', '3509.00', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(220, 1, NULL, NULL, '2020-02-29 00:00:00', '2020007', '2700.00', '3267.00', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(221, 1, NULL, NULL, '2020-02-29 00:00:00', '2020008', '3750.00', '4537.50', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(222, 1, NULL, NULL, '2020-02-29 00:00:00', '2020009', '4100.00', '4961.00', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(223, 1, NULL, NULL, '2020-02-29 00:00:00', '2020010', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(224, 1, NULL, NULL, '2020-03-31 00:00:00', '2020011', '2030.00', '2456.30', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(225, 1, NULL, NULL, '2020-04-01 00:00:00', '2020012', '3050.00', '3690.50', 'OO. nr. HFIT20198035', '0000-00-00 00:00:00', '', 57, 72),\
(226, 1, NULL, NULL, '2020-04-01 00:00:00', '2020013', '2295.00', '2776.95', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(227, 1, NULL, NULL, '2020-04-01 00:00:00', '2020014', '4562.50', '5520.63', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(228, 1, NULL, NULL, '2020-05-01 00:00:00', '2020015', '3687.50', '4461.88', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(229, 1, NULL, NULL, '2020-05-01 00:00:00', '2020016', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(230, 1, NULL, NULL, '2020-05-01 00:00:00', '2020017', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(231, 1, NULL, NULL, '2020-05-01 00:00:00', '2020018', '6800.00', '8228.00', 'Kostenplaats 5380066', '0000-00-00 00:00:00', '', 59, 75),\
(232, 1, NULL, NULL, '2020-05-02 00:00:00', '2020019', '810.00', '980.10', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(233, 1, NULL, NULL, '2020-05-03 00:00:00', '2020020', '810.00', '980.10', 'P20200K20167', '0000-00-00 00:00:00', '', 61, 77),\
(234, 1, NULL, NULL, '2020-05-31 00:00:00', '2020021', '1920.00', '2323.20', 'Projectadvisering Onderwijslogistiek UGent mei 2020	', '0000-00-00 00:00:00', '', 49, 69),\
(235, 1, NULL, NULL, '2020-05-31 00:00:00', '2020022', '2937.50', '3554.38', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(236, 1, NULL, NULL, '2020-06-01 00:00:00', '2020023', '607.50', '735.08', 'P20200K20167', '0000-00-00 00:00:00', '', 61, 77),\
(237, 1, NULL, NULL, '2020-06-01 00:00:00', '2020024', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(238, 1, NULL, NULL, '2020-06-01 00:00:00', '2020025', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(239, 1, NULL, NULL, '2020-06-01 00:00:00', '2020026', '4250.00', '5142.50', 'Kostenplaats 5380066', '0000-00-00 00:00:00', '', 59, 75),\
(244, 1, NULL, NULL, '2020-07-01 00:00:00', '2020027', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(245, 1, NULL, NULL, '2020-07-01 00:00:00', '2020028', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(246, 1, NULL, NULL, '2020-07-02 00:00:00', '2020029', '2062.50', '2495.63', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(247, 1, NULL, NULL, '2020-07-03 00:00:00', '2020030', '1012.50', '1225.13', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(248, 1, NULL, NULL, '2020-07-04 00:00:00', '2020031', '1345.00', '1627.45', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.', '0000-00-00 00:00:00', '', 63, 79),\
(249, 1, NULL, NULL, '2020-07-05 00:00:00', '2020032', '950.00', '1149.50', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(250, 1, NULL, NULL, '2020-08-02 00:00:00', '2020033', '437.50', '529.38', 'Kostenplaats 5380023', '0000-00-00 00:00:00', '', 59, 75),\
(251, 1, NULL, NULL, '2020-08-02 00:00:00', '2020034', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(252, 1, NULL, NULL, '2020-08-02 00:00:00', '2020035', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(253, 1, NULL, NULL, '2020-08-02 00:00:00', '2020036', '2522.50', '3052.23', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.	', '0000-00-00 00:00:00', '', 63, 79),\
(254, 1, NULL, NULL, '2020-08-02 00:00:00', '2020037', '405.00', '490.05', 'P20200K20167', '0000-00-00 00:00:00', '', 61, 77),\
(255, 1, NULL, NULL, '2020-08-03 00:00:00', '2020038', '10830.00', '13104.30', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(256, 1, NULL, NULL, '2020-09-01 00:00:00', '2020039', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(257, 1, NULL, NULL, '2020-09-01 00:00:00', '2020040', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(258, 1, NULL, NULL, '2020-09-01 00:00:00', '2020041', '7885.00', '9540.85', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(259, 1, NULL, NULL, '2020-09-01 00:00:00', '2020042', '4067.50', '4921.68', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.', '0000-00-00 00:00:00', '', 63, 79),\
(260, 1, NULL, NULL, '2020-09-08 00:00:00', '2020043', '8925.00', '10799.25', 'Inkoopnummer 096- 215341', '0000-00-00 00:00:00', '', 64, 80),\
(261, 1, NULL, NULL, '2020-10-01 00:00:00', '2020044', '300.00', '363.00', 'Projectadvisering Onderwijslogistiek UGent sept 2020', '0000-00-00 00:00:00', '', 49, 69),\
(262, 1, NULL, NULL, '2020-10-01 00:00:00', '2020045', '405.00', '490.05', 'P20200K20167', '0000-00-00 00:00:00', '', 61, 77),\
(263, 1, NULL, NULL, '2020-10-01 00:00:00', '2020046', '810.00', '980.10', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(264, 1, NULL, NULL, '2020-10-01 00:00:00', '2020047', '3697.50', '4473.98', 'Inkoopnummer 096- 215341', '0000-00-00 00:00:00', '', 64, 80),\
(265, 1, NULL, NULL, '2020-10-01 00:00:00', '2020048', '7935.00', '9601.35', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.', '0000-00-00 00:00:00', '', 63, 79),\
(266, 1, NULL, NULL, '2020-10-02 00:00:00', '2020049', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(267, 1, NULL, NULL, '2020-10-02 00:00:00', '2020050', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(268, 1, NULL, NULL, '2020-10-05 00:00:00', '2020051', '937.50', '1134.38', 'Kostenplaats 5380017 t.a.v. M. Witte', '0000-00-00 00:00:00', '', 59, 75),\
(269, 1, NULL, NULL, '2020-10-07 00:00:00', '2020052', '5700.00', '6897.00', 'OO. nr. HFIT202015516', '0000-00-00 00:00:00', '', 57, 72),\
(270, 1, NULL, NULL, '2020-11-02 00:00:00', '2020053', '8835.00', '10690.35', 'OO. nr. HFIT202015516', '0000-00-00 00:00:00', '', 57, 72),\
(271, 1, NULL, NULL, '2020-11-02 00:00:00', '2020054', '3915.00', '4737.15', 'Inkoopnummer 096- 215341', '0000-00-00 00:00:00', '', 64, 80),\
(272, 1, NULL, NULL, '2020-11-02 00:00:00', '2020055', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(273, 1, NULL, NULL, '2020-11-02 00:00:00', '2020056', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(274, 1, NULL, NULL, '2020-12-02 00:00:00', '2020057', '11400.00', '13794.00', 'OO. nr. HFIT202015516', '0000-00-00 00:00:00', '', 57, 72),\
(275, 1, NULL, NULL, '2020-12-07 00:00:00', '2020058', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(276, 1, NULL, NULL, '2020-12-07 00:00:00', '2020059', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(277, 1, NULL, NULL, '2020-12-07 00:00:00', '2020060', '675.00', '816.75', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(278, 1, NULL, NULL, '2020-12-26 00:00:00', '2020061', '4320.00', '5227.20', 'Verbijzondering 9610014', '0000-00-00 00:00:00', '', 64, 80),\
(279, 1, NULL, NULL, '2020-12-31 00:00:00', '2020062', '7410.00', '8966.10', 'OO. nr. HFIT202015516', '0000-00-00 00:00:00', '', 57, 72),\
(280, 1, NULL, NULL, '2020-12-31 00:00:00', '2020063', '4050.00', '4900.50', 'Verbijzondering 9610014', '0000-00-00 00:00:00', '', 64, 80),\
(281, 1, NULL, NULL, '2020-12-31 00:00:00', '2020064', '8165.00', '9879.65', 'Opdracht EUR inzake aanbesteding roosterappl.  dec 2020', '0000-00-00 00:00:00', '', 52, 63),\
(282, 1, NULL, NULL, '2020-12-31 00:00:00', '2020065', '555.00', '671.55', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.', '0000-00-00 00:00:00', '', 63, 79),\
(283, 1, NULL, NULL, '2020-12-31 00:00:00', '2020066', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(284, 1, NULL, NULL, '2020-12-31 00:00:00', '2020067', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(285, 1, NULL, NULL, '2021-01-19 00:00:00', '202100001', '0.00', '0.00', 'VOID', '0000-00-00 00:00:00', '', 9, 7),\
(286, 1, NULL, NULL, '2021-01-19 00:00:00', '2021001', '1032.00', '1248.72', 'Projectbegeleiding adviesopdracht Aarhus GNK. nov/dec 2020', '0000-00-00 00:00:00', '', 52, 63),\
(287, 1, NULL, NULL, '2021-01-30 00:00:00', '2021002', '5197.50', '6288.98', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(288, 1, NULL, NULL, '2021-01-30 00:00:00', '2021003', '1512.50', '1830.13', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.	', '0000-00-00 00:00:00', '', 63, 79),\
(289, 1, NULL, NULL, '2021-01-30 00:00:00', '2021004', '405.00', '490.05', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(290, 1, NULL, NULL, '2021-01-30 00:00:00', '2021005', '540.00', '653.40', 'P20200K20167', '0000-00-00 00:00:00', '', 61, 77),\
(291, 1, NULL, NULL, '2021-01-30 00:00:00', '2021006', '17307.50', '20942.08', 'Opdracht EUR inzake aanbesteding roosterappl', '0000-00-00 00:00:00', '', 52, 63),\
(292, 1, NULL, NULL, '2021-01-30 00:00:00', '2021007', '13400.00', '16214.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(293, 1, NULL, NULL, '2021-01-30 00:00:00', '2021008', '3200.00', '3872.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(294, 1, NULL, NULL, '2021-01-30 00:00:00', '2021009', '1600.00', '1936.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(295, 1, NULL, NULL, '2021-03-01 00:00:00', '2021010', '18975.00', '22959.75', 'Opdracht EUR inzake aanbesteding roosterappl. feb2021', '0000-00-00 00:00:00', '', 52, 63),\
(296, 1, NULL, NULL, '2021-03-01 00:00:00', '2021011', '12100.00', '14641.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(297, 1, NULL, NULL, '2021-03-01 00:00:00', '2021012', '2700.00', '3267.00', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(298, 1, NULL, NULL, '2021-03-01 00:00:00', '2021013', '1755.00', '2123.55', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030.', '0000-00-00 00:00:00', '', 63, 79),\
(299, 1, NULL, NULL, '2021-03-03 00:00:00', '2021014', '3200.00', '3872.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(300, 1, NULL, NULL, '2021-03-03 00:00:00', '2021015', '2200.00', '2662.00', 'Advies  marktbewerking en positionering', '0000-00-00 00:00:00', '', 60, 76),\
(301, 1, NULL, NULL, '2021-03-09 00:00:00', '2021016', '920.00', '1113.20', 'Bemiddeling', '0000-00-00 00:00:00', '', 66, 82),\
(302, 1, NULL, NULL, '2021-03-31 00:00:00', '2021017', '2835.00', '3430.35', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030', '0000-00-00 00:00:00', '', 63, 79),\
(303, 1, NULL, NULL, '2021-04-01 00:00:00', '2021018', '6345.00', '7677.45', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(304, 1, NULL, NULL, '2021-04-01 00:00:00', '2021019', '11100.00', '13431.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(305, 1, NULL, NULL, '2021-04-01 00:00:00', '2021020', '16272.50', '19689.73', 'Opdracht EUR inzake aanbesteding roosterappl. mrt 2021', '0000-00-00 00:00:00', '', 52, 63),\
(306, 1, NULL, NULL, '2021-04-02 00:00:00', '2021021', '3200.00', '3872.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(307, 1, NULL, NULL, '2021-04-02 00:00:00', '2021022', '1620.00', '1960.20', 'Bemiddeling', '0000-00-00 00:00:00', '', 66, 82),\
(308, 1, NULL, NULL, '2021-04-02 00:00:00', '2021023', '367.50', '444.68', 'Bemiddeling Q1 RU', '0000-00-00 00:00:00', '', 52, 63),\
(309, 1, NULL, NULL, '2021-04-04 00:00:00', '2021024', '410.00', '496.10', 'bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(310, 1, NULL, NULL, '2021-05-01 00:00:00', '2021025', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(311, 1, NULL, NULL, '2021-05-01 00:00:00', '2021026', '220.00', '266.20', 'Bemiddeling RU Q2', '0000-00-00 00:00:00', '', 52, 63),\
(312, 1, NULL, NULL, '2021-05-01 00:00:00', '2021027', '5550.00', '6715.50', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(313, 1, NULL, NULL, '2021-05-01 00:00:00', '2021028', '10400.00', '12584.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(314, 1, NULL, NULL, '2021-05-01 00:00:00', '2021029', '10120.00', '12245.20', 'Opdracht EUR inzake aanbesteding roosterappl. apr 2021', '0000-00-00 00:00:00', '', 52, 63),\
(315, 1, NULL, NULL, '2021-05-01 00:00:00', '2021030', '607.50', '735.08', 'Ordernr: 30097731-064040', '0000-00-00 00:00:00', '', 58, 74),\
(316, 1, NULL, NULL, '2021-05-01 00:00:00', '2021031', '7492.50', '9065.93', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(317, 1, NULL, NULL, '2021-05-01 00:00:00', '2021032', '1890.00', '2286.90', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030', '0000-00-00 00:00:00', '', 63, 79),\
(318, 1, NULL, NULL, '2021-05-03 00:00:00', '2021033', '12500.00', '15125.00', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(319, 1, NULL, NULL, '2021-05-31 00:00:00', '2021034', '10500.00', '12705.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(320, 1, NULL, NULL, '2021-06-01 00:00:00', '2021035', '3000.00', '3630.00', 'Projectbegeleiding plan van aanpak flexstuderen.', '0000-00-00 00:00:00', '', 68, 83),\
(321, 1, NULL, NULL, '2021-06-01 00:00:00', '2021036', '6197.50', '7498.98', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(322, 1, NULL, NULL, '2021-06-01 00:00:00', '2021037', '12592.50', '15236.93', 'Opdracht EUR inzake aanbesteding roosterappl. mei 2021', '0000-00-00 00:00:00', '', 52, 63),\
(323, 1, NULL, NULL, '2021-06-01 00:00:00', '2021038', '675.00', '816.75', 'Karin van der Zeeuw-Filemon. Sap ordernr: 1510202030', '0000-00-00 00:00:00', '', 63, 79),\
(324, 1, NULL, NULL, '2021-06-01 00:00:00', '2021039', '6952.50', '8412.53', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(325, 1, NULL, NULL, '2021-06-01 00:00:00', '2021040', '14937.50', '18074.38', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(326, 1, NULL, NULL, '2021-06-02 00:00:00', '2021041', '812.50', '983.13', 'Kostenplaats 5380023 | project Onderwijsplanning', '0000-00-00 00:00:00', '', 59, 75),\
(327, 1, NULL, NULL, '2021-06-02 00:00:00', '2021042', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(328, 1, NULL, NULL, '2021-06-02 00:00:00', '2021043', '1140.00', '1379.40', 'bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(329, 1, NULL, NULL, '2021-06-06 00:00:00', '2021044', '5722.50', '6924.23', 'projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(330, 1, NULL, NULL, '2021-06-06 00:00:00', '2021045', '3300.00', '3993.00', 'Kostenplaats 204180 HvA  | Robert Schoeman ', '0000-00-00 00:00:00', '', 70, 85),\
(331, 1, NULL, NULL, '2021-07-01 00:00:00', '2021046', '11750.00', '14217.50', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(332, 1, NULL, NULL, '2021-07-01 00:00:00', '2021047', '7000.00', '8470.00', 'Projectbegeleiding plan van aanpak flexstuderen.', '0000-00-00 00:00:00', '', 68, 83),\
(333, 1, NULL, NULL, '2021-07-01 00:00:00', '2021048', '13187.50', '15956.88', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(334, 1, NULL, NULL, '2021-07-01 00:00:00', '2021049', '6885.00', '8330.85', 'IND.2021.1179761.075118', '0000-00-00 00:00:00', '', 65, 81),\
(335, 1, NULL, NULL, '2021-07-01 00:00:00', '2021050', '5920.00', '7163.20', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(336, 1, NULL, NULL, '2021-07-01 00:00:00', '2021051', '12477.50', '15097.78', 'Opdracht EUR inzake aanbesteding roosterappl. juni 2021', '0000-00-00 00:00:00', '', 52, 63),\
(337, 1, NULL, NULL, '2021-07-01 00:00:00', '2021052', '1080.00', '1306.80', 'Ondersteuning bij proj. standaardisatie PRT-proces @HG', '0000-00-00 00:00:00', '', 71, 86),\
(338, 1, NULL, NULL, '2021-07-01 00:00:00', '2021053', '260.00', '314.60', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(339, 1, NULL, NULL, '2021-07-01 00:00:00', '2021054', '4811.00', '5821.31', 'Kostenplaats  792260L SSC | Project planning en roostering Lwd', '0000-00-00 00:00:00', '', 42, 87),\
(340, 1, NULL, NULL, '2021-07-01 00:00:00', '2021055', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(341, 1, NULL, NULL, '2021-07-01 00:00:00', '2021056', '7700.00', '9317.00', 'projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(342, 1, NULL, NULL, '2021-07-02 00:00:00', '2021057', '8160.00', '9873.60', 'Kostenplaats 538110 | Anfaira Doest | Stud. Wellbeing project', '0000-00-00 00:00:00', '', 59, 75),\
(343, 1, NULL, NULL, '2021-07-07 00:00:00', '2021058', '5400.00', '6534.00', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(344, 1, NULL, NULL, '2021-07-28 00:00:00', '2021059', '2393.20', '2895.77', 'Kostenplaats 792260L SSC | Project planning en roostering Lwd', '0000-00-00 00:00:00', '', 42, 87),\
(345, 1, NULL, NULL, '2021-07-31 00:00:00', '2021060', '7200.00', '8712.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(346, 1, NULL, NULL, '2021-07-31 00:00:00', '2021061', '1375.00', '1663.75', 'Projectbegeleiding plan van aanpak flexstuderen.', '0000-00-00 00:00:00', '', 68, 83),\
(347, 1, NULL, NULL, '2021-08-01 00:00:00', '2021062', '5175.00', '6261.75', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(348, 1, NULL, NULL, '2021-08-01 00:00:00', '2021063', '14720.00', '17811.20', 'Opdracht EUR inzake aanbesteding roosterappl. juli 2021', '0000-00-00 00:00:00', '', 52, 63),\
(349, 1, NULL, NULL, '2021-08-01 00:00:00', '2021064', '1600.00', '1936.00', 'Advies marktbewerking en positionering  ', '0000-00-00 00:00:00', '', 55, 70),\
(350, 1, NULL, NULL, '2021-08-01 00:00:00', '2021065', '7680.00', '9292.80', 'Kostenplaats 538110 | Anfaira Doest | Stud. Wellbeing project', '0000-00-00 00:00:00', '', 59, 75),\
(351, 1, NULL, NULL, '2021-08-02 00:00:00', '2021066', '5500.00', '6655.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(352, 1, NULL, NULL, '2021-08-02 00:00:00', '2021067', '12812.50', '15503.13', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(353, 1, NULL, NULL, '2021-08-02 00:00:00', '2021068', '3375.00', '4083.75', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(354, 1, NULL, NULL, '2021-08-03 00:00:00', '2021069', '6020.00', '7284.20', 'projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(355, 1, NULL, NULL, '2021-08-04 00:00:00', '2021070', '230.00', '278.30', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(356, 1, NULL, NULL, '2021-08-04 00:00:00', '2021071', '2800.00', '3388.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(357, 1, NULL, NULL, '1970-01-01 00:00:00', '2021072', '0.00', '0.00', '', '0000-00-00 00:00:00', '', 55, 70),\
(358, 1, NULL, NULL, '2021-09-03 00:00:00', '2021073', '1600.00', '1936.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(359, 1, NULL, NULL, '2021-09-03 00:00:00', '2021074', '4995.00', '6043.95', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(360, 1, NULL, NULL, '2021-09-03 00:00:00', '2021075', '9200.00', '11132.00', 'Opdracht EUR inzake aanbesteding roosterappl. aug 2021', '0000-00-00 00:00:00', '', 52, 63),\
(361, 1, NULL, NULL, '2021-09-03 00:00:00', '2021076', '6600.00', '7986.00', 'kostenplaats 538110 | Anfaira Doest | Stud. Wellbeing project', '0000-00-00 00:00:00', '', 59, 75),\
(362, 1, NULL, NULL, '2021-09-03 00:00:00', '2021077', '9500.00', '11495.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(363, 1, NULL, NULL, '2021-09-03 00:00:00', '2021078', '5425.00', '6564.25', 'Projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(364, 1, NULL, NULL, '2021-09-03 00:00:00', '2021079', '4995.00', '6043.95', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(365, 1, NULL, NULL, '2021-09-04 00:00:00', '2021080', '2200.00', '2662.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(366, 1, NULL, NULL, '2021-09-04 00:00:00', '2021081', '687.50', '831.88', 'Projectbegeleiding plan van aanpak flexstuderen', '0000-00-00 00:00:00', '', 68, 83),\
(367, 1, NULL, NULL, '2021-09-08 00:00:00', '2021082', '4125.00', '4991.25', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(368, 1, NULL, NULL, '2021-09-09 00:00:00', '2021083', '460.00', '556.60', 'bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(369, 1, NULL, NULL, '2021-09-10 00:00:00', '2021084', '3600.00', '4356.00', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(370, 1, NULL, NULL, '2021-10-05 00:00:00', '2021085', '8400.00', '10164.00', 'Inzet Henk Tjalsma Radboud Universiteit', '0000-00-00 00:00:00', '', 65, 81),\
(371, 1, NULL, NULL, '2021-10-06 00:00:00', '2021086', '6030.00', '7296.30', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(372, 1, NULL, NULL, '2021-10-06 00:00:00', '2021087', '11040.00', '13358.40', 'Opdracht EUR inzake aanbesteding roosterappl. sept 2021', '0000-00-00 00:00:00', '', 52, 63),\
(373, 1, NULL, NULL, '2021-10-06 00:00:00', '2021088', '12750.00', '15427.50', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(374, 1, NULL, NULL, '2021-10-06 00:00:00', '2021089', '7800.00', '9438.00', 'kostenplaats 538110 | Anfaira Doest | Stud. Wellbeing project', '0000-00-00 00:00:00', '', 59, 75),\
(375, 1, NULL, NULL, '2021-10-06 00:00:00', '2021090', '7200.00', '8712.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(376, 1, NULL, NULL, '2021-10-07 00:00:00', '2021091', '300.00', '363.00', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(377, 1, NULL, NULL, '2021-10-07 00:00:00', '2021092', '6000.00', '7260.00', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(378, 1, NULL, NULL, '2021-10-07 00:00:00', '2021093', '7560.00', '9147.60', 'projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(379, 1, NULL, NULL, '2021-10-07 00:00:00', '2021094', '1100.00', '1331.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(380, 1, NULL, NULL, '2021-10-07 00:00:00', '2021095', '4590.00', '5553.90', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(381, 1, NULL, NULL, '2021-10-12 00:00:00', '2021096', '8815.98', '10667.34', 'Kostenplaats Services-SSC 226 -  PLANNING  ROOSTERING', '0000-00-00 00:00:00', '', 42, 87),\
(382, 1, NULL, NULL, '2021-11-03 00:00:00', '2021097', '8900.00', '10769.00', 'IND.2021.1179761.080192', '0000-00-00 00:00:00', '', 65, 81),\
(383, 1, NULL, NULL, '2021-11-03 00:00:00', '2021098', '9200.00', '11132.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(384, 1, NULL, NULL, '2021-11-03 00:00:00', '2021099', '2040.00', '2468.40', 'kostenplaats 538110 | Anfaira Doest | Stud. Wellbeing project', '0000-00-00 00:00:00', '', 59, 75),\
(385, 1, NULL, NULL, '2021-11-03 00:00:00', '2021100', '5025.00', '6080.25', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(386, 1, NULL, NULL, '2021-11-03 00:00:00', '2021101', '490.00', '592.90', 'projectcode PO1766', '0000-00-00 00:00:00', '', 69, 84),\
(387, 1, NULL, NULL, '2021-11-03 00:00:00', '2021102', '6000.00', '7260.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(388, 1, NULL, NULL, '2021-11-03 00:00:00', '2021103', '1100.00', '1331.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(389, 1, NULL, NULL, '2021-11-03 00:00:00', '2021104', '12822.50', '15515.23', 'Opdracht EUR inzake aanbesteding roosterappl. okt 2021', '0000-00-00 00:00:00', '', 52, 63);\
INSERT INTO `invoices` (`id`, `invoice_type`, `member_id`, `subscription_id`, `date`, `number`, `amount`, `amount_tax`, `reference`, `payment_date`, `mollie_payment_id`, `company_id`, `contact_person_id`) VALUES\
(390, 1, NULL, NULL, '2021-11-03 00:00:00', '2021105', '4607.50', '5575.08', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(391, 1, NULL, NULL, '2021-11-03 00:00:00', '2021106', '2632.50', '3185.33', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(392, 1, NULL, NULL, '2021-11-03 00:00:00', '2021107', '310.00', '375.10', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(393, 1, NULL, NULL, '2021-11-03 00:00:00', '2021108', '13027.32', '15763.06', 'Kostenplaats Services-SSC 226 Planning roostering', '0000-00-00 00:00:00', '', 42, 87),\
(394, 1, NULL, NULL, '2021-11-03 00:00:00', '2021109', '3200.00', '3872.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(395, 1, NULL, NULL, '2021-11-03 00:00:00', '2021110', '8875.00', '10738.75', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(396, 1, NULL, NULL, '2021-11-03 00:00:00', '2021111', '4187.50', '5066.88', 'Projectbegeleiding PvA Flexstuderen', '0000-00-00 00:00:00', '', 68, 83),\
(397, 1, NULL, NULL, '2021-12-02 00:00:00', '2021112', '5100.00', '6171.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(398, 1, NULL, NULL, '2021-12-02 00:00:00', '2021113', '5625.00', '6806.25', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(399, 1, NULL, NULL, '2021-12-02 00:00:00', '2021114', '2812.50', '3403.13', 'Projectbegeleiding PvA Flexstuderen', '0000-00-00 00:00:00', '', 68, 83),\
(400, 1, NULL, NULL, '2021-12-02 00:00:00', '2021115', '11937.50', '14444.38', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(401, 1, NULL, NULL, '2021-12-02 00:00:00', '2021116', '3200.00', '3872.00', 'Advies marktbewerking en positionering', '0000-00-00 00:00:00', '', 55, 70),\
(402, 1, NULL, NULL, '2021-12-02 00:00:00', '2021117', '10600.00', '12826.00', 'IND.2021.1179761.080192', '0000-00-00 00:00:00', '', 65, 81),\
(403, 1, NULL, NULL, '2021-12-02 00:00:00', '2021118', '2090.00', '2528.90', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(404, 1, NULL, NULL, '2021-12-02 00:00:00', '2021119', '14950.00', '18089.50', 'Opdracht EUR inzake aanbesteding roosterappl. nov 2021', '0000-00-00 00:00:00', '', 52, 63),\
(405, 1, NULL, NULL, '2021-12-02 00:00:00', '2021120', '16162.32', '19556.41', 'Kostenplaats Services-SSC 226 PLANNING ROOSTERING', '0000-00-00 00:00:00', '', 42, 87),\
(406, 1, NULL, NULL, '2021-12-02 00:00:00', '2021121', '4725.00', '5717.25', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(407, 1, NULL, NULL, '2021-12-02 00:00:00', '2021122', '6440.00', '7792.40', 'Opdracht EUR inzake aanbesteding roosterappl. sept-okt-nov 2021', '0000-00-00 00:00:00', '', 52, 63),\
(408, 1, NULL, NULL, '2021-12-02 00:00:00', '2021123', '1000.00', '1210.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(409, 1, NULL, NULL, '2021-12-03 00:00:00', '2021124', '9600.00', '11616.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(410, 1, NULL, NULL, '2022-01-04 00:00:00', '202200001', '0.00', '0.00', 'vreemd factuurnummer - factuur vervalt', '0000-00-00 00:00:00', '', 9, 7),\
(411, 1, NULL, NULL, '2022-01-04 00:00:00', '2022001', '1615.00', '1954.15', 'Kostenplaats 5311215-proj. intekenen | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(412, 1, NULL, NULL, '2022-01-04 00:00:00', '2022002', '9430.00', '11410.30', 'Opdracht EUR inzake aanbesteding roosterappl. dec 2021', '0000-00-00 00:00:00', '', 52, 63),\
(413, 1, NULL, NULL, '2022-01-04 00:00:00', '2022003', '9400.00', '11374.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(414, 1, NULL, NULL, '2022-01-04 00:00:00', '2022004', '8800.00', '10648.00', 'IND.2021.1179761.080192', '0000-00-00 00:00:00', '', 65, 81),\
(415, 1, NULL, NULL, '2022-01-04 00:00:00', '2022005', '5250.00', '6352.50', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(416, 1, NULL, NULL, '2022-01-04 00:00:00', '2022006', '3062.50', '3705.63', 'Projectbegeleiding PvA Flexstuderen', '0000-00-00 00:00:00', '', 68, 83),\
(417, 1, NULL, NULL, '2022-01-04 00:00:00', '2022007', '9312.50', '11268.13', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(418, 1, NULL, NULL, '2022-01-04 00:00:00', '2022008', '1207.50', '1461.08', 'Opdracht EUR inzake aanbesteding roosterappl. dec 2021', '0000-00-00 00:00:00', '', 52, 63),\
(419, 1, NULL, NULL, '2022-01-04 00:00:00', '2022009', '700.00', '847.00', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(420, 1, NULL, NULL, '2022-01-04 00:00:00', '2022010', '4050.00', '4900.50', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(421, 1, NULL, NULL, '2022-01-04 00:00:00', '2022011', '3000.00', '3630.00', 'IND.2021.1179761.079783 | Petra ter Bekke', '0000-00-00 00:00:00', '', 65, 81),\
(422, 1, NULL, NULL, '2022-01-05 00:00:00', '2022012', '11550.00', '13975.50', 'Kostenplaats Services-SSC 226 PLANNING ROOSTERING', '0000-00-00 00:00:00', '', 42, 93),\
(423, 1, NULL, NULL, '2022-01-05 00:00:00', '2022013', '240.00', '290.40', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(424, 1, NULL, NULL, '2022-01-07 00:00:00', '2022014', '200.00', '242.00', 'Bemiddeling RU', '0000-00-00 00:00:00', '', 60, 76),\
(425, 1, NULL, NULL, '2022-02-01 00:00:00', '2022015', '7820.00', '9462.20', 'Opdracht EUR inzake aanbesteding roosterappl. jan 2022', '0000-00-00 00:00:00', '', 52, 63),\
(426, 1, NULL, NULL, '2022-02-01 00:00:00', '2022016', '3900.00', '4719.00', 'H/539404.006', '0000-00-00 00:00:00', '', 59, 75),\
(427, 1, NULL, NULL, '2022-02-01 00:00:00', '2022017', '11655.00', '14102.55', 'Kostenplaats H/539420.001 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(428, 1, NULL, NULL, '2022-02-01 00:00:00', '2022018', '3847.50', '4655.48', 'IND.2021.1179761.075118 | Dirk Jan Durieux', '0000-00-00 00:00:00', '', 65, 81),\
(429, 1, NULL, NULL, '2022-02-01 00:00:00', '2022019', '10375.00', '12553.75', 'IND.2021.1179761.077220 | B. Overbeek', '0000-00-00 00:00:00', '', 65, 81),\
(430, 1, NULL, NULL, '2022-02-01 00:00:00', '2022020', '1250.00', '1512.50', 'Projectbegeleiding plan van aanpak flexstuderen', '0000-00-00 00:00:00', '', 68, 83),\
(431, 1, NULL, NULL, '2022-02-01 00:00:00', '2022021', '6525.00', '7895.25', 'Kostenplaats 204180 HvA | Robert Schoeman', '0000-00-00 00:00:00', '', 70, 85),\
(432, 1, NULL, NULL, '2022-02-02 00:00:00', '2022022', '3007.50', '3639.08', '2090009 onderwijslogistiek', '0000-00-00 00:00:00', '', 77, 94),\
(433, 1, NULL, NULL, '2022-02-02 00:00:00', '2022023', '1840.00', '2226.40', 'Opdracht EUR inzake aanbesteding roosterappl. jan 2022', '0000-00-00 00:00:00', '', 52, 63),\
(434, 1, NULL, NULL, '2022-02-02 00:00:00', '2022024', '8576.16', '10377.15', 'Kostenplaats Services-SSC 226 PLANNING ROOSTERING', '0000-00-00 00:00:00', '', 42, 93),\
(435, 1, NULL, NULL, '2022-02-02 00:00:00', '2022025', '1050.00', '1270.50', 'Kostenplaats 5311020 | Jos\'e9 van Schie', '0000-00-00 00:00:00', '', 59, 75),\
(436, 1, NULL, NULL, '2022-02-02 00:00:00', '2022026', '8190.00', '9909.90', 'IND.7507YLH.2022.1179761.084411.1', '0000-00-00 00:00:00', '', 65, 81),\
(437, 1, NULL, NULL, '2022-02-02 00:00:00', '2022027', '9555.00', '11561.55', 'IND.2021.1179761.080192', '0000-00-00 00:00:00', '', 65, 81),\
(438, 1, NULL, NULL, '2022-03-11 00:00:00', '2022028', '-40.00', '-49.00', 'Test John', '0000-00-00 00:00:00', '', 1, 3),\
(439, 1, NULL, NULL, '2025-01-08 00:00:00', '202500001', '1.00', '1.02', 'test', '0000-00-00 00:00:00', '', 1, 3);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoice_mistral`\
--\
\
CREATE TABLE `invoice_mistral` (\
  `id` int(11) NOT NULL,\
  `invoice_type` tinyint(1) NOT NULL COMMENT '''0 FOR MEMBER'',''1 FOR COMPANY''',\
  `member_id` int(11) UNSIGNED DEFAULT NULL,\
  `subscription_id` varchar(255) DEFAULT NULL,\
  `date` datetime NOT NULL,\
  `number` varchar(20) NOT NULL,\
  `amount` decimal(10,2) NOT NULL,\
  `amount_tax` decimal(10,2) NOT NULL,\
  `reference` varchar(200) NOT NULL,\
  `payment_date` datetime NOT NULL,\
  `mollie_payment_id` varchar(50) NOT NULL,\
  `company_id` int(10) UNSIGNED DEFAULT NULL,\
  `contact_person_id` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoice_mistral`\
--\
\
INSERT INTO `invoice_mistral` (`id`, `invoice_type`, `member_id`, `subscription_id`, `date`, `number`, `amount`, `amount_tax`, `reference`, `payment_date`, `mollie_payment_id`, `company_id`, `contact_person_id`) VALUES\
(1, 1, NULL, NULL, '2021-07-01 00:00:00', '2021001', '0.00', '0.00', 'VOID', '0000-00-00 00:00:00', '', 9, 7),\
(2, 1, NULL, NULL, '2021-07-01 00:00:00', '2021002', '10652.50', '12889.53', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(3, 1, NULL, NULL, '2021-08-04 00:00:00', '2021003', '13140.00', '15899.40', 'Project Onderwijsplanning 2030 Kostenplaats 535000 OKP', '0000-00-00 00:00:00', '', 59, 75),\
(4, 1, NULL, NULL, '2021-09-03 00:00:00', '2021004', '6587.50', '7970.88', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(5, 1, NULL, NULL, '2021-09-03 00:00:00', '2021005', '1890.00', '2286.90', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(6, 1, NULL, NULL, '2021-10-07 00:00:00', '2021006', '3300.00', '3993.00', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(7, 1, NULL, NULL, '2021-12-26 00:00:00', '2021007', '30000.00', '36300.00', 'managementfee 2021', '0000-00-00 00:00:00', '', 76, 92),\
(8, 1, NULL, NULL, '2022-03-14 00:00:00', '202200001', '0.00', '0.00', 'Test John', '0000-00-00 00:00:00', '', 1, 3);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `invoice_new`\
--\
\
CREATE TABLE `invoice_new` (\
  `id` int(11) NOT NULL,\
  `invoice_type` tinyint(1) NOT NULL COMMENT '''0 FOR MEMBER'',''1 FOR COMPANY''',\
  `member_id` int(11) UNSIGNED DEFAULT NULL,\
  `subscription_id` varchar(255) DEFAULT NULL,\
  `date` datetime NOT NULL,\
  `number` varchar(20) NOT NULL,\
  `amount` decimal(10,2) NOT NULL,\
  `amount_tax` decimal(10,2) NOT NULL,\
  `reference` varchar(200) NOT NULL,\
  `payment_date` datetime NOT NULL,\
  `mollie_payment_id` varchar(50) NOT NULL,\
  `company_id` int(10) UNSIGNED DEFAULT NULL,\
  `contact_person_id` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `invoice_new`\
--\
\
INSERT INTO `invoice_new` (`id`, `invoice_type`, `member_id`, `subscription_id`, `date`, `number`, `amount`, `amount_tax`, `reference`, `payment_date`, `mollie_payment_id`, `company_id`, `contact_person_id`) VALUES\
(1, 1, NULL, NULL, '2021-09-09 00:00:00', '2021001', '0.02', '0.02', 'testfactuur', '0000-00-00 00:00:00', '', 9, 7),\
(2, 1, NULL, NULL, '2021-10-07 00:00:00', '2021002', '100.00', '121.00', 'Kostenplaats 663401 | t.a.v. Stefan Titus', '0000-00-00 00:00:00', '', 59, 75),\
(3, 1, NULL, NULL, '2021-10-07 00:00:00', '2021003', '5225.00', '6322.25', 'Kostenplaats 535020 |Procesregisseur Tentaminering M.Visser', '0000-00-00 00:00:00', '', 59, 75),\
(4, 1, NULL, NULL, '2021-10-07 00:00:00', '2021004', '7375.00', '8923.75', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(5, 1, NULL, NULL, '2021-10-07 00:00:00', '2021005', '2400.00', '2904.00', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(6, 1, NULL, NULL, '2021-10-07 00:00:00', '2021006', '500.00', '605.00', 'Project Onderwijsplanning 2030 Kostenplaats 538001', '0000-00-00 00:00:00', '', 59, 75),\
(7, 1, NULL, NULL, '2021-10-16 00:00:00', '2021007', '4445.00', '5378.45', 'Kostenplaats 82908246 | t.a.v. Pieter van Oosterhout', '0000-00-00 00:00:00', '', 73, 89),\
(8, 1, NULL, NULL, '2021-11-03 00:00:00', '2021008', '19665.00', '23794.65', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(9, 1, NULL, NULL, '2021-11-03 00:00:00', '2021009', '100.00', '121.00', 'Kostenplaats 663401 | t.a.v. Stefan Titus', '0000-00-00 00:00:00', '', 59, 75),\
(10, 1, NULL, NULL, '2021-11-03 00:00:00', '2021010', '3045.00', '3684.45', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(11, 1, NULL, NULL, '2021-11-03 00:00:00', '2021011', '1125.00', '1361.25', 'Kostenplaats 2505 | C. Meijer', '0000-00-00 00:00:00', '', 74, 90),\
(12, 1, NULL, NULL, '2021-11-03 00:00:00', '2021012', '4235.00', '5124.35', 'Kostenplaats 535000 | Procesregisseur Tentaminering M.Visser', '0000-00-00 00:00:00', '', 59, 75),\
(13, 1, NULL, NULL, '2021-12-02 00:00:00', '2021013', '29082.50', '35189.83', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(14, 1, NULL, NULL, '2021-12-02 00:00:00', '2021014', '400.00', '484.00', 'Kostenplaats 2505 | C. Meijer', '0000-00-00 00:00:00', '', 74, 90),\
(15, 1, NULL, NULL, '2021-12-02 00:00:00', '2021015', '2500.00', '3025.00', 'Kostenplaats 663401 | t.a.v. Stefan Titus', '0000-00-00 00:00:00', '', 59, 75),\
(16, 1, NULL, NULL, '2021-12-02 00:00:00', '2021016', '1800.00', '2178.00', 'Kostenplaats 2505 | C. Meijer', '0000-00-00 00:00:00', '', 74, 90),\
(17, 1, NULL, NULL, '2021-12-02 00:00:00', '2021017', '6765.00', '8185.65', 'Kostenplaats 535000 | Procesregisseur Tentaminering M.Visser', '0000-00-00 00:00:00', '', 59, 75),\
(18, 1, NULL, NULL, '2021-12-03 00:00:00', '2021018', '7000.00', '8470.00', 'Kostenplaats O/050600 | inkooporder nnb', '0000-00-00 00:00:00', '', 75, 91),\
(19, 1, NULL, NULL, '2022-01-04 00:00:00', '202200001', '5390.00', '6521.90', 'Kostenplaats 535000 | Procesregisseur Tentaminering M.Visser', '0000-00-00 00:00:00', '', 59, 75),\
(20, 1, NULL, NULL, '2022-01-04 00:00:00', '2022001', '27455.00', '33220.55', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(21, 1, NULL, NULL, '2022-01-04 00:00:00', '2022002', '900.00', '1089.00', 'Kostenplaats 2505 | C. Meijer', '0000-00-00 00:00:00', '', 74, 90),\
(22, 1, NULL, NULL, '2022-01-04 00:00:00', '2022003', '600.00', '726.00', 'Kostenplaats 663401 | t.a.v. Stefan Titus', '0000-00-00 00:00:00', '', 59, 75),\
(23, 1, NULL, NULL, '2022-01-05 00:00:00', '2022004', '8000.00', '9680.00', 'Kostenplaats O/050600 | inkooporder nnb', '0000-00-00 00:00:00', '', 75, 91),\
(24, 1, NULL, NULL, '2022-02-01 00:00:00', '2022005', '6050.00', '7320.50', 'Kostenplaats 535000 | Procesregisseur Tentaminering M.Visser', '0000-00-00 00:00:00', '', 59, 75),\
(25, 1, NULL, NULL, '2022-02-01 00:00:00', '2022006', '27812.50', '33653.13', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(26, 1, NULL, NULL, '2022-02-02 00:00:00', '2022007', '1600.00', '1936.00', 'Kostenplaats 663401 | t.a.v. Stefan Titus', '0000-00-00 00:00:00', '', 59, 75),\
(27, 1, NULL, NULL, '2022-02-02 00:00:00', '2022008', '750.00', '907.50', 'Kostenplaats 2505 | C. Meijer', '0000-00-00 00:00:00', '', 74, 90),\
(28, 1, NULL, NULL, '2022-02-04 00:00:00', '2022009', '2200.00', '2662.00', 'Project Onderwijsplanning 2030 Kostenplaats 538430 ', '0000-00-00 00:00:00', '', 59, 75),\
(29, 1, NULL, NULL, '2022-02-09 00:00:00', '2022010', '5375.00', '6503.75', 'Kostenplaat O050600 | inkooporder nnb', '0000-00-00 00:00:00', '', 75, 91);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `links`\
--\
\
CREATE TABLE `links` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `url` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `page_id` int(10) UNSIGNED DEFAULT NULL,\
  `position` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `open_in_new_window` tinyint(1) DEFAULT '0',\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `links`\
--\
\
INSERT INTO `links` (`id`, `name`, `url`, `page_id`, `position`, `open_in_new_window`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES\
(1, 'LInk 1', 'google.com', NULL, 'header', 1, NULL, NULL, '2014-12-18 06:57:18', '2014-12-18 06:58:36');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `lists`\
--\
\
CREATE TABLE `lists` (\
  `id` int(11) UNSIGNED NOT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `project_id` int(11) UNSIGNED DEFAULT NULL,\
  `group_id` int(11) UNSIGNED DEFAULT NULL,\
  `visibility` tinyint(1) NOT NULL COMMENT '"1 for Workspace, 2 for Workgroup, 3 for all-platform"',\
  `library` tinyint(4) NOT NULL,\
  `title` varchar(60) NOT NULL,\
  `is_archive` tinyint(4) NOT NULL,\
  `workgroup_id` int(11) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `list_items`\
--\
\
CREATE TABLE `list_items` (\
  `id` int(11) NOT NULL,\
  `list_id` int(11) UNSIGNED NOT NULL,\
  `description` varchar(255) NOT NULL,\
  `is_completed` tinyint(1) NOT NULL,\
  `sequence` int(10) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `updated_by` int(11) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `mail_templates`\
--\
\
CREATE TABLE `mail_templates` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `trigger` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `subject` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `content` text COLLATE utf8_unicode_ci NOT NULL,\
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `sender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `mail_templates`\
--\
\
INSERT INTO `mail_templates` (`id`, `trigger`, `subject`, `content`, `tag`, `sender`, `created_at`, `updated_at`) VALUES\
(1, 'Forget password', 'IncZwolle platform', '<p>Beste &lt;first_name&gt;,</p>\\r\\n\\r\\n<p>Je hebt aangegeven dat je jouw wachtwoord bent vergeten. Hierbij nogmaals jouw wachtwoord:</p>\\r\\n\\r\\n<p>Wachtwoord : &lt;password&gt;</p>\\r\\n\\r\\n<p>Met hartelijke groet,</p>\\r\\n\\r\\n<p>&nbsp;</p>\\r\\n\\r\\n<p>Team IncZwolle</p>\\r\\n', '', 'info@IncZwolle.nl', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(2, 'Registration', 'Aanmelding bij het platform van IncZwolle', '<p style=\\"line-height: 20.79px;\\">Beste <span style=\\"line-height: 1.6em;\\">&lt;first_name&gt; &lt;middle_name&gt; &lt;last_name&gt;,</span></p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\"><span style=\\"line-height: 1.6em;\\">Welkom bij IncZwolle en dank voor jouw registratie. We hebben de volgende gegevens van je genoteerd:</span></p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Bedrijfsnaam: &lt;company_name&gt;<br />\\r\\nContact persoon: &lt;first_name&gt; &lt;middle_name&gt; &lt;last_name&gt;&nbsp;<br />\\r\\nE-mail : &lt;email&gt;<br />\\r\\nFactuuradres: &lt;address&gt;<br />\\r\\nPostcode:&lt;zipcode&gt;<br />\\r\\nCity: &lt;city&gt;<br />\\r\\nWebsite: &lt;website_url&gt;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Beschrijving bedrijf: &lt;company_description&gt;<br />\\r\\n<br />\\r\\nVerwachting Pressure Cooker: &lt;reason&gt;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Indien er gegevens niet kloppen, graag even doorgeven aan info@inczwolle.nl</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Wij gaan de gegevens controleren en je account activeren. Hiervan krijg je binnen enkele dagen van ons bericht. Daarna kun je inloggen op ons platform.</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Mocht je vragen of opmerkingen hebben, neem contact met ons op via <a href=\\"mailto:info@inczwolle.nl\\">info@inczwolle.nl</a> of 038 2600800.</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Met hartelijke groet,</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Team IncZwolle</p>\\r\\n', '<first_name> <middle_name>', 'info@IncZwolle.nl', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(3, 'Activation', 'Jouw account op het platform van IncZwolle is geactiveerd.', '<p style=\\"line-height: 20.79px;\\">Beste&nbsp;&lt;first_name&gt; &lt;last_name&gt;,</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Welkom bij IncZwolle.</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Je hebt je aangemeld voor de Pressure Cooker en je aanmelding is gecontroleerd en geactiveerd. Je kunt vanaf nu inloggen op ons platform met de volgende gegevens:</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Email: &lt;email&gt;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Password: &lt;password&gt;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Om in te loggen en je profiel verder aan te vullen, ga je naar <a href=\\"http://www.inczwolle.nl/platform\\">www.inczwolle.nl/platform</a></p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">We kijken er naar uit om samen jouw start up succesvol te maken.</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Met hartelijke groet,<br />\\r\\n&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">Team IncZwolle</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n\\r\\n<p style=\\"line-height: 20.79px;\\">&nbsp;</p>\\r\\n', '', 'info@IncZwolle.nl', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(4, 'workgroup_invitation', 'Je bent uitgenodigd voor een werkgroep', '<p>Beste relatie</p>\\r\\n\\r\\n<p>Je bent uitgenodigd voor een werkgroep.</p>\\r\\n\\r\\n<p>Hartelijke groet</p>\\r\\n\\r\\n<p>Team IncZwolle</p>\\r\\n\\r\\n<p>&nbsp;</p>\\r\\n', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(5, 'factuur', 'Factuur van IncZwolle', '<p>Beste relatie,</p>\\r\\n\\r\\n<p>Bijgevoegd vindt u de factuur voor geleverde diensten.</p>\\r\\n\\r\\n<p>Mocht u vragen hebben over de inhoud van de factuur, verzoeken wij u contact op te nemen met IncZwolle via <a href=\\"mailto:info@inczwolle.nl\\">info@inczwolle.nl</a> of 038 - 2 600 800.</p>\\r\\n\\r\\n<p>We zien uit naar een spoedige betaling en danken u voor de samenwerking.</p>\\r\\n\\r\\n<p>Met hartelijke groet,</p>\\r\\n\\r\\n<p>&nbsp;</p>\\r\\n\\r\\n<p>Dirk Jan Durieux</p>\\r\\n', '', 'IncZwolle', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(6, 'project_invitation', 'Je bent uitgenodigd voor een project', '<p>Beste relatie</p>\\r\\n\\r\\n<p>Je bent uitgenodigd voor een project : &lt;project_name&gt;</p>\\r\\n\\r\\n<p>Hartelijke groet</p>\\r\\n\\r\\n<p>Team IncZwolle</p>\\r\\n\\r\\n<p>&nbsp;</p>\\r\\n', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),\
(7, 'project_invitation_member', 'Je bent uitgenodigd voor een project', '<p>Beste &lt;first_name&gt; &lt;last_name&gt; ,</p>\\r\\n\\r\\n<p>Je bent uitgenodigd voor een project : &lt;project_name&gt;</p>\\r\\n\\r\\n<p>Hartelijke groet</p>\\r\\n\\r\\n<p>Team IncZwolle</p>\\r\\n\\r\\n<p>&nbsp;</p>\\r\\n', '<first_name> <last_name>', 'info@IncZwolle.nl', '0000-00-00 00:00:00', '0000-00-00 00:00:00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `migrations`\
--\
\
CREATE TABLE `migrations` (\
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `batch` int(11) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `migrations`\
--\
\
INSERT INTO `migrations` (`migration`, `batch`) VALUES\
('2014_12_06_063406_create_groups_table', 1),\
('2014_12_06_063406_create_pages_table', 1),\
('2014_12_06_063406_create_throttle_table', 1),\
('2014_12_06_063406_create_users_groups_table', 1),\
('2014_12_06_063406_create_users_table', 1),\
('2014_12_06_063406_create_workgroups_table', 1),\
('2014_12_06_063408_add_foreign_keys_to_workgroups_table', 1),\
('2014_12_06_065803_create_wg_members_table', 2),\
('2014_12_06_065805_add_foreign_keys_to_wg_members_table', 2),\
('2014_12_06_111220_create_companies_table', 3),\
('2014_12_06_111222_add_foreign_keys_to_companies_table', 3),\
('2014_12_08_055528_create_events_table', 4),\
('2014_12_08_055529_add_foreign_keys_to_events_table', 4),\
('2014_12_08_055544_create_event_workgroups_table', 4),\
('2014_12_08_055545_add_foreign_keys_to_event_workgroups_table', 4),\
('2014_12_09_101256_create_event_day_modules_table', 5),\
('2014_12_09_101257_add_foreign_keys_to_event_day_modules_table', 5),\
('2014_12_09_101307_create_event_days_table', 5),\
('2014_12_09_101308_add_foreign_keys_to_event_days_table', 5),\
('2014_12_09_105854_add_event_id_to_event_days', 6),\
('2014_12_11_125639_create_contacts_table', 7),\
('2014_12_11_125640_add_foreign_keys_to_contacts_table', 7),\
('2014_12_16_073007_create_conversations_table', 8),\
('2014_12_16_073008_add_foreign_keys_to_conversations_table', 8),\
('2014_12_17_072443_create_galleries_table', 9),\
('2014_12_17_072445_add_foreign_keys_to_galleries_table', 9),\
('2014_12_17_072453_create_images_table', 9),\
('2014_12_17_072454_add_foreign_keys_to_images_table', 9),\
('2014_12_18_075434_create_links_table', 10),\
('2014_12_18_075435_add_foreign_keys_to_links_table', 10),\
('2014_12_18_082958_create_mail_templates_table', 11),\
('2014_12_19_115953_create_general_settings_table', 12),\
('2014_12_19_115954_add_foreign_keys_to_general_settings_table', 12),\
('2014_12_22_111055_create_website_news_table', 13),\
('2014_12_22_111056_add_foreign_keys_to_website_news_table', 13),\
('2014_12_22_130055_create_website_ambassador_table', 14),\
('2014_12_22_130057_add_foreign_keys_to_website_ambassador_table', 14),\
('2014_12_23_081819_create_website_teammembers_table', 15),\
('2014_12_23_081821_add_foreign_keys_to_website_teammembers_table', 15),\
('2014_12_23_104626_create_website_contactforms_table', 15),\
('2014_12_25_051803_create_website_pages_table', 16),\
('2014_12_25_100316_create_website_page_posts_table', 16),\
('2014_12_25_100317_add_foreign_keys_to_website_page_posts_table', 16);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `pages`\
--\
\
CREATE TABLE `pages` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `page_banner` text COLLATE utf8_unicode_ci,\
  `content` text COLLATE utf8_unicode_ci,\
  `SEO_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `SEO_description` text COLLATE utf8_unicode_ci,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `pages`\
--\
\
INSERT INTO `pages` (`id`, `title`, `page_banner`, `content`, `SEO_title`, `SEO_description`, `created_at`, `updated_at`) VALUES\
(1, 'page1 ', NULL, '<p>content</p>\\r\\n', 'seo 1', 'seo desc', '0000-00-00 00:00:00', '0000-00-00 00:00:00');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `payments`\
--\
\
CREATE TABLE `payments` (\
  `id` int(11) NOT NULL,\
  `payment_id` varchar(100) NOT NULL,\
  `amount` varchar(20) NOT NULL,\
  `status` varchar(100) NOT NULL,\
  `order_id` int(20) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `payments`\
--\
\
INSERT INTO `payments` (`id`, `payment_id`, `amount`, `status`, `order_id`) VALUES\
(4, 'tr_yvhaV8rMjZ', '100', 'open', 1420896347),\
(5, 'tr_TBATcMz3qG', '12', 'open', 1420896615);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `projects`\
--\
\
CREATE TABLE `projects` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `parent_project_id` int(10) UNSIGNED DEFAULT NULL,\
  `name` varchar(100) NOT NULL,\
  `status` tinyint(1) NOT NULL COMMENT '0 for "inactive", 1 for "active", 2 for "archive"',\
  `library` tinyint(4) NOT NULL,\
  `workgroup_id` int(11) NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `projects`\
--\
\
INSERT INTO `projects` (`id`, `workspace_id`, `parent_project_id`, `name`, `status`, `library`, `workgroup_id`, `created_at`, `updated_at`, `updated_by`) VALUES\
(12, 4, NULL, 'Project 1', 0, 0, 0, '2015-03-27 08:39:53', '2015-03-27 08:39:53', NULL),\
(13, 4, NULL, 'Project 2', 0, 0, 0, '2015-03-27 08:39:56', '2015-03-27 08:39:56', NULL),\
(14, 4, NULL, 'Project 3', 0, 0, 0, '2015-03-27 08:39:59', '2015-03-27 08:39:59', NULL),\
(15, 4, NULL, 'Brochure', 0, 0, 0, '2015-03-27 08:40:07', '2015-03-27 08:40:07', NULL),\
(16, 4, NULL, 'website', 0, 0, 0, '2015-03-27 08:40:11', '2015-03-27 08:40:11', NULL),\
(17, 4, NULL, 'Web app', 0, 0, 0, '2015-03-27 08:40:16', '2015-03-27 08:40:16', NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `project_members`\
--\
\
CREATE TABLE `project_members` (\
  `id` int(11) NOT NULL,\
  `project_id` int(10) UNSIGNED NOT NULL,\
  `member_id` int(10) UNSIGNED NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `project_notes`\
--\
\
CREATE TABLE `project_notes` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `user_id` int(10) UNSIGNED NOT NULL,\
  `project_id` int(11) NOT NULL,\
  `notes` text NOT NULL,\
  `created_datetime` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `project_notes`\
--\
\
INSERT INTO `project_notes` (`id`, `user_id`, `project_id`, `notes`, `created_datetime`) VALUES\
(3, 24, 122, 'Notitie 1\\n', '2016-02-12 07:22:17'),\
(5, 3, 18, 'test123\\r\\ndfasdfd', '2016-02-16 06:32:44'),\
(6, 24, 126, 'Dinsdag gesprek gehad Joost, gaf aan mismatch te ervaren tussen functie en competenties. Erna hierop ingelicht en zij gaf aan contact op te nemen met TO. Marjon Ham. Afspraak dinsdag. \\r\\nInmiddels ook met PO gesproken, blijkt dat Joost in re.... nogwat functie, dwz dat iemand zijn plek voor Joost heft opgegeven, die weg is met geld en Joost dus ingewerkt en akkoord is met functie. Lijkt dat daarmee de route naar TO een lastige wordt. \\r\\n', '2016-03-18 09:13:06'),\
(7, 24, 124, 'Gesprek Sandra, roosteraar (e.a. activiteiten) van PGO wil . (is dit onderdeel van FEWEB). Ze willen roosteractiviteiten graag over laten nemen door central roosterteam (maar niet FTE, Sandra gaat dan andere activiteiten binnen PGO doen). Afgesproken is dat zij hierover een eerste opzet maakt en dat ik deze aanvul. Voorwaarde is dat de roosteruitvraag voor S2 2-016-2017 via UAS verloopt en afhankelijk van de kwaliteit, wordt bepaalt of central roosterteam het verantwoord vindt om PGO roostering over te nemen. Heb document gekregen met te roosteren vakken PGO (jaarplanning).', '2016-03-18 09:18:06'),\
(8, 24, 126, 'Project breakdown\\n\\nTeam ontwikkeling\\n- training syllabus expert Senz\\n- training van elkaar \\n- teamtraining processen / samenwerking / \\n- koers\\n- functieprofielen\\n- afstemming werkzaamheden hoofden  Owb\\n- achterwacht\\n- ketenplanning\\nPROCESSEN\\n- verzamel data over procesontwerp\\n- verzamelen data over proces, ism sturingsinfo project\\n-  ontwikkelen discussiedocument versie 0,1 nieuw proces\\n- afstemmen met omgving\\n- formele eerste afstemming met expertgroep\\n- goedkeuring howd of opo\\n\\n', '2016-03-21 07:22:03'),\
(9, 24, 126, 'team overleg\\n- lync teklefoons alleen voor de beta\\'s ? Mogeliojkheid voor mobile telefoons? Afspraak UCIT\\n- Sterke PC\\'s? Minimjum i5 pc met meer geheugen (i7 met 8 GB geheugen)\\n- plan bord plus 1 a twee whiteboards\\n- Stoelen aglaia niet fijn? Rechtsgeleerdheid? Eigen stoel? Stoel wisselen \\\\\\n- Met Naomi:  broker eruit SAP S+: Dagelijks controleren of de broker werkt.  \\n- \\n- \\n ', '2016-03-21 08:44:02'),\
(10, 24, 124, 'Cees van gent.\\n15 augustus aangeleverd aan opo, 8 fasen, vindt het jammer dat dit niet wordt geimplementeerd. Gemiste kans.\\nVind dat er te weinig risico genomen wordt.\\nHalverwege jaren negentig onderwijsplanning\\nOorsprong planner, uu gewerkt, roosteraar, teamleider onderwijs org en admin. \\nDir basisschool, geen succes\\nRoosteraar bij exacte wetenschappen, collega Saskia, 2009.\\nMarjolijn opvolger van Jose van Schie, ging gelijk ook weg, \\nNu waarnemend hoofd beta owb,\\nHad functie voor reeorganisatie, intern gekeken.\\nFascinatie onderwijslogistiek. Overtuigd  dat we dingen fout: verantwoordelijkheden op de verkeerde plekken neerleggen.belasten roosteraars te veel, door drie keer te roosteren.\\nStuk met procesindeling, veel werk in gedaan.\\nGebruiken Splus verkeerd hier, door drie keer roostergegevens aan te leveren en te verwerken. Vallenvullers.\\nVeranderen  van wensen van faculteiten ook beta: willen werkelijke afgenomen uren van zalen zien, omdat ze via de bekostiging verrekend willen worden.\\nWerkvormen, misschien we 21 in het systeem, maar gebruiken er maar 5.\\nHertentamens mist in jaarrooster.\\n', '2016-03-21 15:05:49'),\
(11, 24, 124, 'Karin Bijker\\r\\nFsw , sinds 1992 met yvonne samen gewerkt met Karin. \\r\\nKarin vond het vervelend dat ik haar met ha karin aanhefte.\\r\\nRouwperiode yvonne, omdat ze geen andere dingen meer kon doen. Gaat volgens haar nu wat beter.\\r\\nRoostering fase 2, werkgroep, voorgeZeten, aanscherpen eisen roosterwijzigingen. \\r\\nProject onderwijslogistiek zou dit oppakken, maar is uitgesteld.\\r\\nEerst intekenen daarna lokLen eraan hangen\\r\\nStrenger roosterwijzigingen\\r\\n', '2016-03-22 16:01:29'),\
(12, 24, 126, 'Teamoverleg:\\nAfspraak met Marijke monna om af te stemmen hoe we de leenrechten beter kunnen inrichten voor geneeskunde. Het grote zalen overleg zorgde ervoor dat er zachte afspraken waren die Monique (FCO) nu verkeerd (via dummy zalen) in syllabus heft ingevoerd. \\n\\noveruren,. volgfende week weer op de agenda, met voorstel van hun. Evenwicht vrijheid van handelen en verantwoordelijkheid van mij als leidinggevende. Doel is om 1 regeling te maken voor allen, afstemmen marjolijn.\\n\\nTentamen week 37 traalcentrum, 8:15 uur blok is problem, ron stuurt alternatieve versie\\n\\nTrudie en Ron afvaariging klein committee TENT zelf roosteren.\\n\\nHovo: regelen we in de naplanning, \\n\\n', '2016-03-29 07:54:51'),\
(13, 24, 124, 'Werkoverleg Irma Schouten - Dirk Jan Durieux 24 maart 2016\\n1.	Onderwijs logistiek proces\\nVoormalig onderwijs logistiek project is gestopt. Dirk Jan maakt een afgeslankt voorstel ten behoeve van een integrale verbetering van het roosterproces:\\n-	Mindset docenten (geen vastomlijnd rooster meer aanbieden), onderwijs co\'f6rdinatoren etc.\\n-	Ketenplanning\\n-	UAS\\n-	Communicatiestructuur opzetten\\n-	Sturingsinformatie over bezetting, benutting en no show zaal gebruik\\n-	Helderheid en prioritering onderwijs versus niet onderwijs activiteiten\\nDoorbelastingssystematiek zalen voor onderwijs en laboratoria: TDH (Toerekening en Doorbelasting Huisvestingskosten)\\nActie Dirk Jan: concept plan onderwijslogistiek toesturen.\\n2.	Roosterproces\\n- Streven naar kortere doorlooptijd roosteren\\n- Leenrechtenverdeling: streven naar lager percentage knelpunten. - computerzalen\\n- Contactpersoon roosterzaken: Inhoudelijke zaken verlopen rechtstreeks via betreffende roosteraar(s).\\n- Wens dat roosteraars zelf dummyzalen aanmaken voor hun faculteiten. FCO regelt dit voor HOVO, pgo FEWEB en VUmc.\\nActie Irma en Dirk Jan: na roosterproces inventariseren Dirk Jan en Irma of bijstelling van de toegekende zalen en uren aanpassing behoeft.\\n\\n3.	Leenrechtenoverleg en knelpuntenoverleg\\nLeenrechtenoverleg verloopt via huidige procedure: initiatie: FCO, voorstel leenrechten. Irma en Jeroen (vervanger Brechtje), expertise systeeminrichting.\\nKnelpuntenoverleg: vertegenwoordiging vanuit faculteiten, HOVO, pgo FEWEB, VUmc en namens FCO Jeroen Lases (vervanger Brechtje). \\n\\n4.	Intekenprocedure\\nDirk Jan probeert inzicht te verkrijgen in de richtlijnen.\\n\\n5.	Tentamenplanning buiten unijakaweken\\nVerzoek Ron tentamens zelf plannen buiten unijakawekenn.\\nActie Dirk Jan: overleg plannen met 2 \'e0 3 roosteraars, en 2 collega\'92s van FCO.\\nActie Irma: namen deelnemers doorgeven\\n\\n6.	Voorrangscongressen\\nStatus wordt meegenomen in richtlijnen/prioritering onderwijs en niet onderwijs activiteiten zoals evenementen, Windesheim, pre university college, summerschools etc.\\n7.	Verbouwingen\\n- MF-gebouw\\n- John Stuart Milll College (PPE)\\n\\n8.	John Stuart Mill College (PPE)\\n4A-00 zaal: Dirk Jan is hierover in gesprek met HOVO.\\nActiepuntenlijst\\nNr.	Onderwerp	Actor\\n1	Concept plan onderwijslogistiek toesturen	Dirk Jan\\n2	Na roosterproces inventariseren of bijstelling van de toegekende zalen en uren aanpassing behoeft	Dirk Jan/Irma\\n3	Overleg plannen met 2 \'e0 3 roosteraars, en 2 collega\'92s van FCO	Dirk Jan\\n4	Namen deelnemers doorgeven overleg tentamenplanning buiten unijaka weken	Irma\\nJeroen Lases en Monique van der Sluis', '2016-03-29 10:02:48'),\
(14, 24, 124, 'Gesprek Pim Koenen, 29-3:\\nRechten. Pim\\n\\nIs hoofd onderwijsbureau. Yvonne is teamleider onderwijslogistiek. Stuurde roosteraar aan.Team oonderwijslogistiek, kwaliteitszaorg, verzamelen gegevens, onderwijs organisatorische processen. Yvonne is eerste aanspreekpunt, roostering en capaciteit, heeft alle bevoegdheden voor. \\nOnderwijsbureau is soort van klant voor team roostering. Portefeille houders worden geinstrueerd  door hoofden OWB. \\nGoede vervanging voor uitvallen Annemarie door Aglaia. \\nTaakopvatting, wat wel en niet. SAP, Capaciteitsbeheer.\\nRobin Frohlich, ervaring met rechten, vond het vreemd de wijze waarop de VU e.e.a. heeft inrgericht of gebruikt. \\nSLA, toekomst maar wel goed toekomstbeeld.\\nFaculteiten met de grootste mond krijgen het meest. De roosteraars zijn in het verleden in de kou gezet, zo van zoek het maar uit. \\nRechten is altijd wel een voorstander om wat strenger te zijn naar docenten. \\nOm OPO mee te krijgen moeten ook helderheid te zijn over afspraken en verwachtingen, wat kun je bieden. Als je teveel stuurt op de ene kant (roostering terugnemen) , zonder kwaliteits verbetering, dan gaat OPO stijgeren. Veel OPO-ers zijn zelf ook docent. Goed uitleggen. \\n\\nTentamen logistiek. Wie is waarvoor verantwoordelijk ? Is dit onderdeel van het project? Nee, niet echt.\\nPersonele verantwoordelijkheden. Annemarie: wij hebben contact gehad, lijn loopt via ons. Pim verwacht voor de zomer weer op popt, maar weinig uren. Contract Agaila  loopt tot nov. Snel pienter, goed contact met docenten, weet onzin van zin te scheiden. \\nHO is spil organisatie waar beleid en organisatie elkaar overgaan. Draagvlak realiseren. HO is heel kritisch. Staan onder druk van de faculteiten. Kwaliteit in de gaten houden en realiseren. Zijn wat uit positie gebracht. Zwaartekracht dienstverlening verschuiven naar de dienst. \\nDat wat dichtbij is, draag je meer verantwoordelijkheid bij zich. Kan de dienst het waarmaken? Zorgen over of het \\nSnelheid en transparantie richting faculteit vanuit Anneloes niet goed. Dienst heeft daarmee steken laten vallen. \\nOpvoeden serieus nemen en met strategie doen. Uniformeren en efficiency. \\nKetenplanning, verantwoordelijkheid nemen sobere omgang ruimte plan en middelen. Geen gekkigheid, noodzaak duidelijk en waarom we dit doen. \\nSpelregels afspreken. \\n', '2016-03-29 12:09:03'),\
(15, 24, 126, 'Gesprek Anneloes:\\r\\n\\r\\nOver Nick: wellicht zijn verzoeken onderdeel van de ketenplanning. ', '2016-03-31 13:55:22'),\
(16, 24, 124, 'Gesprek Naomi Mungroo,  Alex Noteboom, 31-3\\r\\n-	Rapport Deloitte is door student FEW uitgevoerd/data analyse . Cees van Gent kan helpen bij zoeken naar student. Irving . Naomi zoekt naam uit voor mij. Mocht Irving niet kunnen dan weet Cees vast wel alternatief. \\r\\n-	\\r\\n-	SPDA, Syllabus Plus Database Adapter, tussendatabase tussen s+ en de broker. \\r\\n-	Het ligt vaker aan de SPDA.\\r\\n-	Of ze kunnen zien of broker werkt, dagelijks, is lastig. Ze zijn onderbezet. Kunnen verzoek indien voor dagelijks \\r\\n-	Als er een uur niet over de lijn gaat, krijgt FB een melding, maar weet niet of\\r\\no	Ligt aan SPDA of broker\\r\\no	Of dat er niets is geroosterd\\r\\n-	Van de SPDA krijg je meestal meldingen, en wordt dan snel weer opgelost, is een script voor. \\r\\n-	Broker beheer, aangeven wat de wens is. Er komt een upgrade van de broker SAP \'96broker- BB, QMP, Vunet,   S+ enz. \\r\\n-	Ander probleem is dat de broker achterstand heeft bij verwerking van data, duizenden verzoeken achterstand. \\r\\n-	Upgrade broker zou verbetering moeten zijn. \\r\\n-	In SPDA zijn verbeteringen doorgevoerd, in tabellen structuur is niet optimaal, zijn verbeteringen doorgevoerd door leverancier. \\r\\n-	Investeren in SPDA is investeren in Syllabus, maar verwachting is niet dat dit voor nieuwe roostersysteem wordt gedaan. Conclusie, hoe houden we S+ en SPDA in de lucht, hoe houden we het hoofd boven water. \\r\\n-	Alex en Naomi, wanneer gegevens niet over de lijn zijn1 uur lang, dan een mail naar Roosteraars?\\r\\n-	Is niet zeker dat het aan SPDA of broker ligt , maar  wel dat er al een uur niets is verwerkt. Proefdraaien?\\r\\n-	Anne van Zeeland, technisch beheer van SQL, er is voor alle database upgrade  uitgevoerd SQL behalve S+, vraag wanneer kan dit Voorstel vrijdagmiddag. Hoe lang duurt dit? \\r\\n-	Communicatie?  \\r\\n-	Vrijdagmiddag goed moment? Rond vier uur, half vijf? Uitloop naar de avond. \\r\\n\\r\\n\\r\\n\\r\\n', '2016-03-31 17:13:15'),\
(17, 24, 126, 'Gespreksverslag GNK, Joost, Marijke, Ron, Saskia over inregelen leenrechten fgn\\r\\n\\r\\n-	Alle faculteiten werden aan de reguliere zalen gekoppeld\\r\\n-	GNK kreeg een dummy zaal, niet de reguliere zaal \\r\\n-	Er waren nooit dummy zalen voor de grote zalen, zachte afspraken\\r\\n-	Grote zaal is opengezet voor iedereen behalve GNK , \\r\\n-	GNK is daarna toegevoegd aan de reguliere zaal. \\r\\n-	FCO zegt: maar hoe verdelen jullie dat dan? Zachte afspraak. \\r\\n-	Door terug te draaien, is het snel weer opgelost\\r\\n-	Doel is om inrichting niet meer door FCO maar door ons wordt ingericht\\r\\n-	Zelf dummyzalen kunnen inrichten, uitgevoerd door centraal roosterteam \\r\\n-	Conclusie: niets veranderen, meer overleg en op basis daarvan  plannen.\\r\\n-	Ron vraagt extra rechten aan, voor allle roosteraars meer rechten, omdat nu niet iedereen alles kan\\r\\n-	GNK toevoegen aan MF zalen? Even samen kijken? Marijke komt maandag mee kijken.\\r\\n', '2016-03-31 17:14:46'),\
(18, 24, 127, 'Bila Bart Overbeek\\r\\n\\r\\nUAS, ragina accounts regelen\\r\\nBart is benieuwd of de output van UAS!\\r\\nsAP uas, VOEDT VAKCOORDINATOREN, koppelt welke persoon voor welk vak verantwoordelijk is voor ingeven van ', '2016-04-01 13:35:19'),\
(19, 24, 126, 'Ron en yvonne naar pieter 9 uur. \\r\\nTraining syllabus in Juni opzetten. \\r\\nBetitel hety niet als overuren maar tijd voor tijd/werktijden. Volgende week op terugkomen\\r\\n\\r\\nSaskia neemt contact op met Naomi om helder te krijgen, wat die uur is, communicatie enz. En vraag wie welke rechten heeft. \\r\\nVrijdagmiddag 4 uur.\\r\\nBijeenkomst plannen voor \\r\\n-	Is het de taak van de Bas om de WP te ondersteunen bij uitvraag roostergegevens.  \\r\\n-	Wil je centrale roostergegevens, dan centrale regels! (Yvonne Hoogwegt)\\r\\n-	Juni uitvraag. Of iig grote zalen overleg?\\r\\n-	Is het bekend bij de afdelingshoofden wat de status is van gebruik uas in semester 2?\\r\\n-	Rechten op UAS en wie si beheerder van UAS? Helpfunctie / handleiding.\\r\\n-	Syllabus rechten. \\r\\n', '2016-04-04 09:12:58'),\
(20, 24, 124, 'Yvonne Knoop 1-4-2016\\r\\nOnderwijscoordinator verantwoordelijk voor logistiek achter de opleidingen, cijferadmin,  studentenadmin (inschrijving, bijvakkers, intekenen, afstuderen, decentrale selectie) vaststelling onderwijs, studiegids, oftewel gehele logistieke keten en dus ook roostering.\\r\\n-	Het gaat goed met Aglaia.\\r\\n-	In oktober met Martin en Robin rooster gemaakt\\r\\n-	Achterwacht, centraal, wie pakt de achterwacht op , mailbox. \\r\\n-	Aan Anneloes destijds lijstje gegeven, met vragen, maar niet beantwoord\\r\\n-	Wat hoort bij een roostering, waar kunnen we op rekening, wat moet een faculteit zelf doen?\\r\\no	Intekening vollopen, \\r\\no	capaciteits beheer, bijplannen, verhogen capaciteit, wie houdt het in de gaten. \\r\\no	Ac struc. \\r\\no	Tentamenplanning. Wie stelt tentamenrooster op?\\r\\no	Uitgangspunten \\r\\n-	Summercourse, reserveren van de digitent, allumnidagen in onze dagen, enz. heeft niets met rechten te maken maar wel in gebouw, Ik krijg nog volledig lijstje van Yvonne Knoop\\r\\n-	Tevreden met Aglaia. \\r\\n-	Te wachten wie gaat wat doen?\\r\\n-	Uitvraag van de roosteraars was niet geregeld. Semester 2 geregeld?\\r\\n', '2016-04-04 17:58:19'),\
(21, 24, 126, 'Gesprek Erna \'96 Marjolijn 5-4-2016\\r\\nagenda: Stuurgroep, Agenderen bij HO, Joost, Trudie onderdeel commissie, \\r\\n\\r\\nStuurgroepleden:\\r\\nErna benoemt dit met Nico, wacht nog op een nieuwe hoofd bedrijfsvoering om dit te bespreken. \\r\\n-	Telefonie / computers\\r\\nOver project: \\r\\n-	Erna zou stuurgroepleden vragen. Rob ? Hij is dan de continue factor. Erna gaat gesprek aan met Rob, vandaaruit kijken, of Rob of Nico van Stralen (FALW). Erna ronselt alle stuurgroepleden (HO/VB/OPO). \\r\\n-	Eind april eerste stuurgroep overleg, informererd. Haalbaar? \\r\\n-	Het is een project! Zitten fase van financien. Staat op de lijst met dingen die besproken worden. Project gaat door. Financiering is nog pending.\\r\\n-	Temperen verwachtingen in HO middels presentatie\\r\\n-	ACTA: Sandra van Bruggen, nieuw HOWB\\r\\n-	Periode aangeven, project gerelateerde taak, profiel opmaken, met Suzanne, langs de TO.\\r\\n-	Telefonie: extra nummer op maandag. Doorverbonden naar mobiele telefoon om gebeld te worden. \\r\\n-	Kosten van Linq, doorverbinden.\\r\\n-	Mobiele telefoon bespreekbaar. \\r\\n-	Trudie onderdeel commissie, Erna benoemt dit met Nico, wacht nog op een nieuwe hoofd bedrijfsvoering om dit te bespreken. \\r\\n-	Vraag Trudie naar voortgang hierover. ', '2016-04-05 10:45:00'),\
(22, 24, 126, 'Clusteroverlg FEWEB, FGW, FGG.\\r\\n\\r\\nPeter, Saskia, Anneke, Maritha: 7-4-2016\\r\\nAgenda: \\r\\n-	Aanlevering uitvraag\\r\\n-	Roosterproces,\\r\\n-	Achterwacht \\r\\n-	Zalen godgeleerdheid \\r\\nAanlevering data: \\r\\nFEWEB: nog niet binnen, bepaalde: minoren niet binnen, Els in overleg Maritha over de minoren. Wanneer is onduidelijk.\\r\\nPeter heeft opleiding gehad. Peter kan mee aan de slag. Volgt nog een bachelor. Nog een minor economie. Het curriculum is nog niet bekent voor wat betreft minoren.\\r\\n Aanlevering van tentamengegevens jaar 3 komt nog van Els naar Peter.  \\r\\nPeter: economie 1 en 2, master, economie jaar 3???\\r\\nFGG: eerste en tweede jaar, binnen. Minoren en masters nog niet helemaal.\\r\\nFGG: houdt vast aan lestijden drie uur. Krijg mail van Saskia .\\r\\nFGW: alles is bij de BAS-er binnen en aan het verwerken. Aan het wachten op spullen. Verwerking BAS is knooppunt. \\r\\nRoosterproces: \\r\\n-	Anneke:met aglaia en ron contact gehad, tussen faculteiten, gaat heel prettig, \\r\\n-	Saskia: krijgt moeilijk gevoel bij het aanleveren van aantallen, zoekt naar of aantallen  uitvoorzorg plannen ze te hoog in, op basis van een piek twee jaar geleden (ivm aanpassing stufi regeling).\\r\\n-	Half augustus goed kijken naar rechttrekken van tegrote zalen versus daawerkelijke inschrijving. \\r\\n\\r\\nAfgesproken dat cluster zelf gaat werken aan een \\r\\nSaskia heeft maar 4 zalen, heeft te weinig zalen. Na knelpuntenfase , wordt erg druk, wachten tot vlak voor de leenrechten.Voordat de leenrechte open gaan, mag saskia als eerste erin, gezamenlijk.\\r\\n-	 \\r\\n\\r\\n\\r\\n', '2016-04-07 10:05:20'),\
(23, 24, 126, 'Clusteroverleg FSW, RCH (NIET AANWEZIG) en FGB (7-4-2016)\\r\\n-	Overdracht voor de masters research masters psychologie en pedagogiek.\\r\\n-	Aanlevering roosteruitvraag\\r\\n-	Roosterproces\\r\\n-	Achterwacht\\r\\n-	Mededeling\\r\\nFSW: alles binnen qua roosteruitvraag\\r\\nFGB \'96 BW: bachelor alles binnen, jaar 3 en masters, ontbreekt 15 @ 20%. Als niet binnen dan pak ik het van vorig jaar, roosterbrief van jaren geleden. \\r\\nOok over BW: docentopleiding: apart geroosterd, zit niet in een SAP structuur. Losgemaakt rooster. Joost gaat navragen hoe dit zit. Waarom niet in Sap, waarom niet reguliere uitvraag proces.\\r\\nFPP: Alles binnen. Wijzigingen van de minoren. Vanmorgen een schema gehad van Carla over de minoren. Was joost niet duidelijk of er nog minoren geroosterd moet worden. Joost en Marijke zoeken dit uit. Volgende week donderdag is hierover gesprek met Anja en anderen. \\r\\nYvonne: veel overlegjes, waardoor niet in de flow komt. \\r\\nJoost: nog veel wijzigingen waardoor onvoldoende aan roosterproces. \\r\\n- Joost gaat duwen richting Annemarie voor rol carla inzake mailbox en secretariaat zalenplanning.\\r\\nResearchmasters is nog niet binnen, aan Carla gegeven. Maandag gaat het naar Aglaia en Yvonne, wat er nieuw is en rest is van vorig jaar \\r\\n\\r\\n  \\r\\n\\r\\n\\r\\n-	\\r\\n\\r\\n', '2016-04-07 11:11:44'),\
(24, 24, 124, 'Overleg Irma Schouten, 7 \'96 4\\r\\n\\r\\nBespreking projectplan OO: \\r\\n-	Enkele vragen besproken\\r\\nMozaiek besproken. \\r\\n-	Irma wil rapportage hebben .\\r\\nGevraagd aan FCO of wij de dummyzalen zelf willen doen. Irma is hier best positief over, neemt het op met haar team \\r\\nStatus PGO als aparte leenrechten. Waarom. \\r\\nLeenrechten Sem2: \\r\\n-	Zij sturen vooraf eerste een concept naar mij\\r\\n-	Ik bespreek met 1 persoon uit team, zitten er fouten in\\r\\n-	Daarna bespreken met FCO in teamoverleg\\r\\n-	Daarna formeel concept rondsturen \\r\\n-	Daarna leenrechten overleg. \\r\\nToewijzen rechten FCO tent buiten tentamenweken, dan \\r\\nInventariserend. Als er een voorstel is, dan aanhaken. We nemen geen besluit, maar inventariseren.  Low profile, een discussie, benefits uithalen, en daarmee naar Rianne gaan. \\r\\nMail naar Rianne. Intern procesje, wellicht van taken van FCO naar roosterteam. Meer organisatorisch dan processen. \\r\\nZien het niet zo groot, wie verwerkt het. ', '2016-04-07 12:57:50'),\
(25, 24, 124, 'Gesprek Rianne Loetjes 7-4\\r\\nProcesmanagement binnen de \\r\\nProcesregisseur en procesbeheerder Rianne.\\r\\nExpertgroepen, ketenoverleg, enz.\\r\\n\\r\\nBart is bezig geweest om gebruik van digitent beter te optimaliseren. Ron input geleverd maar geen terugkoppeling gekregen. \\r\\nBob van Graft, directeur IT, vond het ook een goed idee. \\r\\nProblemen in de digitent:\\r\\n-	iCT problemen \\r\\n-	maar vooral ook te laat aanleveren van digitale toetsen door docenten', '2016-04-08 06:34:01'),\
(26, 24, 124, 'Gesprek Florien de Ruiter / Afke 5-4-2016\\r\\n-	Afke galman, Onderwijs en studentzaken, roostering bachelor en research masters. \\r\\n-	Florien de Ruiter, hoofd owb, inrichting is anders, geen beleidsmedewerkers in team. Wel mensen in dienst die belast zijn met administratief/organistorische studieadviseurs.\\r\\n-	Team master :plannen masterstages. Front office en back office, diplomeren, studieadvieurs enz. \\r\\n-	Beleid: zit in team innovatie en beleid \\r\\n-	In dienst van VU MC, maar studenten zijn VU studenten, hybride constructie. Bestuurlijk gesplitst. Positie is anders, tov collega\'92s vu. Dingen gaan anders. \\r\\n-	Onze roosteraars zijn roosteraars van geneeskunde, maar participeren wel. Wat zij roosteren is buitengewoon complex, door de aard van de opleiding. Tekenen studenten zelf in op vakken, ipv studenten zelf intekenen, \\r\\n-	veel prakticum. \\r\\n-	Het roostering bij GN gaat prima, bijna altijd als eerste. Marijke zeer betrokken en zeer inhoudelijk. Samenwerking verloopt harstikke goed \\r\\n-	Voordeel: dat we zelf mensen inschrijven en bepaalde dynamiek hebben, maakt het makkelijker. \\r\\n-	Masterplanning, stages in ziekenhuizen, geen gebruik van leslokalen. Wel stages in ziekenhuizen.\\r\\n-	 Engelstalige onderzoeksmasters Biomedische Masters, wel groepsgewijs gepland en ingeschreven.\\r\\n-	Minor jaar 3, verbouwing minder lokalen en intensiever onderwijs.\\r\\n-	Marijke uitgenodigd voor team overleg maandagochtend,   10 uur bijschuiven. \\r\\n-	Wanneer we naar mei/juni gaan, dan marijke /Annemarieke ondersteunen? \\r\\n-	Floriens onderbuik is dat de roosteraars het niet gaan redden. Datum afspreken wanneer we elkaar weer treffen, na de leenrechten, omdat we dan zien of we het wel of niet redden. Vervolg 2 weken na leenrechten. \\r\\n-	Jos\'e9 van Schie: florien ziet problemen bij gebruik van UAS. Docenten zijn ook arts. Hun inzetbaarheid vraagt veel meer . ', '2016-04-08 06:38:25'),\
(27, 24, 127, 'Met Bart en Jos\'e9 van Schie over implementatie UAS S2,\\r\\n\\r\\nAnneke is de enige die UAS heeft getest.\\r\\nDocenten, sluit het aan? Vraag van Bart.\\r\\nDecember is geaccodeerd door groep: wel beschikbaarheid uitvragen, maar beschikbaarheid mag. Rekening houden met docentbeschikbaarheid? \\r\\nProcesinrichting vu breed het doel. UAS ondersteunt het optimale proces niet het huidige.\\r\\nDe opleiding\\r\\n\\r\\nVoor \\r\\nRoosterbrede kaders. \\r\\n-	Timeslots? Enz. \\r\\nTwee doelen: \\r\\n-	Roosteraars weten waar ze aan toe zijn. \\r\\n-	Vakcoordinatoren kunnen daarmee niet tegen opleidingsbrede afspraken ingaan \\r\\nUAS: invoer van andere data. \\r\\nVakcoordinatoren zijn zelfde die ook UAS studiegiods en roosteruitvraag doen\\r\\n\\r\\nImplementatie: \\r\\nKleine schaal of groot.\\r\\nBeleidmatige aanpak \\r\\nOmdat we halverwege het jaar zijn, is het niet mogelijk om de beleidsafspraken te wijzigen\\r\\nVakcoorindatoren zouden op de hoogte moeten zijn van de afspraken, roosterkaders. \\r\\n\\r\\n\\r\\nWaarom het niet in UAS staat:\\r\\n-	SAP voedt UAS\\r\\n-	Als je niet vooraf ingevulde roosters, dan weer je niet \\r\\nEr is geen output, anders dan een cvs bestand. ', '2016-04-08 12:36:32'),\
(28, 24, 126, 'Teamoverleg: \\r\\n- delen map: wordt G schijf, heb alle VU net ID\\'s nodig. \\r\\n- structuur, team denkt over ne en mailt mij evenuele voorstellen. Op agenda volgende week. \\r\\n\\r\\nRianne Sloetjes\\r\\n- adviseur onderwijs, QMP, procesregisteur digitent en toetsen en overloopzalen (tijdverlengers).\\r\\n- onderhoud voor de digitent is nodig, in 2012 opgezet, nu onderhoud nodig\\r\\n- probleem is dat IT te laat de gegevens voor digitaal toetsen  om goed te testen\\r\\n- moeten deadline naar voren geschoven\\r\\n\\r\\nProcesmanagement: \\r\\n- expertgroep toetsen en beoordelen (uniforme uitvraag van toetsgegevens)\\r\\n1) - wie wordt hiervan lid? Krijg nog extra info hierover\\r\\n- 1 keer per week of anderhalve week\\r\\n- wanneer er wijzigingsvoorstellen uitkomen, dan naar ketenoverleg\\r\\n\\r\\nKomt er een uitbreiding in de TenT? Nee.\\r\\nHardware? Niet direct, misschien laptops enz. \\r\\nKlaar voor 1-9-2016. Uitbreidi\\r\\n\\r\\nAls leenrechten sem2 hgetzelfde is als sem 1, dan verwacht geen problemen. Daarom: impm,em nieuwe leenrechtenstructuur per sem 1 2016-2017\\r\\n\\r\\nTwee weken vooraf de einde leenrechten, afspraken wie als eerste mag snoepen, in teamoverleg. Anneke aan zet. \\r\\n\\r\\nRechten , wie mist wat?\\r\\nteam mailt mij hoeveel het gebeurd, 3 uur b;lokken ipv 2 uur.Team mailt mij als vrijdagavond digitale tentAMES EENPROBLEEM gaat opleveren\\r\\nAgenderen boeken van tenmanens voor volgende week. Joost inbreng. \\r\\n\\r\\n \\r\\n\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n- \\r\\n \\r\\n\\r\\n\\r\\n\\r\\n\\r\\n', '2016-04-11 09:08:57'),\
(29, 24, 124, 'Gesprek Sandra Verbruggen. 14-4-2016\\r\\nGNK en ACTA hebben eenzelfde problematiek\\r\\n\\r\\nSandra is hoofd onderwijsbureau ad interim en ook hoofd van het planningsbureau. \\r\\nIs hoofd owb functie aan het invullen. \\r\\nDrie roosteraars en plannen ook zorg. Onze studenten behandelen ook patienten in dit gebouw. Koppelen onderwijs student docent en patient bij elkaar.  Gebruik Axium, Canadees patienteninformatiesysteem \\r\\nOmix is geweest om roostersysteem op orde te krijgen. Puinhoop.. Helemaal opnieuw begonnen. Toen heeft Sandra in Syllabus geroosters, toen naar excel en toen in Axium geroosterd. Naast roosterproces in Syllabus ook een ander proces ernaast. \\r\\nZoekt alleen aansluiting bij vernieuwing van het roosterproces. Er is behoefte aan een programma dat individueel kan roosteren en wat gekoppeld kan worden aan Axium.\\r\\nWat is een indivuduele planning. Studenten gaan 1 voor 1 op aparte stages, dat wordt nu nog in aparte planning opgenomen. Wens is zowel persoonlijk rooster als per groep. \\r\\nVerwachting is per sem 1 2018 echt geroosterd in nieuw systeem. Levert dat problemen op ? Nee maar wil wel graag meepraten over functionaliteit en wensen opnemen. \\r\\nOnderwijs wordt steeds individueler.  \\r\\nWat verwacht je van mij? Weinig . \\r\\nJan Komen is informatiemanager van zowel ACTA als VUMC. \\r\\nACTA lokalen beschikbaar. Willen niet dat andere studenten door het pand gaan. Is ingewikkelde discussie. Is er ooit samenwerking geweest, hoorcolleges. In gesprek hierover met FCO. Directieniveau. Vestiging in Almere komt in ACTA erbij. \\r\\n\\r\\n', '2016-04-14 12:49:00'),\
(30, 24, 108, 'Gesprek Berend oosterhuis over Groei XL en Startbaan\\r\\n\\r\\n-	Over PostNL, Tanja scheuder komt niet verder. Berend gaat Tanja verleiden om te kijken of ze te porren is om een gratis klein cursusje af te nemen zodat wij POST NL logo kunnen gebruiken voor Groei XL/StartBaan!\\r\\n-	Berend schuift aan bij gesprek IJsselvliet\\r\\n-	Lijst trainers voor GroeiXL:\\r\\no	Jos\'e9 Fikenscher (maakt ze de omzet die ze elaleert?)\\r\\no	Henk Boshove\\r\\no	Eric Nak\\r\\no	Huub Tuin (financien en wat het met je doet)\\r\\no	Lydia Lijkendijk communicatie en schrijven\\r\\no	Dame die ik heb gesproken in vergaderruimte Zwolle\\r\\no	Carla Honing \\r\\no	Richard Normann (groepsdynamica)\\r\\no	Dirk Jan Durieux\\r\\no	Berend Oosterhuis\\r\\no	\\r\\n', '2016-04-15 07:44:18'),\
(31, 24, 126, 'Teamoverleg 18-4-2016\\r\\n\\r\\n- slogan, men mailt mij\\r\\n- achterwachtbesproken, alleen zalen boeken door centrale roosteraar. \\r\\n\\r\\n-  kunnen we inschrijven op lessen naar achter schuiven, is nu medio juli maar studenten schrijven nog niet in ,\\r\\n', '2016-04-18 09:59:07'),\
(32, 24, 124, 'Rianne Sloetjes\\r\\n\\r\\nTed de Brabander en mensen van Digitent. \\r\\n1)	Geplande groepsgrootte is groter dan werkelijk aantal studenten komen. (kunnen / doen wij niets mee, plannen in wat we krijgen van onderwijs)\\r\\n2)	Er wordt buiten de bloktijden geroosterd, als er van afgeweken wordt, dan hebben ze een kwartier en dat is te kort om software klaar te zetten. Moet minimaal half uur zijn. (Wij kunnen dit niet inplannen, wordt door FCO gedaan) (Graag voorbeeld)\\r\\n3)	Indelen blokken (schriftelijk / digitaal), wordt dat door de roosteraars of door FCO gedaan? (Denk door FCO)\\r\\n', '2016-04-18 13:06:21'),\
(33, 24, 126, 'Status roostering Peter \\r\\nBa/Ma/minoren		totaal 65	Nu 5\\r\\nTentamens			totaal 300	nu 100 geroosterd. \\r\\n8 nieuwe minoren a 5 vakken	totaal 40	verdeling peter/maritha. \\r\\n Peter: 0,4 FTE voor FEWEB. FEW: 0,5.\\r\\n\\r\\n\\r\\nAfspraak: bachelor jaar 1 en 2 zijn hetzelfde als vorig jaar. Voorstel om die op hetzelfde plek te zetten. \\r\\nAfspraken: kopie wordt voor dit jaar herpland. Saskia en Peter kijken samen naar herplannen lessen vorig jaar bach 1 en 2\\r\\nTentamen: 100 van 300 geroosterd. Volgende week 200 tentamens. ', '2016-04-18 13:08:01'),\
(34, 24, 132, '- contract opvragen huidige systeem\\r\\n- continuering via CvB, document tekenen?\\r\\n- landschap beschrijven van roosterapplicaties in Nederland (is Schedule een waardig alternatief)\\r\\n- Gebruikersplatform Scientia/Syllabus afvaardiging\\r\\n', '2016-04-18 16:09:22'),\
(35, 24, 124, 'Hendrik Jan Bosma en Steven Loosekoot 20-4-16\\r\\nInterventie van Hendrik Jan \\r\\nRagina overspoeld door UAS. Lifegang en roosterverhaal\\r\\nAlex, uitgenodigd voor acceptatietest studiemonitor\\r\\nTeus, 4 mei gaan we life met iets, en ik weet er niets van, hoe zit dat nou?\\r\\nStudiemonitor. Ik weet dat het eraan zit kunnen maar weet niet wanneer. Er zit wat onvrede hoe zaken lopen. HJ is kwijt hoe de aansturing loopt. Wil ertussen om te borgen dat we elkaar niet.\\r\\nHet is nog project OSDD.\\r\\nEen aanspreekpunt richting de leverancier. Om helder te krijgen wat er nog gedaan moet worden. Er is nu een keer tussen dirk jan en marcel. Als er werk gedaan moet worden, dan is FB in de lead. Resource aanvraag: op ASDD is aanvraag gepland maar is nu afgelopen weken ver overheen gegaan.\\r\\nAfgesproken is dat Steven maandag met Erna het gesprek aangaat over de mogelijke implemntatoe \\r\\n', '2016-04-20 11:05:28'),\
(36, 24, 124, 'Sharon komt bij FEWEB vandaan, \\n6 jaar hoofd van deze afdeling Volg\\nGrote reorganisatie gehad. Helft van team komt van andere functies binnen VU. \\nFO is geweest , back office \\nInschrijven college geld en allerhande vragen aan Front office.\\nSharon kent evenknie van Erna bij Hogeschool Leiden. \\n ', '2016-04-20 15:00:27'),\
(37, 24, 126, 'Clusteroverleg FEWEB-FGB\\r\\n\\r\\nFGWStatus, moet nog wat gegevens binnenkomen, maar licht op schema. Krijg nieuw schema van Anneke. \\r\\nFEWEB:\\r\\nMaritha: \\r\\nAlles is binnen.\\r\\nBa; 3e jaar nog niet geroostered (minoren) \'96 sommige VU breed en sommige alleen FEWEB.\\r\\nMaster ook nog bijna niet (zitten paar veranderingen in). \\r\\nHet moet af. Verwacht dat je op tijd afkrijgt, zal wel! Ook afhankelijk van Peter, voor Peter. \\r\\nPeter: \\r\\n-	Tentamenrooster: 300 vakken per 1, 2, 3: zaten er 100 in, nu 170. Allle tentamens van vakken die dit studiejaar worden gegeven, behalve derde jaar. Tentamens die dit jaar worden gegeven, worden volgend jaar geveegd (bezemgroep, vak niet gegeven , nog wel tentamen). Die 130 kan die nog niet doen, want wacht nog op gegevens of het voor grote groep is. \\r\\n-	Nieuwe opleiding roosteren vraagt wat meer tijd dan normaal. \\r\\n-	Tentamen minoren derde jaar tentamens moeten er nog in. Komen boven de driehonderd. \\r\\n-	Peter neemt contact op met Els over vragren en vaststellen deadlines, omdat FEWEB nog niet een bepaalde essentiele keuze voor tentamens heeft gemaakt. \\r\\n-	Begonnen met vakken : EBE, kopieren van vorig jaar. Moeilijk om te zien \\r\\n-	Afgesproken dat Peter een lijst maakt met vakken en activiteiten en dat we deze maandag gezamenlijk bespreken . \\r\\n-	FEW: \\r\\nTentamen FEW zitten erin.\\r\\nAl heel wat opleidingen erin, Saskia  doet hetzelfde portie als vorig jaar, neemt daarmee wat van Peter over. \\r\\n-', '2016-04-21 13:43:16'),\
(38, 24, 126, 'Clusteroverleg FGB-FSW-RCH 21-4-16\\n\\nOver roosteren op vijdag avond: krijg voor dinsdag van Joost/Marijke nog dioor of dit voor hun speelt. (inmiddels doorgekregen dat dit niet voor hun speelt).\\n\\nRCH: jaar 1-3 jaar klaar. Tentamen gepland. Deel masters gepland, nog niet alle gegevens binnen, maar is benoemd, afspraak dat je krijgt wat vorig jaar is gepland. Masters erin: begin mei klaar. \\nFSW: bachelor klaar. Moet master en premaster nog plannen en nakijken. Alle gegevens binnen. Vandaag bachelor vak Project binnen gekregen. Tentamens, digitaal zit erin, anderen bijna, moet nog gecontroleerd worden. enz. \\nFGB\\nBW: 1en 2e jaar is af. (BW heeft geen kleine zalen, dus kan niet zalen koppelen) 3e jaar mee bezig, meeste zonder zalen. (HC en WC)\\nULO zit er bijna in. (met zalen omdat alleen op de zalen).\\nLerarenopleiding moet nog , is vaststaand schema, maar alle zalen in de naplanning. Van de masters nog niet alles binnen, dan zelfde hetzelfde jaar. \\nSpanningsveld: FGB moet misschien wel 50% van de zalen buiten domein zoeken ipv 10 % bij een andere \\nFPP: verwachten dat het op tijd klaar komt, geen zicht hoeveel er nog precies geroosterd moet worden. \\n3 FPP research masters. \\nFPP masters en research masters: Yvonne: puinhoop van wat is aangeleverd : roosteruitvraag + uas voor onderwijs + uitdraai van UAS onderwijs programmas\\n-	Mist programma onderwijs (jaar/cohort) (maar inhoud staat wel in UAS)\\n-	Mist aan roosteruitvraag gegevens van vakken. Yvonne geeft aan wat ze mist.  \\n-	Yvonne en Aglaia vraagt om verheldering bij Carla voor onduidelijkheid in aanlevering roostergegevens. \\nAls de BAS niet consequent is met codes en vaknamen dat bemoeilijkt het proces. (NL en EN). \\n', '2016-04-21 15:25:12'),\
(39, 24, 126, 'Teamoverleg 25-4-2016\\r\\n\\r\\nVergader verzoeken: nog niet duidelijk of dit bij roosteraar s hoort of niet. \\r\\nBesloten eenzijdig in oktover dat het niet bij de roosteraars gedaan. \\r\\nFSW wel\\r\\nFGW wel\\r\\nFEWEB niet\\r\\nFGB ook \\r\\nBETA \'96 internetzalenboeken: moest doorsecretariaat \\r\\nAfstemmen met Anneloes wat de status  is.\\r\\nIndelen van studenten in groepen. Bij FEWEB doet eerste jaar. BETA vu, begeleiden het proces even erbij \\r\\nPieter Roteveel over capaciteitsmanagement.\\r\\nVollopen van vak. 4 verschillende situatie van vollopen type vak:\\r\\n- vol is vol\\r\\n- gecontroleerd vollopen\\r\\n- vak vol, capaciteit vergroten\\r\\n- vak vol, en nu? (komt het meest voor!)\\r\\nRoosteraars zoeken uit naar schatting welke het het meest voorkomt. En argumenten doormailen naar Pieter. \\r\\n\\r\\nTentamen en inloop apart, koppelen kan ,maar is omslachtig, beter is om dit handmatig te doen. Sequicing. We kiezen. \\r\\nTentamen voor extra tijders in aparte tentamens. \\r\\nVunet\\r\\n- Bloktijden \\r\\n- jaarkalender\\r\\n- zaalfaciliteiten\\r\\n- \\r\\nKlein committee: \\r\\n- Marijke, Anneke, Bart. ', '2016-04-25 09:40:43'),\
(40, 24, 127, 'Met Yvonne Knoop over deelname pilot UAS:\\r\\n\\r\\n-	Was nauw betrokken bij UAS roosteruitvraag\\r\\n-	Nodig: Henk Huurman (extern tester), nodig /achter de hand als ze UAS niet snappen. \\r\\n-	Vragen komen bij Aglaia, moet achter het product staan\\r\\n-	Iemand die technische kant afhecht , \\r\\no	Bug, technische ondersteuning nodig. \\r\\no	Personen toevoegen? Vacatures. Kan iemand zelf een vacature persoon toevoegen. \\r\\n-	Zoals Yvonne het nu ziet is het best ingewikkeld\\r\\n-	Jelly,  Aglaia,   Anneke, Yvonne, samen door het systeem lopen. Plus Jeroen. Daarna aantal docenten. \\r\\n-	Wil eerst zelf zien, Aglaia en docenten en daarna pas beslissen.\\r\\nPlan de sprints en eerste bijeenkomst met aglaia, enz Op basis hiervan Ja of Nee.\\r\\n', '2016-04-25 15:19:23'),\
(41, 24, 124, 'Bila Irma 26-4\\r\\n\\r\\nHO overleg. \\r\\nProjectplan goedgekeurd? Ja. Volop aan het werven.\\r\\nManagement rapportages. Meeliften. \\r\\nTenT overleg buiten unijaka weken. Kunnen een pilot gaan initieren. Document nog verfraaien en dan vaststellen. \\r\\nAkkoord met uniforme tijden regulier tentamen. \\r\\nGevraagd 31 naar 30 mei ivm iet iedereen werkzaam op dinsdag. \\r\\nKunnen we wat met de knelpunten van MF wat?\\r\\nLilian van Gullik. Escalatie. Dir bedrijfsvoering MF. \\r\\nBenieuwd hoeveel knelpunten er zitten. Medio mei hebben we beter zicht erop. Kunnen we de knelpunten van GNK MF, oplossen? MF zit erbij. Medio juni , gezamenlijk beeld over wat voor knelpunten zijn. Alle betrokken partijen die in de leenrechten zit. \\r\\nVunet roostering, FCO zal voorstel van klein committee aanvullen, niet zozeer deelnemen in klein committee/ \\r\\nPedel Janco Bonnink/Nick /Bart/Irma afspraak over \\r\\nKCO07 ruimte eens per twee weken op donderdagavond na laatste onderwijsblok (kwart over 5) komt rialto films.', '2016-04-26 13:32:31'),\
(42, 24, 124, 'Gesprek USR Desiree en Julliette\\r\\n\\r\\nDesiree Baaleman 21, ba geneeskunde, faculaire raad en doorgestroomd naar centraal. 21 jaa. Vicevz, geinteresseerd in onderwijskwaliteit , minder met de organisatie en financien. \\r\\nJulli\'ebtte  Rontertrap, nu oudheids studie UVA, ba geschiedenis eerste facultaire studentenraad en daarna USR. Joint degree, met UVA, plek zowel bij UVA als hier op campus. \\r\\n`- op 3 plekken staan roosters, en welke is van mij: \\r\\nVunet (persoonlijk rooster)\\r\\nrooster.vu.nl rooster (algemeen)\\r\\nBlackboard staat een rooster (werkgroep) \\r\\nVurooster.nl, agenda implementeren in je agenda. \\r\\nWaarom kun je op vertrouwen. \\r\\nVerouderde studiegidse, vak en semester geswitched. \\r\\nCommunicatie , wat vind ik mijn goede rooster, hoe laat begint precies mijn tentamen, welk vak is wanneer en wat is de inhoud van mijn vak. ', '2016-04-26 14:49:50'),\
(43, 24, 127, 'Expertgroep onderwijsplanning (2-5-2016)\\r\\nYvonne / Willem/Alex Noteboom\\r\\nNiet: Aglaia, Asteria (FEWEB), Ren\'e9 Hogervorst (Bas-FGW), Ellen de Roo (communicatie) en Pieter Jan Kerstens (communicatie)\\r\\n-	UAS na de studiegidsfase, gebruik UAS monitoren/uitvraag Ac Struc.\\r\\n-	Logistieke kalender opstellen, soort grote ketenplanning\\r\\n-	Prioritering van digitale tentamens, Start et zo groot mogelijke tentamens en daarna restruimte opvullen met kleinere tentamens. Of zelf bepalen.\\r\\n-	Vaststellen curr.\\r\\n-	Tentamenplanning, jaarkalender\\r\\n-	Inrichten Ac Struc.\\r\\n-	Koppeling beheer\\r\\n-	Studiegids\\r\\n-	Tent organisatie\\r\\n-	Rapportages\\r\\n-	Intekenen minoren en keuzevakken (OSD, toetsing functionaliteit)\\r\\n-	Bij roosteruitvraag, de wensen voor vollopen meenemen. \\r\\n\\r\\n', '2016-05-02 12:56:16'),\
(44, 24, 126, 'Teamoverleg 9-5-2016\\r\\n\\r\\n\'95	KC007, na kwart over 5. Wanneer gata dit in? Volgend jaar?\\r\\n\'95	Leenrechten ook op zaterdag? Nee! HOVO regelt dit apart met FCO. \\r\\n\'95	Een lunch met z\'92n allen, zelf meenemen.\\r\\n\'95	Klein committee incidentele roosterwijzigingen (Anneke, Joost, Saskia, Dirk Jan)\\r\\n\'95	Vanuit ac struc kan op ingeschreven tentamen voor ET niet in persoonlijke rooster zichtbaar gemaakt worden, alleen regulier ingeschreven tijden. \\r\\n\'95	Spelregels buiten Unijakawerken, met irma afstemmen en volgende week werkafspraken maken. \\r\\n\'95	Schaduw roosters, account blackboard om te kijken . Graag voorbeelden. \\r\\n\'95	Volgende week dinsdag knelpuntenoverleg , facultatief. Initiatie Anneke. \\r\\n', '2016-05-09 09:55:06'),\
(45, 24, 127, 'Maandag even afstemmen met Erna en Hanna.\\r\\n\\r\\nStuurgroep anderhalf uur.\\r\\nPid toesturen\\r\\nPresentatie over OO\\r\\nUitleggen dubbelrol teamleider en projectleider\\r\\nTerug en vooruitblik, tijdpad te verwachten milestones, \\r\\nOp hoofdlijnen sturen\\r\\nEerste keer op meer detail daarna, hoofdlijnen. ', '2016-05-10 11:04:06'),\
(46, 24, 124, 'Bila Irma 10-5\\r\\nTentamen zaal:\\r\\nEmergohal 700 \\r\\nVu lokaal 300 en 254 plekken.\\r\\nAuditorium? 200\\r\\nInitium collegezaal? 150\\r\\nTotaal 1250 plekken ipv 1500. Probleem? \\r\\nMeer opgeknipt worden. \\r\\nWeek 51 en week 5. Team overleggen inventariseren mogelijke obstakels en oplossingen. RAI is niet meer betrouwbaar. Op zoek naar iets anders. \\r\\nKrijg van Irma no show op tentamens. \\r\\nOverlegd over tentamen buiten unijakaweken , rechten en spelregels van Irma. \\r\\n\\r\\nZie verder notitie document van Irma!', '2016-05-11 15:01:04'),\
(47, 24, 126, 'Cuisteroverleg RCH FSW FGB\\r\\nRCH:\\r\\n1)	Concept rooster uitgedaan. Stromen reacties op binnen. 23 mei deadline\\r\\n2)	Aantal activiteiten zonder lokaal.\\r\\n3)	Wanneer Aglaia op vakanbtie is, mail notificatie dat spoedjes naar Joost gaan. \\r\\n4)	Dirk Jan vraagt rechten S+ aan voor Joost voor Rch. Dus ook voor Yvonne en Joost\\r\\n5)	\\r\\nFSW: \\r\\n1)	Conceptroosters, verwacht: di 31 mei. Tot 13 juni reageren (2 weken) \\r\\n2)	Moet nog 8 vakken. Belle vue moet nog \\r\\nFGB\\r\\n1)	Bewegingswetenschappen jaar drie bijna, 1 en 2 al gereed\\r\\n2)	Master, researchmaster en fysio master\\r\\n3)	Verwachte deadline: 23 mei. \\r\\n4)	ULO zit erin\\r\\n5)	Veel kleine zaalbehoefte, act waar geen zalen aan gekoppeld zijn\\r\\n6)	Tentamens, omdat het niet goed stond. Met half uurtje erbij.\\r\\n7)	FPP bachelors: Marijke: is nog vraag vanuit onderwijs om bach ac struc te wijzigen. Ik krijg van Marijke nog mail over wat er aan wijziging is gevraagd/wordt doorgevoerd.\\r\\n8)	FPP masters: klaar, op haar na. 2 vragen staan uit via Carla \\r\\n9)	FPP Research masters. 23 vakken. (misschien iets overlap) moet nog geroosterd worden. \\r\\na.	Iemand anders doen, Anneke?\\r\\nb.	Rooster afblokken (Aglaia/Joost)\\r\\nc.	Leenrechten nog niet openzetten FGB\\r\\nd.	Extra werken door iemand?\\r\\ne.	Roosteren na opheffen leenrechten.\\r\\n10)	Tentamens FPP masters? Geen informatie ontvangen. Carla?\\r\\n', '2016-05-12 15:33:15'),\
(48, 24, 126, 'Cuisteroverleg RCH FSW FGB\\r\\nRCH:\\r\\n1)	Concept rooster uitgedaan. Stromen reacties op binnen. 23 mei deadline\\r\\n2)	Aantal activiteiten zonder lokaal.\\r\\n3)	Wanneer Aglaia op vakanbtie is, mail notificatie dat spoedjes naar Joost gaan. \\r\\n4)	Dirk Jan vraagt rechten S+ aan voor Joost voor Rch. Dus ook voor Yvonne en Joost\\r\\n5)	\\r\\nFSW: \\r\\n1)	Conceptroosters, verwacht: di 31 mei. Tot 13 juni reageren (2 weken) \\r\\n2)	Moet nog 8 vakken. Belle vue moet nog \\r\\nFGB\\r\\n1)	Bewegingswetenschappen jaar drie bijna, 1 en 2 al gereed\\r\\n2)	Master, researchmaster en fysio master\\r\\n3)	Verwachte deadline: 23 mei. \\r\\n4)	ULO zit erin\\r\\n5)	Veel kleine zaalbehoefte, act waar geen zalen aan gekoppeld zijn\\r\\n6)	Tentamens, omdat het niet goed stond. Met half uurtje erbij.\\r\\n7)	FPP bachelors: Marijke: is nog vraag vanuit onderwijs om bach ac struc te wijzigen. Ik krijg van Marijke nog mail over wat er aan wijziging is gevraagd/wordt doorgevoerd.\\r\\n8)	FPP masters: klaar, op haar na. 2 vragen staan uit via Carla \\r\\n9)	FPP Research masters. 23 vakken. (misschien iets overlap) moet nog geroosterd worden. \\r\\na.	Iemand anders doen, Anneke?\\r\\nb.	Rooster afblokken (Aglaia/Joost)\\r\\nc.	Leenrechten nog niet openzetten FGB\\r\\nd.	Extra werken door iemand?\\r\\ne.	Roosteren na opheffen leenrechten.\\r\\n10)	Tentamens FPP masters? Geen informatie ontvangen. Carla?\\r\\n', '2016-05-12 15:33:15'),\
(49, 24, 124, 'Bila Cees van Gent\\r\\nSinds 2012 2013 zijn er werkafspraken over joint degree, \\r\\nRol Wim Houben, FEW FALW, FNWI (UVA)12 joint opleidingen\\r\\nAfspraak roostering hierover; afspraak was: wanneer vak georganiseerd werd op locatie, was de locatie verantwoordelijk voor het rooster. Had te maken met beschikbaarheid van lokalen. Contact tussen Saskia en roosteraar van de Uva. \\r\\nAls vak aan de uva werd gegeven, werd voor die periode: dit vak wordt aan de UVA gegeven, kijk op uva.nl. \\r\\nWas tot 31 augustus 2016\\r\\nVanaf zomer 2016: \\r\\n-	Zijn nu 6 joint degrees (5 UVA en 1 VU) (niet uitgevraagd door VU)\\r\\n-	Penvoerder is verantwoordelijk voor totale administratieve afhandeling. \\r\\n-	In beginsel zullen ze niet hier niets organiseren. \\r\\n-	Scheikunde / natuurkunde zal waarschijnlijk niet passen bij de UVA, moet naar VU. O2 gebouw omdat WN gebouw minder prakticum zalen heeft. O2 kunnen studenten zonder pasje niet in. (Irma Schouten). \\r\\n-	Saskia, korte lijnen FWNI, liaison accountmanager.  \\r\\n-	Ze doet wat ze normaal doet. \\r\\n-	Alles waar joint degree op staat, ligt onder een enorme vergrootglas. \\r\\n-	\\r\\n', '2016-05-13 16:00:06'),\
(50, 24, 126, 'Werkoverleg Erna, Marjolijn, Dirk Jan 17-5-2016\\r\\n\\r\\n1)	Project\\r\\na.	26 mei stuurgroepvergadering. \\r\\ni.	Agenda akkoord?\\r\\nii.	Idee\'ebn over format vooruit-terugblik? \\r\\nb.	Projectleden werven:\\r\\ni.	Procesbeheerder weer uitgezet (Intermediair en vu.nl\\r\\nii.	Data analist nu 1 sollicitatie, interessante kandidaat\\r\\nGoed aangeven, dubbel rol projectleider en teamleider.  Stuurgroep moet sturen op het project. Scope erin en erbuiten. \\r\\nOverzicht geesteswetenschappen. \\r\\nOverzicht mozaiek schema. Het is zinvol dat we hierop sturen. \\r\\nAgenderen bij OPO en VB. Vraag aan hun, op welk niveau ze de voorbeelden willen inschieten, zijn dit goede voorbeelden. \\r\\n2)	Taakverdeling roosteraars, vastlegging?\\r\\nErna checkt nog Susanne over functieprofiel. \\r\\nAfspraak die nog op papier moet gemaakt worden. \\r\\nNT2, enz afspraken over maken. Bart !\\r\\n3)	Roosterproces\\r\\n\\r\\na.	Sterke roosteraars springen in bij zwakkere broeders\\r\\nb.	Met Susanne bespreken over Peter, over afspraken maken. \\r\\nMarijke ? NADENKEN OVER VERVOLG\\r\\nSeptember knopen doorhakken over Aglaia! Vlootschouw. \\r\\n\\r\\n4)	NSE resultaten?\\r\\n\\r\\n5)	Roosteruitvraag UAS status update.\\r\\n\\r\\na.	20 K akkoord\\r\\nb.	Woensdag pilotgangers bij elkaar,\\r\\nc.	Daarna gesprek met leverancier\\r\\nd.	Pieter is projectleider, en regelt e.e.a.\\r\\n\\r\\n6)	Landelijk gebruikersoverleg Scientia\\r\\na.	Feedback Walter, uitgezet Eric\\r\\nProcessen onder review: \\r\\n-	tentamen in roosters\\r\\n-	verdeling TenT \\r\\nRoosteraars moeten binnen beleidsafspraken blijven. Mails doorsturen aan Erna. In theorie is er hetzelfde jaarrooster. ', '2016-05-17 11:09:03'),\
(51, 24, 126, 'Clusteroverleg Betas + FEWEB + FGW 17-5-2016\\r\\n\\r\\nFEWEB\\r\\n-	Nog niet alles binnen, ba tutor overleggen. Nog niets binnen. \\r\\n-	Peter: van het weekend bezig geweest. Heeft 1 \'bd  minor geroosterd van vrijdag. \\r\\n-	Zalen vrijgegeven aan Maritha\\r\\n-	Code groen.\\r\\nFGW\\r\\n-	Goed, mis nog 1 2 jarige minor by filosofie, \\r\\n-	Veel nog zonder zaal, na leenrechten opheffen\\r\\n-	Groen\\r\\n\\r\\nPPE: \\r\\n-	Vandaag bijna definitief gemaakt\\r\\n-	Code groen\\r\\n\\r\\nFEW\\r\\n-	Nog geen prakticum rooster ontvangen. Beloofd om dat aan te leveren, maar door verhuizing , \\r\\n-	FEW, wat heeft Peter nog openstaan? \\r\\nFALW\\r\\nRon:\\r\\n-	Ba groen\\r\\n-	Roostert ook als geen gegevens binnen krijgt. \\r\\nTrudie: \\r\\n-	Minoren klaar\\r\\n-	Premasters klaar\\r\\n-	Masters, deels\\r\\n-	Aard, economie en ecology , nog niet, net uitsluitsel 884. Andere nu voor het eerst 884, ipv5*4.  \\r\\n-	\\r\\n', '2016-05-18 11:47:04'),\
(52, 24, 126, 'CLusteroverleg Beta\\'s 23-5\\r\\n\\r\\nBeta Clusteroverleg\\r\\n\\r\\nFALW\\r\\nRon: \\r\\n-	Gaat goed, gaan het redden. \\r\\n-	Concept versturen: na zalen vrijgeven\\r\\nTrudie:\\r\\n-	Hier en daar nog wat afspraakjes over hoe het rooster moet gaan\\r\\n-	Van enkelen nog geen gegevens omdat er geen docent bekend is, \\r\\n-	Grootste deel erin. \\r\\nPractica zalen FALW: onduidelijk of FALW O2 gebouwen gaan gebruiken.\\r\\nFEW:\\r\\nSaskia:\\r\\n-	Komt wel af, moet nog wel dingen doen.\\r\\n-	Joint degrees met UVA is al geroosterd, maar checkt nog even volgende week. \\r\\nPeter: \\r\\n-	Nog 7 minoren moeten er nog in, 40a50 vakken. \\r\\n-	Saskia kan er ook nog even naar kijken\\r\\nWaarschijnlijk conceptrooster volgende week di of do versturen.\\r\\nGezamenlijk versturen? Streven naar volg week donderdag! Anders 7 juni.\\r\\n', '2016-05-23 12:37:24'),\
(53, 24, 126, 'Clusteroverleg FSW, FGB, FSW 24-5\\n\\nFSW: \\n-	Alles aan het nakijken. Alles staat erin. \\n-	Concept roosters, volg week di of woensdag. 2 weken kijken. Dan definitief. \\n-	Status groen.\\nFGB:\\n-	Marijke moet nog een deel doen. Verwacht donderdag af te krijgen\\n-	Joost moet nog 1 master erin, 6 vakken. \\n-	Zalen is erg afwachten \\n-	Indien moet afknippen, dan past die niet meer, hopelijk kan lokaal vrijmaken. \\n-	Conceptrooster, voor een deel uitgezet maar nog niet officieel\\n-	Conceptrooster, ergens eind volgende week. \\n-	Ze willen de werkgroepen voor psychologie ophogen van 17 naar 25. Is niet handig qua leenrechten. Marijke gezegd tegen anja ruhland. \\n-	Annemarie is ingelicht. Is ook niet blij mee. \\n-	Het wordt nee, tenzij er nog tijd en ruimte is om passende zaaltjes te vinden \\n-	FPP zit erin, incluis tentamens. \\n-	Anneke research masters. Aglaia helpt morgen. \\n-	FGB status: bijna groen. \\nRCH: \\n-	Concept gegevens teruggekregen, mee bezig om wijzigingen hierover door te voeren\\n-	Status groen, wel opmerking over lokalen\\n00 zalen zijn erg schaars, zorgelijk. \\n\\n', '2016-05-24 12:46:08'),\
(54, 24, 124, 'Irma bila 25-5-2016\\r\\n\\r\\nRAI alternatief: \\r\\n-	Emergo hallen is gecontracteerd\\r\\n-	Sportcentrum vu moet nog afgesproken worden. \\r\\n\\r\\nLeen rechten semester 2, concept moet 9 juni aangeleverd worden. \\r\\nWelke extra zalen komen erbij van O2? Wanneer krijgen we dat? \\r\\nLeenrechten op computeralen. Er zijn 4 dedicated zalen bij faculteiten. Werkgroep geweest, maar is ondergesneeuwd. \\r\\nKunnen we met z\'92n drie\'ebn overleggen, bart-dirkjan-irma.\\r\\n', '2016-05-25 12:35:56'),\
(55, 24, 127, 'Pilot UAS, sprint 2, 25-5-16:\\r\\n-	Vinkje akkoord bij beleidsafspraken\\r\\n-	Opmerkingen velden, teveel?\\r\\n-	Tentamen \'96 vanuit ac struc of standaard beschikbaar?\\r\\n', '2016-05-25 18:07:11');\
INSERT INTO `project_notes` (`id`, `user_id`, `project_id`, `notes`, `created_datetime`) VALUES\
(56, 24, 126, 'Teamoverleg/knelpuntenoverleg 30 mei.\\r\\n\\r\\nTeamoverleg : \\r\\nIrma nogmaals vragen \\r\\nFEW: \\r\\nMaandagen zalen \\r\\nFSW: \\r\\n2 keer 00 zaal tekort op maandag\\r\\n00 , 60 zalen\\r\\n\\r\\nNaar aantallen kijken, indikken in zaal.\\r\\n-	Indikken, van \\r\\n-	1 persoon kan inventariseren, wie er te ruim zit. Bestand maken grootte, \\r\\n-	Uitdraai van \\r\\n-	Rijn en maaszaal van 200 is veelvuldig beschikbaar.\\r\\n-	Wie kan de kosten dragen voor deze zalen. \\r\\n-	Stempel \\r\\n-	9 juni overleg van middag\\r\\n-	Beschikbaarheid van HOVO zalen, hoe wat. Vraag aan FCO of ze dummy zalen willen overzetten en daarna leenrechten willen opheffen. Eerst anneloes vragen.\\r\\nZaterdag is geen probleem voor Nick Henning\\r\\n29 september, belle vue is vol, voor congres. (voorrangscongres)\\r\\nComputerzalen in de leenrechten? Bart laatste stand van zaken.\\r\\n\\r\\nGesprek Jeroen over HOVO dummy niet teruggezet. \\r\\nLeidinggevende : Carolien van Bergen, c.b.van.bergen@vu.nl\\r\\nOmzetten niet een optie problemen; 6a33 dummy hovo, quamtum mechanica, alternatieven, niet in \\r\\n-	F607, haal FALW haal ze er uit. Er is geboekt door FALW geboekt. Waarschijnlijk in de \\r\\n-	14A33 , al hun activiteiten, beperkingen, geeft niet als alternatief de orginele zaal. \\r\\n-	En geen tijd voor. \\r\\n', '2016-05-30 14:27:05'),\
(57, 24, 126, 'Inhuur Marijke Monna\\r\\n\\r\\nsinds 19 nov 2015\\r\\nwekelijks tussen 8 en 9,5 uur per week gedeclareerd, excl vakanties\\r\\nUurtarief 36,59 +6,26 km vergoeding per dag.\\r\\n', '2016-05-31 10:14:33'),\
(58, 24, 124, 'Bila Karin Bijlker\\r\\n\\r\\nGesprek met Karin Bijker\\r\\n\\r\\nErna werkt vooral met haar. Yvonne zelf tegen Erna vragen. En dat ik het uitzet. \\r\\nEerste half jaar was er geen verschil. Maakte zich zogrn over UAS, maar toen het er bijna kwam, wilde er graag mee werken\\r\\nTweede half jaar, had ze last ervan dat er op een andere manier van werken. Maakt zich zorgen over het grote zalenoverleg. \\r\\nVanuit de faculteit is Karin erg blij dat Yvonne zeer dicht bij de faculteit zit. \\r\\nFSW wil 215 regulier en 245 inclusief extra tijders\\r\\n\\r\\n', '2016-06-06 15:20:03'),\
(59, 24, 124, 'Gesprek Nico van Straalen 21-6\\n\\nRoostering is geen probleem situatie. Wil niet zeggen dat alles onder conrole is. \\nPunten: intern is: compleetheid van de roostering, roostrgegevens graag gebruiken als input voor docentvergoeding . Gaan interne geldstromen veranderen, begin 2017. Vergoeding onderwijs, vanuit de faculteiten, werkelijke inzet van docenten. Er staat een prakticumlkaal geroosterd staat een docent bij. Niet zichtbaar hoeveel studenten erbij zitten en hoeveel assistentie. Alleen dingen per zaal, niet per docenteninzet. Het is niet geformaliseerd welke docent assistent, prakticum \\nGerrit oomens regelt prakticum zalen\\n\\nParkticum. Overzicht van roostering van prakticum voor komend jaar, maar nog niet naar centraal roostering S+. Dus eerst op excel. Bart van Ommen coordineert. Gebouwbeheer O2 is lastig. Mensen die in O2 zitten willen graag in O2 prakticum geven, maar spullen / apparatuur is nog niet verhuisd. \\n\\nScience owl. Uva moet naar UAS. Kunnen wij helpen (ESC educational sevice center = onderwijsbureau van FNWI (UVA) ) Dit moet door College van Bestuur UVA?VU besloten worden, anders gaat ESC niet bewegen. \\n\\nSchaduw rooster, zowel vooraf (aanleveren volledig rooster = ongewenst, stuur hem voorbeeld) als achteraf wijzigingen in blackboard eigen rooster maken. Waarom? omdat je op zo\'92n vroeg stadium aanleveren, docenten zijn niet gemotiveerd om na te denken. Inhoudelijk nadenken pas een maand van te voren. Het is communicatie (gedrag) voornamelijk om dit te verbeteren. Je geeft docenten de mogelijkheid om kleine dingen aan te passen. Actie: meer naar onze docenten uitstralen dat er goed over nagedacht en accepteren. Via Cees zou het moeten lopen. Korte notitie? Hebben een overleg met opleidingsmanagers waar dit wordt besproken. \\n\\nRelatie met NSE. Docenten en studenten willen het graag in Blackboard. Roostermogelijk in blackboard: is meer gewoonte en cultuur dan dat er een goede reden voor is. \\n', '2016-06-21 09:12:14'),\
(60, 24, 126, 'Beta clusteroverleg 21-6\\r\\nFEW: \\r\\nstatus Verwerken van reacties op concept rooster. Best wel veel maar wel onder controle. Peter zit er niet ontspannen bij. Ligt aan hem. 50 a 60 mail. Zitten dingen bij die veranderingen vragen. Iedereen bij FEWEB heeft bericht gehad. \\r\\nZijn geen dingen waar we Dirk Jan op af moeten sturen. Nog 10 werkdagen totdat einde rooster, verwachting is dat het op tijd klaar komt. Geen problemen. \\r\\nUiteindelijk komt het wel goed. Veel mail is nu het gevoel van Overwelmed. Jakkeren. \\r\\nFALW: \\r\\nWij doen nog niets op DEF in S+. Omdat, het academische structuur goed zit. Tycho en Willem  moeten seintje geven wanneer Ac Struc goed staat. Willem valt onder Cees. Door op def te zetten koppelt die activiteit aan vak-CE object.  Voor de 27e juni moet alles op DEF staan. Handmatig steeds zetje geven (volgens RON) kost veel tijd voor de roosteraars. \\r\\nTrudie zet (vrijdag) alles voor FALW op Def. \\r\\nTentamenrooster, is nog niet af, teveel fouten in ac struc. Jaarschema\'92s ontbreken ontbreken. \\r\\nAchterwacht FEW: tijdens de zomer is er altijd iemand aanwezig. ', '2016-06-21 14:01:32'),\
(61, 24, 126, 'Bila Erna, Marjolijn, Dirk Jan  13 juni\\n\\n12 juli naar VB. Presentatie. BVS. Dinsdag ervoor alle stukken klaar. Overzicht stand van zaken en eerste semester, hoe ziet het eerste semster eruit. Ook daar melden over het team , management van verwachting. \\nOPO ook een keer. Uniformeringsafspraken. Beter om dat ergens in nieuwe studiejaar plannen. \\n \\nNo Show tentamens, goed om inzichtelijk te maken met geld enz. goed om bij VB . Desiree Baaleman eens hierover checken. \\n\\nMarijke blijft bij FGB roostren tot de Kerst. Vraag aan Martin kostenplaatsnummer voor FGB tbv doorbelasting. Aangeven . \\n\\nStuurgroep vergadering\\n-	Voortgang melden, \\n-	Syllabus SOS + notitie bespreken\\n-	UAS roosteruitvraag laten zien  + management informatie', '2016-06-21 14:03:04'),\
(62, 24, 126, 'Teamvergadering 4-7-2016\\n\\nJoost doet inwerken aimee, HOVO als vervanger Annelies Siegmund\\n\\nZalen stilte , moet in S+ ingeboekt worden, kan dus niet in study spot. Anders IZB, of alle roosteraars moeten dit dan worden. Comm via pop up Study spot of VU net  etc Oftewel apart comm kanaal\\nFilosofenhof als geschikte plaats voor stilteruimtes?', '2016-07-04 10:14:27'),\
(63, 24, 126, 'Gesprek FGB roostering. \\r\\n11 -7- 2016\\r\\nCarla, Carolijn, Annemarie, Marijke, Joost, Dirk Jan\\r\\n\\r\\nPlanning \\r\\n-	Binnen 2 weken uitvraag S2 (Joost/Marijke)\\r\\n-	Herinneringsmail voor 1 sept. \\r\\n-	Uitvraag deadline: 1 september\\r\\n\\r\\n-	Ba curr pedagogiek , vanaf sept pakken marijke en Carolijn dit samen op\\r\\n-	Psychologie. Vraag wie coordinatie hiervoor gaat doen. Vraag of hetzelfde als vorig jaar gepland mag worden. \\r\\n\\r\\nProces afspraken	\\r\\no	Vervolg medio September ; Joost plant hiervoor een vervolgafspraak\\r\\n\\r\\nRoosterwijzigingen	\\r\\no	Internet zalen boeken is bijna uitgerold. Annemarie en Joost pakken dit op.\\r\\n\\r\\nCurriculum wijzigingen 2016/17	\\r\\no	Geen wijzigingen voor S2\\r\\n\\r\\nCurriculum wijzigingen 2017/18	\\r\\no	Master Pedagogiek/ psycho en methodelijn eerste jaar statistiek\\r\\no	Ba Engels psychologie wellicht (in de gaten houden)\\r\\no	15 Oktober naar gremia, opl commissies, excie,  - , verwacht 1 jan klaar? (in de gaten houden)', '2016-07-11 18:45:00'),\
(64, 24, 126, '22-8-2016\\r\\nEerste roosteroverleg na de zomervakantie: \\r\\nKnelpunten zijn alle losse eindjes opgelost, op 1 knelpunt van\\r\\nCapaciteitsmanagement: stonden eerste geen email adressen in, welke routering richting centrale mailbox. Ongeveer 45 meldingen nu \\r\\nLoper was alleen voor nieuwe schooljaar, niet voor lopende schooljaar.\\r\\nLoper kon je geen lintboekingen mee opknippen\\r\\nAandachtspunt, voor FCO, dat alle beschikbare zalen  ook echt beschikbaar komen. \\r\\nCorrupte activiteiten, in S+.\\r\\nSleutelveld drie heeft een enter, die er niet moet zijn. Gezamenlijk bestand, tips en trucks  S+. Surfdrive. \\r\\nGrote zalen, we gingen rechtstreeks in de grote zalen boeken, niet in de dummies. Maar ze staan dicht. KC07 staat dicht. Sommigen. \\r\\nIrma: MF-H047 enz, aantal tafels en stoelen matchen niet met opgegeven aantal in S+.\\r\\n\\r\\n', '2016-08-22 14:00:25'),\
(65, 24, 124, 'Michel van Raaphorst & J.A. Breed\\r\\n\\r\\nReorganisatie doorgevoerd , ook bij rechten. Concentratie op eerste geldstroom, ook vwb roostering. In vervolg, wat zijn behoefte voor niet eerste geldstroom; ook logistiek geinventariseerd. \\r\\nPGO: FEWEB, Rechten, FSW, UC(f)GB,  cursussen voor derden tegen betaling. \\r\\nVoor FEWEB en onze fac geldt gebruiken vooral agora zalen en minder reguliere zalen. UCGB hebben eigen collegezalen die niet in de poel zaten. (MF)\\r\\nSelectie PGO directeuren gesproken om aan te haken bij de roostering zoals die nu ontwikkeld wordt binnen de VU. Leenrechtenstelsel. Men is toen tot de conclusie gekomen dat men zou lunnen meeliften op de leenrechten. Voor deze specifieke ook eigen specifieke voorwaarden, zitten bijv. vooral op de vrijdag. \\r\\nHet idee was om te kijken of PGO org mee kunnen liften op leenrechten stelsel, zodat ook op 1 manier kunnen regelen. Zou VU breed \\r\\nRoosterproces\\r\\nRechten \'96 Agora zalen. Vu net, VASS FSW-PGO. Doen niet mee in de leenrechten. \\r\\nApart roosterprogramma apart, PGO FEWEB, geven aan de roosteraars, hun grote opleidingen, die krijgen eerste plaats in agora zalen. Monique van der Sluis maakt die slag. Apart roosterslag. \\r\\n1)	Apart proces\\r\\n2)	Ruimte niet beschikbaar \\r\\n3)	Kunnen niet in de grote poel\\r\\n4)	Symphonie, blijkt weinig mogelijk omdat er geen catering. \\r\\nPGO stelt eisen aan lokalen qua aankleding en uitstraling \\r\\nBusiness case, vraagstuk: meenemen PGO in roostering. Ik heb daar niet de mogelijkheid voor hier energie in te steken, maar misschien \\r\\nPGO integreren in centrale roostering, willen we \\r\\nMichel- \\r\\nOnderwijs Dienstverlening Processen, vervolg OSD programma : overlegtafel, aanknopen \\r\\nWie doet PGO roostering Breed- Ellen. \\r\\n\\r\\n', '2016-08-25 14:25:27'),\
(67, 24, 126, 'Clustreroverleg 25-8-16 FSW/FGB\\r\\n\\r\\n1)	Wijzigingen start, sem 1\\r\\nFSW: zelfde als altijd, docentwijzigingen, aantal studenten enz. Het is wel lastig om zalen te vinden. \\r\\nFGB: zijn nog volop aan het repareren en aan het roosteren, zijn nog helemaal niet klaar. Deel tentamens zijn niet geoorsters, Een honours programma moest nog geroosterd worden . Zijn ook veel roosterwijzigingen die men nav concept rooster, had kunnen aanvragen en daar is men nu te laat voor.  (analyse Aglaia). Speelt bij Psychologie en Pedagogiek\\r\\n\\r\\n2)	Terugblik zomer\\r\\nYvonne: kan er weinig over vertellen. Mailadres is toegevoegd en toen werkte dat. \\r\\nJoost: het heeft gewerkt met de achterwacht: Trudie en Aglaia heeft dingen op kunnen pakken. Wel veel meldingen, zie punt 1\\r\\nAglaia: Yvonne Knoop als achterwacht ; Tweedeweek was Agalaia de achterwacht; was best een klusje! Anderhalf tot 2 uur per dag mee bezig geweest. FEWEB notificaties! Is tijdrovend. FGB: Psy en Ped. Veel sap fouten. Marijke, heeft veel slordigheden begaan bij het invoeren. \\r\\nFPP grote puinhoop. \\r\\n\\r\\nKnelpunten: binnen het team moet je mensen anwijzen dat ze hun verantwoordelijken . Men voelt zich niet geroepen. Vele lag bij Peter, maar hij kon het ook anders oplossen. FGB kregen nog veel knelpunten erbij. \\r\\n\\r\\nCarla is erg druk, te druk. \\r\\n3)	Uitvraag sem 2\\r\\nFSW: Mis er nog 6 of 7. Begint na wijzigingen Sem1 met roosteren. KC initium,grote zalenoverleg obv inschatting vorig jaar\\r\\nFGB: roosterbrief nog niet verstuurd. Carla gaat hem sturen. Begin volgende week weg!\\r\\nRechten: pilot UAS.\\r\\n\\r\\n\\r\\n', '2016-08-25 14:28:37'),\
(68, 24, 126, 'Clusteroverleg 25-8-16 FGW-FEWEB \\r\\nClusteroverleg FGB-FEWEB\\r\\nSaskia, Maritha, Anneke\\r\\n\\r\\n1)	Terugblik zomer\\r\\nErvaring: Anneke: ws heel rustig, ze was eerste week achterwacht , nog erg vroeg in seizoen\\r\\nHele heisa om het op te tuigen\\r\\nSaskia: Best wel veel werk aan gehad, FEWEB-FGB\\r\\nEr is veel FEWEB binnengekomen. Lastig is dat er veel notificaties binnen komen, drie per vak. \\r\\nGevoel van DJ: als er geen drijvende kracht achter zit, dan hadden we nu nog de knelpunten gehad. Misschien omdat Peter de linten niet had opgeknipt bleef dit een knelpunt. \\r\\nIdee is om een dag bij elkaar zetten om die knelpunten weg te werken.  Gezamenlijkheid in oplossen knelpunten. Boek de kelder op een goede dag.  \\r\\n2)	Uitvraag sem 2\\r\\nFEWEB: wat is binnen, is nog niet duidelijk, gaat ze over enkele weken bekijken\\r\\nFGB : jaarlijks aangeleverd maar moet wel gecheckt worden omdat er vacatures in staan, of docenten iet meer werken, en nu weten hoeveel studenten er daadwerkelijk zijn enz. Lijkt geen problemen op te leveren\\r\\n\\r\\n3)	Wijzigingen start, sem 1\\r\\nFGB: heel veel extra student engels, ook hier en daarminder overall zelfde. \\r\\nFEWEB: geen idee over instroom:kijk cijfers. \\r\\nTentamen, ophogen doen we wel, kleinere zalen doen we niet. \\r\\n<b>Downgraden doen we niet of in extreme gevallen. </b>\\r\\nStart sem 1, het lijkt meer. Mensen die ziek zijn en nu pas naar het rooster kijken. Nu Els er niet is, kijkt Maritha vooral zelf naar het rooster. \\r\\nZalen nodig voor week 3 of 4, van 70 personen. \\r\\n\\r\\n4)	Technische problemen, vak was uit het rooster verdwenen\\r\\nAfspraak: als het een menselijke fout is geweest, dan oplossen, anders terugkoppelen aan Dirk Jan \\r\\nPPR 26 def, 60 niet goedgekeurde. Gaan waarschijnlijk niet boven de 50 aankomen. \\r\\n5)	FEWEB computerzalen, sommigen zijn van FEWEB en sommigen zijn van FCO. Beheer van de algemene computerlokalen ligt niet bij FCO maar nog bij de roosteraar. \\r\\n6)	Rooster.vu.nl. ', '2016-08-25 14:29:23'),\
(69, 24, 126, 'Clusteroverleg 25-8-16 FGW-FEWEB \\r\\nClusteroverleg FGB-FEWEB\\r\\nSaskia, Maritha, Anneke\\r\\n\\r\\n1)	Terugblik zomer\\r\\nErvaring: Anneke: ws heel rustig, ze was eerste week achterwacht , nog erg vroeg in seizoen\\r\\nHele heisa om het op te tuigen\\r\\nSaskia: Best wel veel werk aan gehad, FEWEB-FGB\\r\\nEr is veel FEWEB binnengekomen. Lastig is dat er veel notificaties binnen komen, drie per vak. \\r\\nGevoel van DJ: als er geen drijvende kracht achter zit, dan hadden we nu nog de knelpunten gehad. Misschien omdat Peter de linten niet had opgeknipt bleef dit een knelpunt. \\r\\nIdee is om een dag bij elkaar zetten om die knelpunten weg te werken.  Gezamenlijkheid in oplossen knelpunten. Boek de kelder op een goede dag.  \\r\\n2)	Uitvraag sem 2\\r\\nFEWEB: wat is binnen, is nog niet duidelijk, gaat ze over enkele weken bekijken\\r\\nFGB : jaarlijks aangeleverd maar moet wel gecheckt worden omdat er vacatures in staan, of docenten iet meer werken, en nu weten hoeveel studenten er daadwerkelijk zijn enz. Lijkt geen problemen op te leveren\\r\\n\\r\\n3)	Wijzigingen start, sem 1\\r\\nFGB: heel veel extra student engels, ook hier en daarminder overall zelfde. \\r\\nFEWEB: geen idee over instroom:kijk cijfers. \\r\\nTentamen, ophogen doen we wel, kleinere zalen doen we niet. \\r\\n<b>Downgraden doen we niet of in extreme gevallen. </b>\\r\\nStart sem 1, het lijkt meer. Mensen die ziek zijn en nu pas naar het rooster kijken. Nu Els er niet is, kijkt Maritha vooral zelf naar het rooster. \\r\\nZalen nodig voor week 3 of 4, van 70 personen. \\r\\n\\r\\n4)	Technische problemen, vak was uit het rooster verdwenen\\r\\nAfspraak: als het een menselijke fout is geweest, dan oplossen, anders terugkoppelen aan Dirk Jan \\r\\nPPR 26 def, 60 niet goedgekeurde. Gaan waarschijnlijk niet boven de 50 aankomen. \\r\\n5)	FEWEB computerzalen, sommigen zijn van FEWEB en sommigen zijn van FCO. Beheer van de algemene computerlokalen ligt niet bij FCO maar nog bij de roosteraar. \\r\\n6)	Rooster.vu.nl. ', '2016-08-25 14:29:23'),\
(70, 24, 126, 'Teamoverleg roosteraars\\r\\n\\r\\nIZB geschiktheden, \\r\\nCategorie lijstje aparte firlter voor IZB gebruiker,. Onderzoeken of dit mogelijk is?\\r\\nNaomi, om tafel. Saskia, Dirk Jan \\r\\nSpeelt ook voor de tent. TENT zelfzstandig gebruiken. We kunnen nu niet zien of de tent beschibaar is omdat er geen beschikbaarheden niet zijn aangemaakt. Vanwege IZB. \\r\\nFCO heeft de leenrechten aangemaakt voor de faculteiten niet voor alles. Zij moeten dit weer doen. Alles open voor iedereen. \\r\\nComputerzaal vragen. Delen van algemene computerzalen. Wij geven computerzalen vrij voor semester 1. \\r\\nBoeken buiten de tentamenweken om, van TENT. \\r\\nInrichting TENT is rommelig, \\r\\nWij gaan dummy zalen aanmaken. FCO, graag alle dummyzalen eruit die FCO heeft aangemaakt.  \\r\\nMail wat voorstellen voor opleidingen. \\r\\nNo reply; mail; 80% doen we niets mee, kan weg. Krijgt soms 3 keer 80% mail, lijkt een bug. \\r\\nKan er naar 90 & 95%? Kand e 80% eruit. Gewenst 90, 95 en 100.\\r\\nDubbelingen eruit. \\r\\nPercentage kan alleen per vak aangepast worden. Kan dat geautomatiseerd doorgevoerd, worden.', '2016-08-29 08:55:14'),\
(71, 24, 126, 'Clusteroverleg Beta\\'s 29-8-2016\\r\\n\\r\\nStart uitvraag Semester 2\\r\\nNa drie weken starten met inventariseren van Sem 2 derde week september. \\r\\nTrudie of Ron mailt mij status herinneringsmail uitvraag Sem 2. Of eindbericht versturen. \\r\\n\\r\\nSem 1; wat valt op : aantallen ophogen ivm de capaciteitsmail. \\r\\nMet de loper kon je niet ophogen, niet andere zaal toewijzen.\\r\\nZomerperiode: \\r\\nFALW roosteraars volgden niet de route van het terugverwijzen bij wijzigingsverzoeken die buiten de reguliere verzoeken lagen naar directie. Afgesproken is om alle wijzigingen, behalve invullen vacature, studentaantallen  en dat soort onvoorziene omstadigheden, via de directie (Pamela of Thilo) te laten verlopen. Ze melden dit terug aan de aanvrager die toestemming nodig heeft van een van hun beiden. \\r\\n\\r\\n Grote discussie over inwerken met elkaar: een uur per week bij elkaar zitten . Het gaat om elkaars inhoud snappen, niet zozeer om algemene best pratice in roostering te bewerkstelligen. Vooral Ron zag hiervan weinig het nut.\\r\\n', '2016-08-30 06:27:11'),\
(72, 24, 126, 'BIla Marjolein en Erna, 29-8-16\\r\\n\\r\\nEvaluatie zomer\\r\\n1)	Er is echt leiding nodig. Team gaat achterover leunen\\r\\n2)	Als de kat van huis is, er is een positieve lijn, maar als de leiding weg is, verval je terug in oud gedrag\\r\\n\\r\\nNu 1.0. \\r\\n5.0\\r\\nWil plan van optimale onderwijsplanning naar 2.0, zowel team als gunning, \\r\\n2018 fase 3: naar 3.0 of 4.0 \\r\\nHele team bespreken, in vlootschouw. Binnenkort gesprek\\r\\nYvonne; a) financieel FSW, \\r\\nDossier maken. Argumentatie helder. Met Karin dossier opstellen, helpen met argumentatie enz. \\r\\nAfdelingsbijeenkomst in september. Team voorstellen. \\r\\nAfdeling van Yvonne Berkhof. SOZ. \\r\\nGeven minder workshops.  \\r\\n\\r\\nUVA \'96 VU, Moeten we verkennen. Met Erna en Bart afstemmen, rondje polsen. Dirk Jan \'96 polst Walter. ', '2016-08-30 06:28:19'),\
(73, 24, 124, 'Cees van Gent dd 30-8-2016\\r\\n\\r\\nBila Cees van Gent\\r\\nIk heb hiervoor toestemming nodig van de onderwijsdirecteur, kun je me die verlenen. \\r\\nZelfde geldt timeslot, is vastgesteld daarbinnen moet het uitgevoerd worden. \\r\\nOperationele dingen (extra groep erbij, groep eraf)\\r\\nAfgelopen dinsdag met alle afdelingsmanagers enz. Ook 10 minuten aandacht aan aandachtdiscipline, vooral over werkvormen, hoezwaar en wanneer zet je welke in. Ze willen van de last minute wijzigingen af. Daarom erg geinteresseerd in de wijzigingen. \\r\\n\\r\\nMogelijk: minimaal aantal werkvormen. Helpt. Moet ook op die manier geroosterd worden, volgordelijk. \\r\\nScience owl is enige bron voor aanleveren van gegevens, niet ook de mail. Klopt, en ook niet het krukje naast het bureau. Wel voor toelichting Science Owl. \\r\\nOmhangen van studenten aan activiteit ivm ander zaal, wiens verantwoordelijkheid: verantwoordelijkheid van de BAS; formele lijn. Soms wil je niet wachten. Vooral rondom de intekeningen. Creer korte lijnen met de bas. \\r\\n\\r\\nCees is er voor roosterproblemen zoals twee overlappende activiteiten. Of een tentamen van docent die in de kerstvakantie. Ron kon deze vraag direct bij Cees neerleggen. \\r\\nGezamenlijke FAQ onderwijsplanning voor de BETA, als voorloper op een breder. Verwijspagina.\\r\\nFAQ in science owl vastleggen? Academische jaarkalender. RACI tabel voor vaststellen Ac Struc. Wordt projectje\\r\\nTentamenrooster FEW is nooit voorgelegd aan de onderwijsorganisatie. Waardoor de onderwijsorg lopende het jaar erachter kwam dat er dubbelingen waren. Tentamen en onderwijsrooster als def is; formele klap onderwijs directie en  faculteitsbestuur. Op 5 (wordt 7) sept: geef ik door aan Cees; het tent rooster. Controle: 4 onderwijscoordinatoren FEW en misschien iets meer bij FALW. Kun je meekijken of het zo klopt. Dat proces weer zo inrichten. \\r\\nWil heel graag dat Beta Vu op 5 sept het tentamenrooster deelt. Aangeleverd in excel.  \\r\\nOpmerkingen: -Tentamenroostering wordt 1,6 fte personen, die gaat ook de dig toetsing organiseren. \\r\\n-	As maandag: nieuwe protocol tentamenorg. Vastgesteld, en wordt door Cees met mij en roosteraars gedeeld. ', '2016-08-31 07:03:33'),\
(74, 24, 126, 'Saskia de Munnik\\r\\n\\r\\nAfspraken arbeidsvoorwaarden Saskia de Munnik\\r\\n-	Neven activiteiten doorgeven aan Dirk Jan \\r\\n-	40 euro per uur is all-in tarief\\r\\n-	Tot 1 / 1. 2017, daarna 4 maand in loondienst\\r\\n-	Werktijden: di tot 15:00 uur en wo tot 16:00 uur, gecompenseerd door eerder te beginnen \\r\\n-	Vrijnemen enz. in overleg, aangeven. \\r\\n', '2016-08-31 07:05:22'),\
(75, 24, 126, 'BILA Bart- Dirk Jan \\r\\n?	Idee kader in project kader plaatsen\\r\\n?	Aparte excelsheet met onderbouwing, gebaseerd op Johan\'92s sheet\\r\\n?	Projectteam met 2 deelprojectleiders\\r\\n\\r\\nUitzetten acties voor aanbestedingsstrategie\'94\\r\\nPlannen afspraken met leveranciers en met scholen. \\r\\nScholen: \\r\\nEindhoven TU, (afspraak via Floor) DJ benadert Floor. \\r\\nUVA afspraak pilot traject met adviteau schedule??  Bart vraagt via zijn contact\\r\\nUU, werkten met timeslots en zijn er mee afgestapt. DJ vraagt Cees naar contactpersoon\\r\\nEUR, referentiebezoek afspraak via Eric Jansen\\r\\nLeveranciers: \\r\\nScientia, Robert Jan Bulter, Wie , Eric Jansen vragen. \\r\\nAdastra, NL-se vrouw van de directeur. Bart\\r\\nAdvitrea, Henk van der Molen (DJ benadert hem. )\\r\\nNieuwe leveranciers met nieuwe pakketten: via Walter. Actie Dirk Jan \\r\\nWie zit erbij? Roosteraar (Roulerend) Anne, Bart, Dirk Jan, IT(Ted de Brabander?)\\r\\n\\r\\n?	Educoarse, oktober, USA, interessant?\\r\\n\\r\\nVerdeling Anne over procesbeheer en project OO: Bart maakt overzicht te verwachten inzet Anne. Dirk Jan heeft dit al gedaan dmv projectplan. Afspraak met \\r\\n', '2016-08-31 08:53:22'),\
(76, 24, 124, 'Bila Annemarie 1-9-16\\r\\n\\r\\nJoost was 3 of 4 weken weg, marijke was er niet. \\r\\nAchterwacht: weet dan toch te weinig om het goed te doen. Sommige dingen kan die oplossen, sommige niet\\r\\nVeel in de koppeling tussen Sap en S+, dingen die in SAP niet goed stonden. Waren aantal dingen niet geroosterd. Joost heeft nu alles wel gehad, maar ze zijn het niet gewend bij Psychologie/Pedagogiek\\r\\nBinnen cluster de vakanties minder laten overlappen; gegevens breder beschikbaar ook voor achterwachters. Aantal personen die zich ermee bemoeien, is niet ideaal. Ac struc, hopelijk wordt die beter, is nog veel in te verbeteren. (door carla) : Huub (PP) Henny (ULO) en BW (veel verschillenden, Annelies, ging eigenlijk best goed)', '2016-09-01 12:59:11'),\
(77, 24, 124, 'Ella Noordhoek\\r\\nFEWEB. 5-9-2016\\r\\nHet is druk, heel de maand september nog. \\r\\nRoostering. Ben niet helemaal gelukkig.\\r\\n-	Peter, ben ik niet gelukkig over, tijdens zijn vakantie zijn er heel veel dingen opgepopt in zijn opleidingen.\\r\\n-	Hij is heel laconiek. Als ik hem dingen vraag, denkt dat er nog tijd is, maar \\r\\n-	Zijn kleine dingen maar alles bij elkaar geeft gevoel, ik ben niet in controle binnen roostering. \\r\\n-	Maritha en Peter zo lang op vakantie samen, was not done.\\r\\n-	Centrale roosterteam heeft het zo goed als kan\\r\\n-	Ik heb me er erg in moeten verdiepen en bezig geweest nu meer dan ooit te voren. \\r\\n-	Heeft ook te maken met wennen, maar al met al niet gelukkig mee, gevoel steken vallen, en dat we dingen moeten aanleveren die voorheen de roosteraars leverden. \\r\\n-	Maar als er iets gebeurt \\r\\n-	Bij het intekenen ging het mis\\r\\n-	Niet terugzetten op defintief zetten. Iemand die het had opgehoogd\\r\\n-	Peter: irritatie ontstaan over aantal studenten inschatten inschrijven tentamens\\r\\n-	Er is iets gebeurd, dat docenten zelf hebben aangeven ws aan Peter, dat ze de werkcolleges zelf willen indelen. Via blackboard. Wil je zelf je groepen indelen of moeten ze zich erop intekenen. Standaard inteken, is heel belangrijk voor FEWEB. Docenten hebben hier Ja opgezegd. Wel inschrijven op module niet op activiteit. Is dus uitgezet. In de uitvraag was dit een vraag aan docenten. Standaad formulier voor UAS- vraag of ze wel of niet zelf groepen willen maken.\\r\\n-	FEWEB heeft als faculteit besloten om last minute inschrijving te doen, voor komende periode (2). Tussen intekendeadline en voor last minute inteken dagen, periode van 3 weken,  sturen ze een lijst met vakken die worden opgehoogd.  \\r\\n-	 Afgesproken dat zij de issues verzameld en aan mij terugkoppelt. Ik ga met Maritha en anderen in overleg wat er beter kan. ', '2016-09-05 14:44:35'),\
(78, 24, 126, 'FEWEB/FGW \\r\\nClusteroverleg 08 sept 2016\\r\\n\\r\\nFEWEB/FGW\\r\\n\\r\\nAfronding Semester 1: \\r\\nMaritha: jaarlijks terugkerend \\r\\nMinoren: ze hebben niet doorgegeven hoe ze de werkgroepen geroosterd willen hebben. \\r\\n\\r\\nAan Ella:\\r\\n-	Via uitvraag is dit gedaan\\r\\n-	Niet alleen 1e jaars periode 1, maar ook minoren, waar geen uitvraag reactie voor is geweest, en andere waar ze expliciet hebben aangegeven\\r\\n-	Dit is nu helaas al een stap verder, wordt op basis van individuele verzoeken aangepast \\r\\n-	Voor semester 2; wordt dit er weer uitgehaald. \\r\\nOp def zetten via roosteraars of via SAP op inschrijven zetten. Tentamen in SAP open en dicht zetten. \\r\\nVerwacht 60 studenten en 120 studenten ingeschreven \\r\\nHeb je de tijd en de zalen. \\r\\nFGW: veel ophogingen, als totaal gelijk gebleven Niet actief downsizen, alleen actief op zoek als er een probleem is. \\r\\nAanwezigheidsplicht bij vakken van Geesteswetenschapppen. En hoorcolleges willen ze zijn. Oftewel: er heerst gevoel dat ze zowel 1e jaar s als 2e jaars vakken kunnen volgen. \\r\\nPeter. 2e jaars econometrie; kwamen laat met vraag om extra werkcolleges. Willen 2 groepen, had Peter niet goed begrepen. \\r\\nTentamens. Nog dingen aan het schuiven. Bastiaan is niet aangehaakt in de wijzigingen in het tentamenrooster. \\r\\nEerste week is druk, liever geen vergaderingen. ', '2016-09-08 14:58:57'),\
(79, 24, 126, 'Clusteroverleg FGB FSW RCH\\r\\n\\r\\nFGB, druk met de dagelijkse ophogingen. Meer masterstudenten dan vorig jaar, lintboekingen opknippen enz. Tentamen semester 1 rechtzetten , gaan nu weg ter controle via Carla, naar opleidingsdirecteuren. Extra tijd is apart geroosterd conform notitie. \\r\\nCarla zit te vol, op de grens van in paniek! \\r\\nFSW: druk bezig met ophogen van zalen. Heeft HOVO zo grote 00 zaal nodig? Yvonne stemt af met Aimee \\r\\nUitvraag S2: 1 opleiding coordinator, rest is binnen. Start ermee als inteken voor Sem1 is afgerond. \\r\\nRCH: loopt goed. Start wijzigingen , reguliere wijzigingen\\r\\nUAS roostervraag: ongeveer 90% is aangeleverd. \\r\\n', '2016-09-08 14:59:22'),\
(80, 24, 124, 'Impasse Syllabus. \\r\\nBeeldvorming\\r\\nNaomi: Toen we begonnen met Syllabus, was FCO de systeemeigenaar. Toen SLM gebruik, is verschuiving plaatsgevonden en is SOZ eigenaar geworden. Als er wijzigingen door Leverancier enz. is onduidelijk wie de beslissing moet maken en wie de rekening zou moeten betalen. \\r\\nBepaalde dingen zijn blijven liggen, maar omdat er geen schot in zit, duidelijkheid waar proces en budget en systeem eigenaarschap zou moeten liggen \\r\\nVoorbeeld: FZ \'96web applicatie aan syllabus (facturen database en fz web applicatie)\\r\\nEigenaar was FZ van voorheen. Bart heeft onderzoek hiernaar gedaan. SOZ , ICT en FCO is allemaal geen budget opgenomen voor ondersteuning van Syllabus. ICT doet dit vanuit concernsystemen. \\r\\nVoorstel was, proceseigenaarschap bij SOZ en systeem bij ICT neerleggen. \\r\\nVerbinding SAP en Syllabus, standaard koppeling via de broker, onderhoud \\r\\nVoor 2017, wie is budgetverantwoordelijke\\r\\nConcreet probleem, communicatie broker en web applicatie S+, inschatting kosten en neerleggen bij directeuren, zodat zij hierover kunnen factureren. \\r\\nRobert \'96 Jan Tan contact opnemen met Wilfred (controller)\\r\\n\\r\\n', '2016-09-08 15:00:51'),\
(81, 24, 127, 'Lone ROoftop voorbespreking met Bart, \\r\\nKoen: CTO \\r\\nArjan Hoofd tech support bibliotheek, ook een fysieke component. Studenten komen steeds meer op de VU. Expertgroep Smart campus. \\r\\n\\r\\nErna en Bob. Is dit een partij die interessant is. \\r\\nWayfinding voor bibliotheek\\r\\nBHV:\\r\\n\\r\\nPositieve aspecten: \\r\\nDoor Wageningen ervaring met Clocks\\r\\nClocks betaal je per student: \\r\\n- PIE geen licentie, ongeveer 10 a 15K per gebouw (inlezen plattegronden, meten wifi), tussen 2 en 4 weken, daarna 1 tot 2 weken. \\r\\n- apps: \\r\\n-	building intelligence 65 cent per m2\\r\\n-	clocks aantal studenten: 30K voor aantal studenten. Tot 30 K studenten = 30K euro. Staffel.\\r\\n-	Wally: 11 a 25 schermen = 800 per scherm,\\r\\n-	Aanbestedingsgrens 200 K per 4 jaar,\\r\\n-	Zijn er concurrenten? Op basis van WIFI systeem, zijn ze de enige. Ook door een breed platform met verschillende toepassingsmogelijkheden. \\r\\n-	Studentenapp voor wayfinding?\\r\\nProject traject. Beschikbare resources IT projectleider en business project leider, voorstel, enz. enz. \\r\\nTraject doorlooptijd: \\r\\n-	BOB/Erna/Josja\\r\\n-	Projectplan / business case\\r\\n-	Investeringscommissie\\r\\n-	Voorstel VB\\r\\n-	Budget\\r\\n-	ICT project opstart: \\r\\n-	Techniek is niet de bottle niet, maar wel security en privacy officer audits/jurist. \\r\\n-	\\r\\nAanbesteding: open aanbestding, vooraf markt informatie, daarna onderhands aanbesteden opbasis van specifieke wensen\\r\\n\\r\\n', '2016-09-08 15:02:31'),\
(82, 24, 126, 'clusteroverleg beta\\'s\\r\\n\\r\\nBETA\\r\\n\\r\\nRoosterwijzigingen, wanneer wel en wanneer niet richting opleidingen,\\r\\n-	Compleet op z\'92n kop\\r\\n-	Als iets niet kan,\\r\\n-	Dan via opleidingdirectie\\r\\nWijzigingen. Onvoorziene toesstroom , docenten, congressen etc. \\r\\nWil het aantal wijzigingen terugbrengen. Streng beleid, zoveel wijzigingen staan we toe, zoveel niet. \\r\\nWanneer tentamens dubbel boeken, dan is een oplossing om extra tentamenruimte boeken in een kleinere ruimte. \\r\\nTentamenprotocol, coordinatoren FALW zijn bijgepraat over roostering. \\r\\n?	S311 Ik betaal voor de vierkante meters. Wie gaat dan de rekening betalen?\\r\\n', '2016-09-12 17:42:45'),\
(83, 24, 126, 'Over roostering FEWEB tijdens de zomer. \\r\\n\\r\\nEr was veel voorkomen geweest als er in SAP gecontroleerd , door te kijken of het goed in SAP is gekomen, eenmalig. Als er wijzigingen zijn dan kijken we niet meer. \\r\\nSommigen activiteiten stonden niet op definitief, sommige tekst 3 gebru ikersveld niet ingevuld, SAP sleutel. Bijvoorbeeld 3 werkgroepen, moeten alle drie een uniek sleutelveld, als je 1 sleutelveld invoert dan heb je maar 1 groep om in te schrijven. \\r\\nTrudie heeft achterwacht, weet dat \\r\\nIs vaak voorgekomen, ongeveer voor 10 vakken. \\r\\nSAP geeft soms een foutmelding, maar vaak ook niet. Peter lijkt nu alleen te checken op foutrapportage van Jantien, niet proactief na roosteren in S+.\\r\\nTentamens: bij heel veel tentamens heeft hij de uiteindelijke kandidaten die deelgenomen hebben vorig hebben deelgenomen, niet verwachtte aantal . \\r\\nEerstejaars IBA vak Business Mathematics, aantal studenten eerste jaars tentamen = 151 aangevraagd, maar er hebben zich 204 studenten aangemeld   (nummeris ficus is 200). Heeft 200 plekken gekregen in de RAI.\\r\\nAnder vak: People in Business and society, hebben 203 zich aangemeld voor tentamen, en heeft in systeem S+ 158 gezet, toegewezen gekregen 201. \\r\\nDecember Economic for the global era: tentamen 166 aangevraagd, en gekregen 187, ingeschreven studenten nu: 173. Eerste jaars IBA = 200 studenten, dit is hem door Maritha en Els\\r\\nEr was een vak, verwacht 80 studenten, en drie werkgroepen  van 70 geboekt, waardoor er 1 vol was, twee beetje en derde niet. \\r\\nReparatiewerk eventueel om studenten zich te laten inschrijven voor activiteiten door act op def te zetten, in overleg met docenten of ze dat toch willen. Geldt voor per 2 en 3. Voor sem2 wordt alles open gezet voor inschrijving. \\r\\nPeter roostert de tentamens voor alle opleidingen maar had alleen voor zijn eigen opleiding de tentamens opengezet\\r\\nHij heeft de deadlines niet gehaald, had veel hulp nodig, komt omdat hij het zo gecalculeerd, als ik zoveel doe per week. \\r\\nPeter vertikt om te knippen, er zitten daardoor veel knelpunten bij hem. Heen en weer gemail. Marc schouten, werkgroepen. \\r\\nHij roostert activiteiten in S+ die direct conflicten oplevert, maar hij laat het er wel instaan, en vergeet het later op te lossen. \\r\\nHij roostert het eerste tentamen, maar niet het hertentamen. Overgangsregeling was niet duidelijk. Nu wel. \\r\\nMinoren: hij had geen informatie over hoe de minoren er uit komen Als je een HC van 90, 30 WC. \\r\\nSommige mails waren in de delete mails, \\r\\nVolgend jaar komt er een nieuwe masteropleiding, en dat krijgt \\r\\nTelefonische bereikbaarheid voor spoed. Soms ook per mail spoed. \\r\\nBij spoed vraagt hij: Waarom is het niet geroosterd, wie is het docent, waarom hangt er geen zaal aan het vak enz. In plaats dat hij het oplost. ', '2016-09-13 14:52:14'),\
(84, 24, 126, 'Teamoverleg maandag 12 september\\r\\nBeetje verkouden. \\r\\n-	Capaciteits management, toch verzoek 80%. Hoe passen we dit aan?\\r\\no	Mails zelfde percentage 95%\\r\\no	Zo niet, dan 2 percetages standaard, 94 en 95%\\r\\no	\\r\\n-	Computerlokalen teruggeven in de leenrechten, status?\\r\\no	Openzetten computerlokalen: \\r\\no	Beta\'92s vandaag, \\r\\no	GNK, alleen voor wie erom vraagt\\r\\no	Wij hebben de ruimte nodig voor zelfstudie BETA FALW, \\r\\no	FEWEB, heeft niet computerlokalen opengezet\\r\\no	RCH: zelfstudie lokalen, in de poel opgenomen. \\r\\no	FSW: openstaan voor alle faculteiten\\r\\no	FGB: nog niet opengezet\\r\\n-	\\r\\n-	Eens per 2 weken maandagochtend vergaderen\\r\\n\\r\\n-	FGB: Maandagochtend ; 80 grootte, en van 30.\\r\\n-	FALW: maandagochten 11- 15:15, 120, 130 personen vrijdag tussen 11-15:15 uur, premaster; 130 personen; platte zalen 70 a 80 groepen door gebrek aan docenten\\r\\n-	FEWEB: maandag; KC 300+ ruimtes, 87 en groter zalen \\r\\n-	FSW: vrijdag en dinsdagmiddag, 130 personen + vrijdag werkgroepzaal 50 , collegezalen 90-150\\r\\n-	GNK: hebben alles geroosterd, geen problemen; \\r\\n-	FEW: maandagan 11-15:15; 80\\r\\n-	RCH: grotere werkgroepzalen 40-50 zalen, dinsdag middag, donderdagochtend; oook platte zaal 80 a 90, \\r\\n-	Volgende week maandag vrij\\r\\n-	Waar is momenteel het meeste te kort aan, wat voor type zaal, wat voor grootte\\r\\n-	Oorzaak: verandering in het onderwijscurriculum, sommige grotere instroom , \\r\\n-	Innitium zaal veel problemen qua inrichting. \\r\\n-	Is Moskou/Amsterdam verschuifbaar mobilair\\r\\n-	\\r\\n-	Rooster.vu.nl ligt eruit. Naomi of Alex \\r\\n-	\\r\\n\\r\\n-	_____\\r\\n-	Train de trainer, hoe pakken we dit op, wanneer agenderen we dit\\r\\no	Tips en tricks, hoe gebruik je dingen gezamenlijk hetzelfde\\r\\no	Noem twee onderwerpen, die je zou willen. \\r\\no	Per sessie 1 kiezen. \\r\\no	Start in December KC30; \\r\\no	\\r\\n-	Informeren over klein committee werkwijzen , maken van een foto huidige situatie \\r\\n-	Erna en Marjolijn ;heeft het team idee\'94en wat voor vorm, waar behoefte aan is\\r\\n-	Wat doen we met het project, waar staan we: binnenkort korte presentatie geven\\r\\n-	Peter: \\r\\no	Geld verzamelen\\r\\no	VVV bon\\r\\no	Krijg je van de faculteit\\r\\no	Onderbroek\\r\\n-	Studyspot komt niet overeen met de werkelijkheid, synchronisatie met syllabus klopt niet. \\r\\n', '2016-09-17 05:48:05'),\
(85, 24, 124, 'Bila Cees van Gent\\r\\n\\r\\nCees is van mening dat een wijziging van Ron naar FEWEB, formeel voorgelegd moet worden aan BETA\'92s. \\r\\nBETA\'92s heeft een overcapaciteit van 0,7. \\r\\n-	December 2014: hoofden onderwijsbureau van medewerkers, hierin staat : 0,55 FTE tent org totaal was 1,4 (Peter 0,3 roosteren en Saskia 0,25)\\r\\n-	Saskia: 5% \\r\\n-	RON deed 0,1 digitale tent organisatie. (Katrijn heeft \\r\\nVoorstel van Cees in advies nota om UAS in 2017- 2018 te gebruiken. \\r\\nVerplaatsen van Beta;s naar centraal hoofdgebouw, wat voor problemen zou dat opleveren? Volgens Cees niet echt. Het te pas en onpas inlopen van docenten, voegt weinig toe. Regel inloop spreekuren enz. Wat kost de ruimte? Niet duidelijk. \\r\\n', '2016-09-20 12:54:39'),\
(86, 24, 126, 'Clusteroverleg FEWEB, FGW FGG\\r\\n\\r\\nFEWEB: \\r\\n- nu het idee dat je kant beginnen met semester 2. \\r\\n- Nog geen overzicht wat je moet roosteren ; Peter\'92s manier is om wat hij binnen heeft, te roosteren en wat niet binnen is, zelfde als vorig jaar. Maakt geen schema. \\r\\n-	6 oktober is digitaal aanleveren \\r\\n-	20 oktober, het hele tentamenrooster moet aangeleverd\\r\\nVraag Irma of de tentamen deadline naar achter gekeken  worden. \\r\\nHet is niet efficient om eerst naar alles te kijken voor de tentamens en daarna naar de lesroosters, weer alle uitvraag bekijken. \\r\\n-	Bespreken met de hele groep. \\r\\n-	Intrekken leenrechten 8 november \\r\\n-	Volgende week bekijken hoe Peter\'92s roostering loopt en of hiervoor additionele hulp voor nodig is. Donderdag wekelijks moment,  afspraak peter\\r\\nPPE: 44 studenten. \\r\\nGodgeleerdheid , gedisciplineerd, filosofen wat dwallerig. \\r\\nEens in de drie weken clusteroverleg?\\r\\n\\r\\n', '2016-09-22 17:56:21'),\
(87, 24, 126, 'FGB, druk met de dagelijkse ophogingen. Meer masterstudenten dan vorig jaar, lintboekingen opknippen enz. Tentamen semester 1 rechtzetten , gaan nu weg ter controle via Carla, naar opleidingsdirecteuren. Extra tijd is apart geroosterd conform notitie. \\r\\nCarla zit te vol, op de grens van in paniek! \\r\\nFSW: druk bezig met ophogen van zalen. Heeft HOVO zo grote 00 zaal nodig? Yvonne stemt af met Aimee \\r\\nUitvraag S2: 1 opleiding coordinator, rest is binnen. Start ermee als inteken voor Sem1 is afgerond. \\r\\nRCH: loopt goed. Start wijzigingen , reguliere wijzigingen\\r\\nUAS roostervraag: ongeveer 90% is aangeleverd. \\r\\n\\r\\nClusteroverleg FSW/RCH/FGB\\r\\nA400 zaal staat geblokkeerd voor PPE. Is A500 geworden. Teamoverleg. \\r\\nFSW: wijzigingen, redelijk bij. Nu zalen omboeken. Tijdrovend om te schuiven. \\r\\nFSW sem 2: bezig met tentamens, neem basis van vorig jaar. Hopelijk volgende week beginnen met roosteren. \\r\\nRCH: loopt op schema. \\r\\n\\r\\nFGB: \\r\\nMarijke: mailbox roosterwijzigingen bezig, te kleine zalen vergroten\\r\\n-	Veel problemen met doorvoeren gegeven naar SAP. \\r\\nS2: nog niet naar gekeken (marijke) \\r\\n-	Aglaia: FGB: er wordt lustig gewijzigd omdat men niet heeft nagedacht, vage redenen enz. \\r\\n-	Uitvraag S2 komt binnen. \\r\\nDigitent heeft een verkeerde planning gemaakt, door digitent, waardoor een tentamen morgen van half 4 naar 4 uur moet. \\r\\n\\r\\nClusteroverleg eens per 3 weken plannen. ', '2016-09-22 17:56:34'),\
(88, 24, 126, 'Clusteroverleg 26-9\\r\\n\\r\\nOver stuk van Rianna: wij weten niet wat voor toets het is, en daarom welke deadline gehanteerd moet worden. \\r\\n-	De digitent zou  dan graag ook geen aanpassingen doen in het rooster, ander moment of samenvoegen van tentamens, zonder overleg met roosteraar. \\r\\n-	Willen oude bloktijden buiten de unijakaweken, maar volgens mij is dit vrijgegeven. \\r\\n-	Willen vrijheid of niet mbt bloktijden. Als het geen conflict oplevert, dan afwijken van tijden?Per wanneer kun je een andere tijd voorstellen buiten de bloktijden? Nadat FCO het tentamen \\r\\n-	Pilot? Voorstel?\\r\\nKerstvakantie. \\r\\nDoet overal evenveel pijn,verbouwing van de Tent.\\r\\n\\r\\n?	Tentamen deadline aanleveren tentamens: 6 okt en 20 okt: mag dit twee weken later?\\r\\n\\r\\n?	Pilot boeken buiten de Unijakaweken: ook periode 2 en 3?\\r\\n\\r\\n?	Irma: Is het gebouw dicht, de dag na hemelvaart en de dag na koningsdag?\\r\\n', '2016-09-26 08:23:54'),\
(89, 24, 126, 'Bila Beta\\'s : 26-9\\r\\n-	Werkplek centraal of niet. Inschatting is dat indien de beta;s / FALW niet in WN gebouw zit, is de verwachting dat kwaliteit van het rooster zal afnemen, totstandkoming zal lastig zijn. Nu komen docenten ook ad hoc binnen. Ander aspect is dat FALW en FEW roosteraars, 10 keer per dag naar de BASsers gaan, om af te stemmen.  Deel van de populatie zal hier van schrikken. Afspraak maken. Toegang A0 gang is afgesloten voor docenten, men moet op de telefoon mobiel bellen om . Moet een goed alteratief geboden worden. \\r\\n', '2016-09-26 12:16:23'),\
(90, 24, 126, 'Anneke Dubbink (door Sharon) \\r\\n\\r\\nAanleiding\\r\\nWeerbaarheidstraining: balie functie van faculteiten overnemen. \\r\\nAnneke heeft: team zodanig gebouwd dat mensen op de hoogte zijn van elkaars sterkte en zwakke kanten. Hadden een buddy, tijdens en na de training, om van elkaar te leren. \\r\\nVerschillende dagdelen, trainer en acteur heeft meegekeken, hoe jij je tov studenten/collega\'92s gedroeg, en kon feedback krijgen. Uiteindelijk heeft iedereen daar gebruik van gemaakt. 1 op 1 gesprek met trainer. Wat ik kan ik heel goed en wat kan jij heel goed. \\r\\nAnneke maakt vrij uitgebreid voorstel. Weerbaarheid, en eigenlijk spelregels hoe met elkaar om te gaan. Latitia is teamleider geworden. \\r\\n\\r\\nHoelang traject: lange intake. Daarna voorstel uitgebreid, toen 4 dagdelen bij elkaar, met anneke en andr\'e9, en daarna terugkoppelmoment, ook aan de backoffice. Was ook waardevol. \\r\\n8 \'e1 9 maanden\\r\\nHeeft ook geleid: brownpaper over de reorganisatie, welk moment vond je het rotste tijdens de reorganisatie.\\r\\n>> levert ook spanning op, moet ook nazorg doen <<', '2016-10-06 09:05:53'),\
(91, 24, 127, 'Referentiebezoek EUR 7-10-2016\\r\\n\\r\\nMarkconsultatie in 2013: \\r\\n-	Welke partijen\\r\\no	Scientia\\r\\no	Advitea\\r\\no	Celcat\\r\\no	Infosylum\\r\\no	Adastra\\r\\no	Symmestry, \\r\\n-	Hoe ziet het landschap er over 3 jaar uit? Meer dan Scientia. \\r\\n-	Programma van eisen, groot invloed is Harry geweest.\\r\\n\\r\\n-	Programma van eisen, hebben Erasmus met Erasmus MC, aparte aanestedingblokken. \\r\\n\\r\\n-	Toekomst visie van Erasmus, was meer automatisch roosteren, dus het systeem laten bepalen wanneer het geroosterd wordt. \\r\\n\\r\\n-	Het is een ilusie, zie patat, om te denken dat je met 1 knop, een rooster hebt. Hoe goed wordt een rooster met automatisch roosteren? \\r\\n\\r\\n-	Met een centraal roosterteam kun je veel beter afstemmen hoe je de soft constrains. Door meer automatisch te roosteren, kun je betere spreiding realiseren.  En hoger gebruik van ruimten. \\r\\n\\r\\n-	Het geeft je roosterteam wat slagkracht. \\r\\n\\r\\n-	Roosteren bij EUR is vooral nog zaaltoewijzing. Niet zozeer roosteren. Bij goed gebruik van S+ zit de nadruk van de roosteraars in het voortraject. \\r\\n\\r\\n-	Tentamenroostering is interessant fenomeen  , toewijzen van de blokken is een lastig probleem. ', '2016-10-07 13:59:06'),\
(92, 24, 126, 'Week 27 en week 28 staan niet in opgenomen. Het is geen reguliere tentamenweek. Wat doen ze wel en niet. \\r\\nIs het een fout in het schema dat dag na hemelvaart staat niet afgeblokt.\\r\\nFCO, graag de computerzaal boekingen niet onderwijs, laten boeken door FCO , niet meer door ons. IZB? Liever niet omdat die een hele zaal boekt en niet individuele computers zoals dat in studyspot kan. \\r\\nComputerzalen hebben niet dezelfde gegevens. Bij alle zalen staat een pamflet waar staat dat als er iets ontbreekt dat ze bij FCO terecht kunnen , maar iet bij de computerzalen. \\r\\nGeschiktheden inventariseren beamer enz. en in Syllabus weergeven.  \\r\\nNa 1 december zelf kunnen boeken buiten de Unijakaweken. \\r\\n', '2016-10-10 10:03:57'),\
(93, 24, 126, 'CLusteroverleg Beta\\'s\\r\\nBeta overleg\\r\\n-	FALW: roostering, 1/3e is klaar (ron) en 1/3 half gebakken en 1/3e nog niet. \\r\\n-	1/3e klaar, 1/3 is binnen en 1/3e is nog niet binnen (Trudie)\\r\\no	Willem geeft mensen die niet in Science Owl kunnen, dan maar via mail \\r\\no	Waarom kunnen mensen niet in Science Owl? Afstemmen met Willem. 	\\r\\n-	Minder dan 50% van de aangeleverde roosteruitvraag gaat via Science Owl  of niets aangeleverd. \\r\\n-	Niets aanleveren is een standaard route voor vraag van zelfde rooster als volgend jaar\\r\\n-	FEW: zit nu op ongeveer 40%. \\r\\n-	IZB, losse zaalboekingen via secretaresses, niet via roosterteam. \\r\\n', '2016-10-10 11:46:44'),\
(94, 24, 124, 'Bila Cees van Gent 11-10\\r\\n\\r\\n-	Bezetting roostering FALW | Sentiment, complete staf FALW, vinden het zwaar kut, dat sommige mensen achter een berlijnse muur zijn. Vroeger konden ze naar binnen lopen en dingen vragen en nu niet meer. Specifieke kennis zitten bij hun in het hoofd wat nog niet in systemen zitten. Cees wil weten wanneer we dit formeel aan het terugkoppelen, heb hem aangegeven dat ik dat doen wanneer ik beter plaatje heb over wie wat gaat doen. \\r\\n\\r\\n-	Losse zaalboekingen \\r\\n\\r\\nBesluit dat losse zaalboeking niet meer bij de roosteraars worden gedaan. Via de directeur bedrijfsvoering communiceren. Erna/Marjolijn. Erna wil dit via Cees laten lopen/ \\r\\n-	Blokkeren van praktikum\\r\\n-	\\r\\n\\r\\n', '2016-10-12 14:43:46'),\
(95, 24, 126, 'Clusteroverleg \\r\\nFSW : \\r\\n- nog 20 vakken roosteren voor de 8e nov intrekken leenrechten.\\r\\n- digitale tentamens en gewone al naar  FCO. \\r\\n- concept rooster: 8 november \'92s middags 2 weken reactietijd\\r\\n- daarna SAP controle\\r\\n- Jantien draait rapportage SAP, afspreken wanneer. \\r\\nFGB:\\r\\n- begonnen met roosteren Sem2. \\r\\n- tentamens stonden erin, herkansingen semester 1 ( en semester 2) vallen voor eind van de zomer. \\r\\n- Aanlevering zou gaan lukken voor 8 nov. \\r\\n- Digitale tentamens zijn klaar\\r\\n- Zou fijn zijn als zij een seintje geven wanneer ze gaan beginnen; omdat ze niet altijd op tijd door krijgen, willen ze de nasleep riching FCO zo goed mogelijk doen. \\r\\n- Annemarie: wat niet is aangeleverd, krijgt vanaf nu het rooster van vorig jaar.\\r\\n- Master moet nog gepland worden, 15 vakken\\r\\n- Joost geeft voor 8 nov aan of de leenrechten voor FGB verlengd zouden moeten worden. \\r\\n\\r\\nRCH:\\r\\n- 3e jaar bachelor nog afmaken, masters nog bijna helemaal doen, nog 40 vakken roosteren. \\r\\n- lessen vooral periode 4 en 5, en in periode 5 veel feestdagen die wegvallen\\r\\n- UAS werkt niet, veel last van. \\r\\n\\r\\nLeenrechten  en extra zalen', '2016-10-18 09:27:14'),\
(96, 24, 124, 'BUIla Irma 19-10\\r\\n\\r\\nBila Irma\\r\\n-	Computerzalen FEW; gekoerst wordt op duo boot linux-win. Krijg mail van Irma over afspraken. \\r\\n-	Afgesproken: activiteiten van FEW wordt  met voorrang geroosterd in zalen van FEWEB, Dirk Jan stemt dit af met Saskia van Es en Maritha.\\r\\n-	Volgende week na dinsdag krijg ik van Irma  lijst stilteruimtes\\r\\n', '2016-10-19 14:46:04'),\
(97, 24, 124, 'BIla Ella 18-10-16\\r\\n\\r\\nGesprek over FEWEB roostering; Ella\\r\\n?	Over last minute intekenen\\r\\n-	Ella geeft aan dat ze in alle gremia enz. helder hebben aangegeven dat FEWEB wil verhogen. \\r\\n-	We zijn er niet op uit zalen te vergroten of extra activiteiten\\r\\n-	Indien een zaal toch vergroot moet worden, dan zou FEWEB met de roosteraars het gesprek aan.\\r\\n-	Periode 4, proces afstemmen, stem ik af met Marloes. Week na de deadline van inschrijvingen, rapportage , zien we welke opgehoogd moeten worden, uitkomsten doorspreken, eerst met mij bespreken, als het gaat over andere zaal of extra activiteiten\\r\\n?	Mirella Kleijnen; inschrijven voor groepen met conflicten\\r\\n-	Voor periode 1 zetten zelf studenten in groepen\\r\\n-	Nadenken: hoe kunnen we de eerste jaars studenten bereiken om te juiste vakken te kiezen\\r\\n-	Het is lastig om onze eigen studenten te bereiken, cohorten informeren\\r\\n-	Het onderwijsbureau neemt de klachten (voor last minute) in tekenen in behandelen\\r\\n-	Naam en groepsnummer van 2 studenten, kunnen we wisselen, maar in principe gaat de groepsindeling via onderwijsbureau. Studenten doorsturen naar het studiesecretariaat.feweb@vu.nl\\r\\n?	Beeldvorming en image. Als je een slecht imago hebt, wordt alles hierop gegooid. \\r\\n?	Wat is er mis met het tentamenrooster?\\r\\n-	Definitief zetten, en controle in SAP \\r\\n-	Vakken stonden open, en tentamens stonden dicht\\r\\n-	Tentamenorganisatie kreeg nog heel veel wijzigingen; staat een tentamen van 2,5 uur, maar dat hebben ze niet, alleen van 2 uur.\\r\\n?	Econometrie vakken over 2 periodes, en voor 1 vak is het over 1 periode geroosterd. \\r\\n?	Roosteraar moet echt telefonisch bereikbaar zijn, maar ook uitgelegd dat we niet altijd fysiek aanwezig kunnen zijn\\r\\n-	Er is veel ontevredenheid, ook bij faculteitsbestuur, graag met Rob en met Mira\\r\\n-	Ook omdat de faculteit altijd tegen de centralisering is geweest,\\r\\n-	Teruggeven \\r\\n?	Hoe kunnen we samen met de hoofden bekijken of de communicatie met de docenten te verbeteren daar waar het gaat bijvoorbeeld over roosterwijzigingen\\r\\n', '2016-10-19 14:47:07');\
INSERT INTO `project_notes` (`id`, `user_id`, `project_id`, `notes`, `created_datetime`) VALUES\
(98, 24, 124, 'BIla Karin Bijker 18-10-16\\r\\n\\r\\nBila Karin\\r\\n\\r\\nOver reacties WP maandag \\r\\n-	WP heeft informatie achterstand, WP gaat van dingen uit, wat wij niet weten en andersom\\r\\n-	Persoonlijke contact, dat je naar iemand toe kunt stappen of bellen\\r\\n-	Communicatie\\r\\n\\r\\nErvaringen van Karin, hoe heb je het ervaren \\r\\n-	Roostering kabbelde wel voort\\r\\n-	Yvonne neemt de verantwoordelijkheid, ze baalt dat ze de zaakjes zelf wel op orde heeft, maar \\r\\n-	Bachelor en premasters, omgooien van curriculum : Liggen bij de opleidingscommissies voor beoordeling. Voor de premasters is het idee om al het onderwijs op vrijdag te plannen. \\r\\n-	Ook blended learning, door de week heen week hoorcollege kunnen bekijken, en act doen, en vrijdag het HC en WC. Deadlines zijn heilig. \\r\\n-	Ook wijzigingen bij de masters.\\r\\nTentamenorganisatie:\\r\\n-	Centraliseren van tentamenorganisatie: FEWEB en BETA willen dat niet, anderen zeggen: nu ook niet oppakken\\r\\n-	Extra tijders, wellicht wel: surveillanten, ruimtes, tentamens vermenigvuldigen, laptops met grote letters, apart zaaltje enz. Iedereen organiseert dit zelfstandig.  Jos\'e9, noteert het voor 2017\\r\\n-	Andere punt gaat over Yvonne: Met Hanneke besproken wat het aanbod was van Erna. Erna: is er ruimte om Yvonne deels op de payroll te houden voor FSW?\\r\\n', '2016-10-19 14:47:56'),\
(99, 24, 127, 'Uit ref bezoek Scientia 19-10\\r\\n\\r\\nDrie hoek docent, student, zaal, wie is het belangrijkste.\\r\\nBusiness proces review Scientia \\r\\nDashboards\\r\\nExcel data, maak er maar een rapportage van', '2016-10-19 14:49:21'),\
(100, 24, 126, 'Overleg Erna Marjolijn 31-10-2016\\r\\n\\r\\n\\r\\n-	De vrijdagen zijn vrije dagen. In periode 5 vallen 4 vrijdagen uit. Check of er bij de faculteiten behoefte is om op vrijdag na hemelvaart of koningsdag om terug te komen bij de VU.\\r\\n-	Robert Jan : afstemmen of er ruimte is voor 8700 SOZ, of OO2, schuiven binnen OO1. \\r\\n-	42, direct aan de gang en de factureren in 2016, voorkeur. \\r\\n-	Marjolijn checkt of facturen Dirk Jan va feb onder mijn project staan. \\r\\n-	OO1, PID OPO,  jan april. Voorblad maken, en PID erbij, gaat om dit project . Marianne Karsen afstemmen. Verklaring waarom het meer is dan het was\\r\\n-	Of: nieuw projectaanvraag voor jan \'96 mei. \\r\\n', '2016-10-31 19:02:15'),\
(101, 24, 126, 'CLusteroverleg FSW-FGW-RCH, 3 nov 2016\\r\\nFSW: clusteroverleg\\r\\n\\r\\n-	Bijna klaar, \\r\\n-	87 lokalen te kort, waarvan een aantal 00 zalen. Minder onderwijs , of minder docenten, grotere groepen enz. voor hele dag vol. \\r\\n-	Geschiktheden is slordig ingericht. Moet voor volgende database jaar opgeschoond worden. \\r\\n-	Spreiding! Meer geconcentreerd op alle dagen. Deeltijdbanen is een probleem.\\r\\nFGB: \\r\\n-	FBW: \\r\\n-	ULO: hadden twee weken voorjaarsvakantie ipv 1 week bedacht. \\r\\n-	Automatisch roosteren Yvonne: kostte ook tijd\\r\\n-	Ulo staat erin.\\r\\n-	BW: 1e en 2e jaar staan erin, dan moeten de masters er nog in. \\r\\n-	Leenrechten FGB : maandag geeft Joost door wat \\r\\n-	Lopende rooster issues: evenement van een studentenvereniging, waren vergeten een grote zaal te boeken, college moest ervoor verplaatst worden\\r\\n-	Masters FPP staan erin, bijna geen lokalen knelpunten. Researchmasters, zelfde. \\r\\n-	Concept rooster? In delen versturen. Jaar op jaar. Enz. \\r\\n-	Semester 2, overzicht van alle tentamens. Gaat Aglaia doen. \\r\\n-	Weinig overzicht bij FGB door coorindatoren of docenten over de programma;s en afhankelijkheden\\r\\n-	Peda: bijna erin, Psychology. \\r\\n-	Honoursprogramma was toen niet geroosterd, men wist het niet. \\r\\nRCH: \\r\\n-	Zit erin, heeft 14 collegezaal problemen, en 90 werkgroepproblemen, voor de rest staat het erin, en concept is nu uitgestuurd. \\r\\n-	Tentamens rechten erin, FGB digitale en erin gepeuterd. ', '2016-11-06 09:03:50'),\
(102, 24, 124, 'BIla Marloes, vervangster Ella FEWEB, 3 nov 2016\\r\\n-	Kan inschrijfmodule checken wanneer een student zich intekent, dat hij al een ander activiteit heeft op dat moment, agenda checker.\\r\\n-	Ron, inwerkprogramma, in januari . \\r\\n-	Bij inwerk Ron \'96 Els \'96 Maritha, komt Marloes ook mee. \\r\\n-	 \\r\\n', '2016-11-06 09:13:04'),\
(103, 24, 124, 'Bila Vanessa FEWEB tent org, 3 nov\\r\\n\\r\\nVanessa\\r\\n\\r\\n1)	FEWEB is gewend om tentamens alleen aan te passen voor de intekenperiode, dus voor 15 juli. Ik krijg van Vanessa een lijstje voor welke tentamens het gaat. Tentamens staan vast.\\r\\n2)	Hoe wordt gecontrolleerd of het tentamen klopt. Concept lesrooster is ook concept tentamens. Docenten weten dat ze voor 15 juli wijzigingen moeten doorgeven, en dat er dan nog tijd moet zijn voor de roosteraars om het aan te passen. \\r\\n\\r\\n', '2016-11-06 09:13:39'),\
(104, 24, 124, 'Bila irma\\r\\nInventarisatie vrijdagen collectieve vrije dagen, na inventarisatie kan het naar Irma, die kijkt hoe verder vorm te geven. \\r\\nComputerzalen: faculteit hebben zalen toegevoegd aan de poel. \\r\\nSOZ zou behoeftepeiling doen, hoe computerzalen te gebruiken?\\r\\nLinux computerzalen FEW, niet in de poel. \\r\\nHet gebeurt al dat er interne klanten (diensten) gebruiken van computerzalen. \\r\\nDUS: computeralen zelfde stramien als leszaken: na def rooster ook in IZB en in studyspot, alleen geen externe aanvragen van buiten de VU. FCO kan de reserveringen afhandelen. \\r\\nComputerzalen moeten ook meegenomen worden in de leenrechten!\\r\\nNT2: willen van 8 naar 12 zalen. Extern huren? Hoe verhoudt zich dat met regulier onderwijs. Zelfde constructie als HOVO? Hoe komen we aan 4 extra zalen? Extern huren? Wie betaalt dat? Actie: Saskia analyse van gebruik NT2.\\r\\n', '2016-11-10 19:45:13'),\
(105, 24, 127, 'Bob van Graft: \\r\\nZorg ervoor dat je de toko op orde,  en processen. \\r\\nBusiness analyst, vertalen naar parameters voor aanbesteding.\\r\\nSurf, aan te halen of ze een rol daarin willen spelen. \\r\\nIntakemeeting. Waarbij alle partijen van IT aan tafel. Om daar een presentatie te geven, diepgaandere sessie. Projectvoorstel, wat wil je functioneel, welke processen. Eerste contact. Uitkomst: volgende stap, die moet dit opleveren, die moet dat opleveren. Belangrijkste : breed kennis delen over het roosteren. Project en innovatie club. Roel Nobak, Richard Vader, FB , Tech beheer, \\r\\nOp basis van functional requirements, dan kunnen requirements van ICT nog veranderen. \\r\\nIBM die de roostering inkoopt en implementeert bij VU, ervaring binnen implementatie van roostersystemen binnen de VU. \\r\\nCSC, CDI, \\r\\nExit strategie, belangrijk bij aanbesteding, ofwel hoe kun je weer van elkaar af. Wachtkamer constructie (backup partij).\\r\\nGemiddelde leverancier zegt overal \\r\\nGoede marktorientatie is belangrijk\\r\\n\\r\\nRobuste oplossing, up time, snel weer online, goede integratie met SAP, goede verbindingen, gecertificeerde interfaces, voldoen aan standaarden, dit is onderhoudbaar en draaibaar. FB en functionele afdelingen, als het niet kan roosteren maar het draait als een zonnetje dan is het ok. ', '2016-11-24 07:28:50'),\
(106, 24, 127, 'Mareanne over onderwijs veranderingen  irt nieuw roosterpakket\\r\\n23-11-2016\\r\\n\\r\\nOntwerp principes: \\r\\nNotitie via Bart\\r\\nGroepsgrootte;\\r\\nFysiek contact is belangrijk, blijven bieden\\r\\nHoorcolleges, en kennisoverdracht : moet men vanaf, andere vormen. Studenten bereiden zich tuis voor, dan groepjes uitwerken dan samen bespreken. \\r\\nFEWEB: opleidingsdirecteuren hebben opleiding in onderwijsdidactiek gedaan, maar BETA\'92s niet \\r\\n PGO opleidingen: VU governance school. PGO rechten fgb en feweb in 1 school\\r\\nRechten liep niet zo met PGO, FEWEB wel, wil internationaal accrediteren \\r\\nDoor bundeling van PGO wordt een school naast een school.\\r\\nPGO daardoor betere zalen hebben. Meer eind middag en avond onderwijs. \\r\\nUCGB: lerarenopleiding en nascholing\\r\\nEngelstalige opleiding. Minder studenten opleidingen. \\r\\nHerinrichten van master portfolio: effect: kijken naar of masters relevant zijn, opleiden voor onderzoekers enz. \\r\\nFeweb werkt met kostendoorbelastingsmodel, andere faculteiten willen naar KDM. \\r\\nGroepen: sommigen werken met inrichten dmv hulp met software. Tweesporenbeleid: sommige doen groepsindeling, sommige laten zelf kiezen. \\r\\nKennisclips, ipv hoorcolleges\\r\\nwerkgroepen verplicht\\r\\nstudenten werken naast rooster: maar praktijk zijn de bijbaantjes flexibel ', '2016-11-24 07:32:37'),\
(107, 24, 126, 'BETA clusteroverleg met Cees:\\r\\n\\r\\nBeta overleg :\\r\\n- Terugblik afgelopen half jaar\\r\\n+ niet veel anders dan ander jaar, \\r\\n+ door sem 1 wijzigingen, kwam 2 in het nauw\\r\\n- Reservering secretaresses IZB.\\r\\n + stukje tekst in de nieuwsbrief, voor donderdag 09:00 uur aanleveren, dan kan met mee. \\r\\n + samen met linda maken \\r\\n + standaard email tekst roosteraars.  (Anne)\\r\\nComputerzalen\\r\\n+ computerzalen kunnen nu alleen door de roostaars geboekt worden. \\r\\n+ Ron maakt computerzalen geschikt voor IZB.\\r\\n+ IZB en kostendoorbelasting?\\r\\n- huisvesting\\r\\n+ gezelschap  per 1 januari van 2 a 3 personen in e kamer. (Tentamenorganisatie)\\r\\n\\r\\n- vooruitblik \\r\\n-	UAS roosteruitvraag: Ron vindt dat er inloopsessies moeten komen. ', '2016-12-05 12:38:21'),\
(108, 24, 126, 'Teamoverleg15-12-16\\nStukje uit Imra Dirk Jan Bila over com[uterzalen mailen naar GNK.\\nNaamgeving computerzalen?\\nFCO. Coputerzalen? IZB? Degeeld worden met FCO. Niet IZB?\\nRon- Noami Over IZB inrichting mbt computerzalen. \\nMaritha pilot UAS testen\\nActiviteiten controleren (aantal). Kmt doordat ze zelf gingen opschonen. \\n\\nBeta Teamoverleg\\nFALW: gaat goed. \\nFEW: gaat goed. \\n\\n', '2017-01-05 16:35:13'),\
(109, 24, 127, 'Over contractverlening Saskia de Munnik\\r\\n\\r\\n\\r\\n\\r\\n-	Functie zwaarte is zwaarder dan bedacht\\r\\n-	Salaris is laag, zit ruimte. Hoe past het werk binnen de functieprofielen. \\r\\n-	Wat je zou moeten doen, dan doe ik meer. Procesbeheer zit in 10. Data analist is minimaal 10. \\r\\n-	Wil nov \'96 feb weg (4 maanden), na de zomer, freelance?\\r\\n-	Contract tot 31 oktober .', '2017-01-18 16:41:21'),\
(110, 24, 126, 'Team overleg 23 - 2017\\r\\n\\r\\n-	Introductie Willem-Jan (UAS roosteruitvraag)\\r\\no	Wat als docenten niets doen\\r\\no	\\r\\n-	Opschonen geschiktheden\\r\\no	Roosteraars sturen BASSER aan hierover\\r\\no	In bulk begrenzen van activiteiten en sjablonen. Kan dat automatisch\\r\\no	Activiteitensjablonen waar nog geen activiteiten aan hangen. (module kan nog niet begrenst worden, enorme vervuiling. Modules met dezelfde naam).\\r\\no	Uitzoeken of dit in bulk gedaan kan worden, Bassers hierop aanspreken\\r\\no	Docenten die uit dienst , in syllabus en in sap en rooster.vu.nl \\r\\no	HRM  haalt ze niet uit SAP. Bas kan de koppeling met module verbreken, dan komt die ook niet door naa Syllabus. \\r\\n-	Uniforme werkwijze controle of wijziging is doorgekomen in SAP (verzoek FGB Baaijens)\\r\\no	Procedure:  Capaciteit ophogen, alleen wegschrijven, alle andere wijzigingen, dan ontroosteren en opnieuw roosteren. \\r\\n-	Status update : computerzalen \\r\\no	Als FCO kan boeken, dan is het ook in IZB zichtbaar, hoe dat op te lossen. \\r\\no	Nog niet alle zalen zijn met iedereen gedeeld. Zlefde manier inrichten als gewone zalen\\r\\n-	Gebruik stiltezaal IN-2B43 (computerzaal) (Aglaia) \\r\\no	Laten aanpassen in FCO dat het een stiltezaal is \\r\\no	Doen we nog aan fluisterzalen? Van wie is deze zaal, kan dat stilte label eraf?\\r\\n-	Leenrechten versie 0.1 kort bespreken\\r\\no	\\r\\n-	Sollicitatie update + wie wil tweede ronde mee?\\r\\n-	4 vrijdagen in periode 5 , wel gebouw open + koffie, geen ICT en AV ondersteuning\\r\\n-	Terugkoppeling gesprek CvB en GV (USR en OR) over onderwijsplanning\\r\\n-	(Heeft iedereen van de centrale roosteraars zijn/haar management drives assessment ingevuld?) Vervolg : individuele gesprekken inp;annen\\r\\n-	Naomi om half 11, ivm bit 64. ', '2017-01-23 10:47:21'),\
(111, 24, 124, 'Gesprek over zalen tbv leenrechten, 23-1-2017\\r\\n\\r\\nOWC (onderwijscentrum), UC GB (9 zaaltjes gekregen in metropolitan, maar gaan toch hun piek in de pool zalen roosteren. Universitair centrum gedrag en bewegen. FGB, FPP, fusie. Beheofteafgelopen jaar: 4 zalen door de week en 13 zalen op maandag. Behoefte was 9 zalen. Eerste verdieping. De piek past niet zullen ze zeggen. Dinsdag tot vrijdag gebruiken wij de 9 zalen in metropolitan. Roosters FGB? Wordt door FGB geroosterd. \\r\\n-	Krijgen 9 metropolitan zalen van UC GB van Marjan Oliehoek\\r\\n\\r\\nComputerruimtes: 2 zalen minder, totaal 40 PC\'92s, minder dan vorig jaar. Willen niet extra copmputerzalen boeken. \\r\\nA400  krijgen we nog  info over ', '2017-01-23 10:49:10'),\
(112, 24, 126, 'Contract Aglaia | in werking zetten. | Eerst via TO| Na akkoord: Moet het zelf initieren , bijzetten dat het conform afspraak is. \\r\\nVerlening Saskia de Munnik, schaal 9 + 250 extra + doorlopen tijdens buitenland? Susanne, contract tot 1 juni 2018 OO2 termijn.\\r\\nTrudie voorstel na de zomer van 1.0 naar 0.8 ivm korte termijn . Akkoord na de zomer. 1 september 2017. \\r\\nStatus huisvesting roosteraars. Nog niet. \\r\\nBart en OO2?\\r\\nSollicitanten, terugkoppeling.\\r\\nUB bibliotheek en tentamens? Stuur mail aan Erna over tentamen  \\r\\nTerugkoppeling ULO dienstverlening. \\r\\nTeamleiderschap. \\r\\nProject vanuit IT, kosten. \\r\\nMarjolijn meenemen in kopie mail stuurgroep. ', '2017-01-25 09:33:51'),\
(113, 24, 126, 'Clusteroverleg RCH FSW FGB 26-1-2017\\r\\n\\r\\n-	Yvonne onderwijsprogramma\'92s, bezemprogramma\'92s. Sap werk. Excelschema\'92s overzicht waar een deel van het programma in UAS (curr. uitvraag) staat. \\r\\n-	Leenrechten kijkt naar het verleden, maar organiseert onvoldoende de toekomstige mogelijkheid om hoorcolleges bijv op andere dagen te plannen. \\r\\n-	Elisha voor FGB : Elisha rooster FPP, helpt om op te ruimen. \\r\\n-	ULO \\r\\n-	Ac struc FGB in SAP lijkt op 1 feb redden.\\r\\n-	FSW, lijkt voor 13 feb te redden\\r\\n-	RCH Ac struc , hoop nieuwe structuur en naamswijzigingen, minoren ingrijpend. Uiterlijk 4 feb klaar. \\r\\n-', '2017-01-26 14:54:31'),\
(114, 24, 124, 'ACASA- heeft bestuur- opdrachtgever van Cees. BV: Nettie vlakveld\\r\\nSamenwerking UVA VU, 3 Bachelor opleidingen en 2 masteropleidingen\\r\\nBachelor: Archeologie Grieks latijns taal en cultuur, oudheidwetenschappen (vanaf 1 sept)\\r\\nOnderwijs vindt volledig plaats in de binnenstad. Door Uva gehuisvest\\r\\n\\r\\nMaster: Archeolgy; ancient studies. (al 5 jaar)\\r\\nDoor Vu en UVA, \\r\\nS\'e9 Jenssen\\r\\nProbleem: Uva roostert heel jaar, wij half jaar. \\r\\nVraag: \\r\\nna 1 september in timeslots. \\r\\n\\r\\nRol Cees: 50% tijd dit project / samenwerking VU/Uva\\r\\n\\r\\n\\r\\n', '2017-02-17 21:53:50'),\
(115, 24, 124, 'Karin FSW over roostering Educatieve Master LVHO. (Samen met de ULO).(5 faculteiten bij betrokken, leveren vakken en docenten). Penvoerder is FSW. \\r\\nLijkt op de educatieve master Taal en cultuur (FGW)\\r\\nS1 2017-2018.\\r\\nMaster is vooral samenvoeging van bestaande vakken bij verschillende faculteiten: \\r\\nFGW FGG FGB (ULO) en FEWEB en FSW (+ 1 nieuw vak S1). \\r\\nLeonie van Dijkhuizen zou, omdat ze FGW ook educatieve master Taal en cultuur roostert, deze kunnen oppakken. Afspraak is dat ik mail stuur aan hun cc Karin, voor intake bij Gerhart en Erna. \\r\\n\\r\\n', '2017-02-17 21:54:04'),\
(116, 24, 126, 'Clusteroverleg RCH FSW FGB\\r\\nFsw roostering: \\r\\nVoorbereiding 2017-2018 \\r\\nAlles in SAP vakken en evenementypes. Docenten nog niet. \\r\\nNieuw format voor output roosterinformatie. Plenair bespreken. \\r\\nRCH: \\r\\nUitvraag: gaat goed. \\r\\n- houd bestandje bij Bevindingen in UAS.\\r\\n\\r\\nFGB:\\r\\n-	Leenrechten 80 zalen nodig . \\r\\n-	In UAS curr en op papier BW. \\r\\n-	Ac Struc staat ook in PP\\r\\n-	Roosteruitvraag: nog \\r\\n\\r\\n', '2017-02-17 21:54:38'),\
(117, 24, 127, 'Ingrid Joustra en Robert Jan Tan\\r\\n\\r\\nIN mei: idee kader totaal OO, dus 2018 oo3 en 2019 OO3 kosten/\\r\\nBest case scenario en worst case scenario en dan onderbouwen en terugrekenen\\r\\nGehele traject: globale schatting. \\r\\nProject kader voor 2017 en 2018.\\r\\nStrategische Portfolio Management : akkoord. 		)\\r\\nFinance F&M: Derk Jan Slagter, vraagt project kader. 	) gezamenlijk advies\\r\\nOPO PID werkgroep : positief advies. \\r\\nIT: zitr in advies van Ingrid Joustra erbij. Zij checkt of het OK is.', '2017-03-01 15:52:48'),\
(118, 24, 127, 'Gesprek My TImetable : Mike en Marco\\r\\n\\r\\n-	Reporting database Scientia nodig voor My Timetable\\r\\n-	Om de Reporting database Scientia te omzeilen door My Timetable kost tussen 10K en 15K.\\r\\n-	Robert-Jan geeft een indicatie van de prijs\\r\\n-	Als MT het zelf doet is de vraag hoe snel de updates zijn.\\r\\n-	MT regelt kunnen zelf de tussendatabase (VU maakt koppeling van SAP naar tussendatabase, MT doet dan de koppeling naar My Timetable), hebben ervaring met Maastricht \\r\\n-	Dingen direct uit SAP uitvragen is een probleem, daarom de tussen database.\\r\\n-	MT wil dan data uit S+ en SAP combineren \\r\\n-	Met security officer gesprek over waar te hosten (intern of extern)\\r\\n', '2017-03-02 16:40:39'),\
(119, 24, 126, 'Over taakverdeling FGW\\r\\n\\r\\n-	Tentamen organisatie extra tijders:\\r\\no	Vroeg verlengers op bij bedrijfsbureau\\r\\no	extra zalen geboekt worden\\r\\no	andere handicaps er ook bij?\\r\\no	Communicatie extra voorzieningen\\r\\n-	Losse zaalboekingen (IZB)\\r\\n', '2017-03-07 07:46:27'),\
(120, 24, 126, 'Over taakverdeling FGW\\r\\n\\r\\n-	Tentamen organisatie extra tijders:\\r\\no	Vroeg verlengers op bij bedrijfsbureau\\r\\no	extra zalen geboekt worden\\r\\no	andere handicaps er ook bij?\\r\\no	Communicatie extra voorzieningen\\r\\n-	Losse zaalboekingen (IZB)\\r\\n', '2017-03-07 07:46:27'),\
(121, 24, 126, 'Bila Erna/Marjolijn,\\r\\n\\r\\nTrudie: functiewaardering voor de zomer vakantie inplannen\\r\\nTraject: loopbaantraject, ontslag wordt moeilijk tot onmogelijk, wel dossieropbouw, \\r\\nWellicht Anneke hierin betrekken\\r\\nPeter, terug in schaal?\\r\\nErna denk dat het fijner als hij weg zou gaan? \\r\\nLoopbaantraject? Nieuwe baan in schaal 8?\\r\\nMet Suzanne en Anneke gesprek aangaan. \\r\\n\\r\\nNieuwe teamleider: na geprek Anneke en Susanne, kijken hoe in vulling te geven en per wanneer. Idee zou zijn DJ tot en met OO2 teamleider, en dan ook iemand hebben ingewerkt. \\r\\nRuimte: \\r\\n\\r\\nPlattegrond filosofenhof: mail Marjan. Bezettingsmeting: wacht op reactie , zoveel tijd is er (iig) voor reactie.\\r\\nEnkele weken respijt', '2017-03-28 06:40:51'),\
(122, 24, 126, 'CLusteroverleg FGB/FSW/RCH\\r\\n\\r\\n-	UAS uitvraag\\r\\n-	FSW: alles is binnen. Uitdraai is niet leesbaar. Docentbeschikbaarheid hangt er nog niet aan. Meer tijd eraan kwijt door roosteraar . Overzetten in oude roosterformulieren.\\r\\no	Roosteraars naar kijken. \\r\\n-	FGB: 		\\r\\no	Werkt met UAS. Switcht. Zou graag wel een derde scherm willen hebben. Joost vraag in Roosteroverleg.\\r\\no	Tentamens staan er nog niet in\\r\\no	Heb eerder kunnen beginnen\\r\\no	Als het onduidelijk is, zelfde dag antwoord op vragen\\r\\no	Pedagogiek nu alle gegevens binnen. Niet in uas maar op papier\\r\\no	Pega wil al onderwijs op maandag en woensdag hebben. En op maandag juist minder leenrechten voor grotere zalen 90/120, maar wel een 200 zaal.  Misschien eind april neerleggen in roosteroverleg. \\r\\no	Tentamenrooster deed Aglaia, maar wordt nu gedrie\'ebn opgepakt, wel afstemming. \\r\\n-	RCH: \\r\\no	blij met UAS\\r\\no	Blij met de leenrechten\\r\\no	Modules staan niet goed in SAP, \\r\\no	Op zoek naar achterwacht voor in April : Joost pakt incidentroosterbeheer op. \\r\\n', '2017-03-30 11:06:34'),\
(123, 24, 126, '-	Tussentijds functioneringsgesprek, aangeven herziening taken en terugblik afgelopen jaar -> voorstel is asessment en welicht coach om weer op nievau te komen/perspectief \\r\\n-	Voor zowel Peter als Trudie het voorstel \\r\\n-	Traject afstemmen met Susanne Backer. \\r\\n-	Info over assesment van Anneke D. \\r\\n', '2017-03-30 14:24:19'),\
(124, 24, 126, 'Clusteroverleg RCH - FSW - FGB\\r\\n\\r\\nFSW:  krappe tijd maar voor de rest niet \\r\\nNieuwe uitvraag rapportage. Kleuren bij printen gaan weg. \\r\\nKleine aanpassingen gedaan en voor de rest niet. Weinig communicatie over dat het is aangepast.\\r\\nOpen klikken en soms niet. \\r\\nWindows instelling groter lettertype in . In SAP en Syllabus gebeurt het ook. Outlook \\r\\nLeenrechten, van gelijke orde als voorgaande jaren. Nieuwe vakken. \\r\\nFGB: \\r\\nJoost Bachelor zo goed als klaar. ULO klaar, BW bachelor bijna klaar, nu masters. Relatie Syllabus SAP\\r\\nTime Out bij scrollen. Dagroosterbeheer, is goed te doen. \\r\\nVoor dit cluster een moment prikken. \\r\\nClusterkoehandel\\r\\nDinsdag voor hemelvaart bij Joost \\r\\nMaandag voor de dinsdag \\r\\nGeschiktheid zonder zaal labelen', '2017-04-20 12:37:52'),\
(125, 24, 126, 'BILA marjolijn, Erna\\r\\n\\r\\nHuisvesting  :\\r\\n-	Nog geen reactie Marjan \\r\\n-	Volgende week bezettingsmeting\\r\\n-	Sturen op verhuizing\\r\\nBudget OO1, financiele bijdrage van 40 K?  \\r\\n-	4 maands afwachten, overzicht van geheel\\r\\n-	Dan met Robert Jan doorspreken- Marjolijn en Dirk Jan\\r\\n-	42 factuur? Robert Jan is er een factuur?\\r\\n-	Dirk Jan facturen \'96 met Robert Jan afstemmen. \\r\\nElla en last minute intekenen  \\r\\n-	Naintekenen mag niets betekenen voor ondersteuning na-afloop?\\r\\n-	Erna zou met Mira / en Rob spreken erover | Mail hierover. \\r\\n-	Dirk Jan heeft met Erna besproken. Erna deelt de lijn met de afspraken en Erna wil het graag bespreken, indien nodig gesprek met Rob en Mira . \\r\\nDeelprojectleider is nog geen uitgemaakte zaak  \\r\\n-	Sybren , is enthousiast over. \\r\\n-	Kosten: via P&O \\r\\nL&D support, en vervolgstappen zetten  \\r\\n-	Met Nelleke over spreken en erbij spreken\\r\\n-	Dit is wat ik zie, dit is wat ik wil veranderen.\\r\\nMY Timetable, wie betaalt?  \\r\\n-	Moet je verder het plan verder uitwerken, als het \\r\\n-	College moet ok geven. Na de 4 maands rapportage. Kans na deze rapportage. Zelf mee investeren, maakt altijd een goede indruk. We denken dat er in het project wat ruimte zit. \\r\\n-	\\r\\n-	Met Richard Vader scherp krijgen van offerte\\r\\n-	Met Martijn van Noort checken hoe en wat\\r\\nNotitie niet gezamenlijk aanbesteden UVA VU\\r\\n-	Als het te lang duurt, dan via Erna naar Vinod/Marjolijn  \\r\\nAanwezigheid eerste week januari:\\r\\n-	Intekentermijn: last minute valt op 2 en 3 januari. \\r\\n-	Bezetting onderwijsplanners.\\r\\n', '2017-04-20 12:38:26'),\
(126, 24, 126, 'Bila Erna\\r\\nDeacharge 001\\r\\nDecharge OO1, als alle rekeningen zijn geregeld. Met Robert Jan Tan. Daarna met OPO PID? Als geld uit onderwijsagenda, dan ook Mareanne Karssen vragen. \\r\\nMedezeggenschap en aanbestedingstraject: Op basis van DLO21.\\r\\nMoeten we nu de OR (Susanne de Visser, hoofd juridische zaken, moet dat kunnen zeggen). \\r\\n1)	Omvang financieel\\r\\n2)	Impact op het personeel \\r\\nAls het JA is, dan moeten ze advies geven over het proces, niet over de uitkomst van de aanbesteding. Aan het einde, kijk of het OK is verlopen. \\r\\nMichael van Raaphort\\r\\n\\r\\n', '2017-05-06 19:10:07'),\
(127, 24, 86, 'Cursus Jaargesprekken bij de VU\\nBelangrijk is he smart afspraken maken aan het begin van de cycles, zodat het terugkijken veel minder spannend wordt. POP! Niet alleen over de projecten of andere incidentele of korte termijn klussen maar over de hele linie.\\nHoe maak je smart afspraken? Op basis van welke kenmerken wil je de kwaliteiten het roostersysteem verbeteren?\\nGeen inspanningsafspraak maar een uitvoer plan.\\nDOELEN van jaargesprekken:\\nPrestaties: meten (doet ie wat ie moet doen, en doet ie dat goed?)\\nPotentieel: duurzame inzetbaarheid, talentmanagement\\nPlezier: Motivatie, erkenning, luisterend oor\\nBeter niet vragen waar wel je over 5 jaar, (en die functie is er dan niet), maar vragen welke elementen er in je functie zijn die we je meer kunnen laten doen. \\nNiet praten over persoonskenmerken maar over kennisvaardigheden -> werkgedrag -> resultaten\\nWat verwacht je van iemand???\\n1) Wat zijn de belangrijkste clusters van resultaatgebieden\\n2) Per cluster: welke eisen stellen we eraan?\\n Beoordelingstraining.nl (video over hoe je een functie smart kan maken).\\n\\nBij positief oordeel: doorvragen bij positief oordeel:vraag of het succes op andere termijnen nog toepasbaar zijn. \\nBij negatief oordeel: direct jouw oordeel teruggeven, niet eerst vragen hoe ze het zelf ervan vonden. Hang yourself approach\\n \\n', '2017-05-08 15:16:09'),\
(128, 24, 126, 'BIla Erna/Marjolijn\\r\\n\\r\\nmedezeggenschap in aanbestedingstraject  \\r\\n-	Gesprek met Hein? Jolijn afspraak? Imke Limkens Business PL\\r\\nvoortgang commissie roosterwijzigingen  \\r\\nRoosterproces, nieuw vervaldag en knelpunten\\r\\nnieuwe teamleider Plannetje bedenken? \\r\\n- Communicatie richting team  \\r\\n- Plan door Marjolijn\\r\\n- Proces uitzetten? Met Susanne ?\\r\\n- Start in september\\r\\n\\r\\nOPO juni agendering, hoe te formuleren, wat bereiken?  \\r\\n-	Terugkoppeling ronde + NSE scores + samenvattong OO2 + uitgelijnd wat staat er op de rol. \\r\\n-	Vraag: we zien dit nu, het is veschillend en ruimte voor verbetering: \\r\\no	We hebben dit en dit in de planning staan. Spreken jullie daat commitment voor uit?\\r\\no	Als we ermee aan de slag gaan, moet het OPO er iets van vinden. \\r\\no	Ze realiseren dat zich dat ze VU brede afspraken over maken. \\r\\no	Wat hebben we tot nu toe gedaan aan \\r\\no	Samen op die weg door te gaan \\r\\no	Voorstel naar Erna/Marjolijn en Nico.\\r\\nIn HO, zelfde doen. \\r\\n\\r\\nLeonie/Elisha aan de slag met jaarplan uniforme werkwijzen  \\r\\nhuisvesting?  \\r\\nfinanciele afwikkeling OO1 lijkt positiever  \\r\\n\\r\\nVervolg ruimte reservering\\r\\n-	Hoe voorkom je dat alles niet omhoog gedelegeerd wordt\\r\\n-	Hoe zou dat kunnen? Ze zijn vrij streng. Moet alle stappen gepaseerd worden \\r\\n-	Adviezen van de partijen en decaan\\r\\n-	Proces even uitschrijven.\\r\\n-	Verwachting dat eerste jaar paar keer voorkomt en daarna veel minder tot niet. \\r\\n-	Financiele consequenties moet duidelijk zijn en voor rekening van faculteit\\r\\n-	Terug hamerstuk naar CvB\\r\\n-	\\r\\n-	Kan Opera in Griffioen?\\r\\n\\r\\nUAS vraag curr uitvraag\\r\\n-	Geneeskunde; florien, ze doen niet me met curr uitvraag, roosteruitvraag? Florien de Ruiter?\\r\\n\\r\\nStuurgroep: NSE opnemen agenda', '2017-05-23 14:49:13'),\
(129, 24, 126, 'Bila Bart\\r\\n\\r\\nGriffioen / Rialto \\r\\nZij gaan in VU NU gebouw, gaan onderwijszalen gebruiken hiervoor. Sept 2019 onderwijs in gebruik. Voor bepaalde type voorstellingen moeten ze al ruimt van te voren plannen. Anne: bijwerken van proces met Rialto n Griffioen als ze naar campus komen.\\r\\nBijeenkomst aanbesteding.   \\r\\nEerste 20 minuten terugkoppeling Bart. \\r\\nRemco iets over aanbestedingstrajecten ervaringen VU\\r\\nDirk Jan projectaanpak aanbesteding Roosterapplicatie. \\r\\n\\r\\nAfspraak Bart Aglaia Dirk Jan \\r\\nover koppelen docent in SAP en moment wanneer\\r\\n\\r\\nVervuiling in S+\\r\\n- 	er wordt vroegtijdig en kopie gemaakt van de database in S+, waardoor de vervuiling is ontstaat\\r\\n- FB draait rapportage. BAS  herstelt FB draait nieuwe rapportage\\r\\n\\r\\nUAS roosteruitvraag: \\r\\n-	Ik moet gegevens aanleveren die niet relevant zijn.\\r\\n\\r\\nPilot notificaties FEWEB?\\r\\n-	Ligt aan mij?\\r\\n-	Overleggen met Ron  en Maritha\\r\\nBerichtregel instellen om 80% direct naar prullenbak\\r\\n-	Instructie schrijven\\r\\n\\r\\n', '2017-06-13 15:31:04'),\
(130, 24, 165, 'Leenrechten S2 (klaar)\\r\\nUAS management rapportages (morgen gesprek met Pieter), zie voorstel Saskia\\r\\nRoosteruitvraag per opleiding (rapportage obv uas gegevens, in Tableau). \\r\\nMismatch UAS en roosterconcept (tableau?)\\r\\nWerklast roosteraars (excel?)\\r\\nZaalbezetting heatmap vroegboek (Opzet naar Dirk Jan in PDF A3, splits 3 rijen)\\r\\nNO-Show per opleidingsdirecteur (wordt vanaf semtember per opleiding uitgevraagd doro FCO en gekoppeld doro Saskia)\\r\\nvoorspellingsmodel (wacht op inschrijvingen via SAP)\\r\\nOverdracht dashboards (5 sept gesprek Jeroen van Dinter, met iemand van Mivu erbij) Matrix, grafieken en onderliggende databronnen)\\r\\nAutomatisch roosteren\\r\\nMeetinstrument mooi/goed rooster\\r\\nanalyse eindresultaat en tijdstip rooster HC/WG etc\\r\\nmappenstructuur maken op projecten map', '2017-07-12 12:46:33'),\
(131, 24, 124, 'Gesprek Rob en Mira, 10 april 2018 inzake verhuizing Roosteraars naar centraal \\r\\n-	Zorgen over centralisatie. \\r\\n-	Contact met docenten te hebben. \\r\\n-	Klachten over de roostering/de ondersteuning ?\\r\\no	Uitvraag roosteruitvraag\\r\\no	Combinatie werkgroepen en rooster , hergroepen\\r\\no	Overleg moet plaatsvinden\\r\\no	Grote vakken: mastervak/ Eerste helft van de periode gezamenlijk en daarna in werkgroepen uit elkaar. \\r\\n-	Vakcoordinator 7 vakken in 1 periode. Moet in overleg met \\r\\n-	Loop maar even bij docenten langs\\r\\n-	Fysieke verschil G2 en 8e HG. Alles zit bij elkaar. \\r\\n-	Contact. \\r\\n-	Door centralisatie wordt het formeler, wanneer je decentraal zit wordt meerdere zaken voortijdig opgelost;\\r\\n-	Eigen docent , wanneer je zichtbaar en aanspreekbaar \\r\\n-	Ervaringen zijn negatief. Alle voorbeelden werken niet. Communicatie en projectbureau werkt niet . \\r\\n-	Klachten van WP, ze gooien alles op 1 hoop. \\r\\n-	2 om 2, en dan over een half jaar evalueren. ', '2018-04-12 15:04:45');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `project_tasks`\
--\
\
CREATE TABLE `project_tasks` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `project_id` int(10) UNSIGNED DEFAULT NULL,\
  `task_id` int(10) UNSIGNED NOT NULL,\
  `updated_by` int(10) UNSIGNED NOT NULL,\
  `updated_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `project_tasks`\
--\
\
INSERT INTO `project_tasks` (`id`, `project_id`, `task_id`, `updated_by`, `updated_at`) VALUES\
(16, 12, 18, 5, '2015-03-27 09:44:30'),\
(176, 12, 361, 5, '2015-06-10 05:50:03');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `subscriptions`\
--\
\
CREATE TABLE `subscriptions` (\
  `id` int(11) NOT NULL,\
  `member_id` int(11) UNSIGNED NOT NULL,\
  `subscription_id` int(11) NOT NULL,\
  `date` datetime NOT NULL,\
  `price` decimal(5,2) NOT NULL,\
  `created_by` int(11) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `subscription_kinds`\
--\
\
CREATE TABLE `subscription_kinds` (\
  `id` int(11) NOT NULL,\
  `name` varchar(100) NOT NULL,\
  `description` text NOT NULL,\
  `price` decimal(5,2) NOT NULL,\
  `tax` int(10) NOT NULL,\
  `no_tax_possible` tinyint(1) NOT NULL,\
  `status` tinyint(1) NOT NULL COMMENT '''0'' = ''disabled'' & 1 = enabled',\
  `created_by` int(11) UNSIGNED DEFAULT NULL,\
  `updated_by` int(11) UNSIGNED DEFAULT NULL,\
  `updated_at` datetime NOT NULL,\
  `created_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `subscription_kinds`\
--\
\
INSERT INTO `subscription_kinds` (`id`, `name`, `description`, `price`, `tax`, `no_tax_possible`, `status`, `created_by`, `updated_by`, `updated_at`, `created_at`) VALUES\
(23, 'Overigen', '', '0.00', 21, 0, 1, 15, NULL, '2015-10-05 13:28:13', '2015-10-05 13:28:13'),\
(24, 'Project management Opt. ZaalUtil.', '', '125.00', 21, 0, 1, 15, 15, '2020-06-01 17:31:22', '2016-03-04 15:57:51'),\
(25, 'Projectmanagement UGent', '', '120.00', 21, 0, 1, 15, NULL, '2019-05-03 06:20:44', '2019-05-03 06:20:44'),\
(26, 'Treinreizen van & naar Gent', '', '165.00', 21, 0, 1, 15, NULL, '2019-05-03 06:22:49', '2019-05-03 06:22:49'),\
(27, 'Strategische advisering onderwijsplanning', '', '135.00', 21, 0, 1, 15, 15, '2020-06-01 17:33:07', '2020-06-01 17:30:38'),\
(28, 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - aug 2021', 'Functioneel Beheer Roosterapplicatie - H.Tjalsma - aug 2021 desc', '100.00', 21, 0, 1, 77, NULL, '2021-08-20 10:08:05', '2021-08-20 10:08:05');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `tasks`\
--\
\
CREATE TABLE `tasks` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `workspace_id` int(11) NOT NULL,\
  `assigned_to` int(10) UNSIGNED DEFAULT NULL,\
  `short_description` varchar(255) NOT NULL,\
  `description` text NOT NULL,\
  `attachments` text NOT NULL,\
  `UID` varchar(20) NOT NULL,\
  `due_date` date NOT NULL,\
  `agenda_switch` tinyint(1) NOT NULL COMMENT '0 for off 1 for on(deadline)',\
  `time` time NOT NULL,\
  `completed_datetime` datetime NOT NULL,\
  `is_completed` tinyint(1) NOT NULL DEFAULT '0',\
  `priority` tinyint(1) NOT NULL COMMENT '0 for checked, 1 for checked',\
  `company_id` bigint(20) NOT NULL,\
  `contact_id` bigint(20) NOT NULL,\
  `created_at` datetime NOT NULL,\
  `updated_at` datetime NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `sequence` int(5) NOT NULL,\
  `recurring_task` tinyint(4) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `tasks`\
--\
\
INSERT INTO `tasks` (`id`, `workspace_id`, `assigned_to`, `short_description`, `description`, `attachments`, `UID`, `due_date`, `agenda_switch`, `time`, `completed_datetime`, `is_completed`, `priority`, `company_id`, `contact_id`, `created_at`, `updated_at`, `created_by`, `updated_by`, `sequence`, `recurring_task`) VALUES\
(18, 4, NULL, 'Task 1', '', '', '', '2015-03-30', 0, '00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, '2015-03-27 09:41:00', '2015-03-27 09:53:13', 5, NULL, 2, 0),\
(361, 4, NULL, 'kjshdskjhdfssa', '', '', '', '0000-00-00', 1, '00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, '2015-06-10 05:50:03', '2015-06-10 05:50:03', 5, NULL, 3, 0);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `task_areas`\
--\
\
CREATE TABLE `task_areas` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `task_id` int(10) UNSIGNED NOT NULL,\
  `area_id` int(10) UNSIGNED NOT NULL,\
  `created_at` datetime NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `task_areas`\
--\
\
INSERT INTO `task_areas` (`id`, `task_id`, `area_id`, `created_at`, `created_by`) VALUES\
(18, 18, 12, '2015-03-27 09:44:46', 5),\
(19, 18, 14, '2015-03-27 09:44:49', 5),\
(20, 18, 11, '2015-03-27 10:24:08', 5);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `task_comments`\
--\
\
CREATE TABLE `task_comments` (\
  `id` int(11) NOT NULL,\
  `task_id` int(10) UNSIGNED NOT NULL,\
  `comment` text NOT NULL,\
  `created_at` datetime NOT NULL,\
  `created_by` int(11) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `task_contexts`\
--\
\
CREATE TABLE `task_contexts` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `task_id` int(10) UNSIGNED NOT NULL,\
  `context_id` int(10) UNSIGNED DEFAULT NULL,\
  `created_by` int(10) UNSIGNED NOT NULL,\
  `created_at` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `task_contexts`\
--\
\
INSERT INTO `task_contexts` (`id`, `task_id`, `context_id`, `created_by`, `created_at`) VALUES\
(35, 18, 16, 5, '2015-03-27 09:44:36'),\
(36, 18, 19, 5, '2015-03-27 09:44:39');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `throttle`\
--\
\
CREATE TABLE `throttle` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `user_id` int(10) UNSIGNED DEFAULT NULL,\
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `attempts` int(11) NOT NULL DEFAULT '0',\
  `suspended` tinyint(1) NOT NULL DEFAULT '0',\
  `banned` tinyint(1) NOT NULL DEFAULT '0',\
  `last_attempt_at` datetime DEFAULT NULL,\
  `suspended_at` datetime DEFAULT NULL,\
  `banned_at` datetime DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `throttle`\
--\
\
INSERT INTO `throttle` (`id`, `user_id`, `ip_address`, `attempts`, `suspended`, `banned`, `last_attempt_at`, `suspended_at`, `banned_at`) VALUES\
(1, 1, '27.109.18.163', 0, 0, 0, NULL, NULL, NULL),\
(2, 1, '83.162.229.183', 0, 0, 0, NULL, NULL, NULL),\
(3, 1, '82.168.229.50', 0, 0, 0, NULL, NULL, NULL),\
(4, 1, '94.215.153.200', 0, 0, 0, NULL, NULL, NULL),\
(5, 1, '87.208.64.161', 0, 0, 0, NULL, NULL, NULL),\
(6, 2, '27.109.18.163', 0, 0, 0, NULL, NULL, NULL),\
(7, 3, '27.109.18.163', 0, 0, 0, NULL, NULL, NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `users`\
--\
\
CREATE TABLE `users` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `alternate_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `image` text COLLATE utf8_unicode_ci NOT NULL,\
  `permissions` text COLLATE utf8_unicode_ci,\
  `activated` tinyint(1) NOT NULL DEFAULT '0',\
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `activated_at` datetime DEFAULT NULL,\
  `last_login` datetime DEFAULT NULL,\
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `middle_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `phone_number` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `city` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `zipcode` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `company_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `company_description` text COLLATE utf8_unicode_ci,\
  `reason` text COLLATE utf8_unicode_ci,\
  `linkedIn_url` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `facebook_url` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `twitter_url` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `website_url` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `users`\
--\
\
INSERT INTO `users` (`id`, `email`, `alternate_email`, `username`, `password`, `image`, `permissions`, `activated`, `activation_code`, `activated_at`, `last_login`, `persist_code`, `reset_password_code`, `first_name`, `middle_name`, `last_name`, `phone_number`, `address`, `city`, `zipcode`, `company_name`, `company_description`, `reason`, `linkedIn_url`, `facebook_url`, `twitter_url`, `website_url`, `created_at`, `updated_at`) VALUES\
(2, 'jaykesh@devrepublic.nl', '', 'jaykesh', '$2y$10$TPgM6zYO1imLsruLy8kGBumv3qj1aVDQj2uzd3jHL1ECNGuXFMMY2', '', NULL, 1, NULL, NULL, '2021-08-02 13:33:44', '$2y$10$aShZP/8CcVVGGrXB1QNeyuzCOMN9yMnrqHNEgvvdzt8Ht4AdZQ6gS', NULL, 'Jaykesh', NULL, 'Patel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-12-06 05:53:50', '2021-08-02 11:33:44'),\
(5, 'john@devrepublic.nl', '', 'john@devrepublic.nl', '$2y$10$TPgM6zYO1imLsruLy8kGBumv3qj1aVDQj2uzd3jHL1ECNGuXFMMY2', '', NULL, 1, NULL, NULL, '2025-01-10 05:58:24', '$2y$10$KvGGET6UkSNCtnko2FHGZeF0Q7qDwl7T2oDW4PrOn/aSHBbmlPaAm', NULL, 'John', '', 'Wassing', '', 'Florijn', 'Dronten', '8253DM', '', '', '', '', '', '', '', '2015-01-05 15:21:50', '2025-01-10 00:28:24'),\
(15, 'dirkjan@datajockey.nl', '', 'dirkJand', '$2y$10$NEzXl7bdMzIR6hgzHibmEO/vHhpb6Ks0BKdvcxgy716WTK81ATWwK', '', NULL, 1, NULL, NULL, '2022-02-09 17:25:49', '$2y$10$lIWUlnBX2UzysN4wKZwalum0J.uihNds4JsiUDgPHjci6iT0zD4ea', NULL, 'Dirk Jan', NULL, 'Durieux', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-01-15 13:05:05', '2022-02-09 16:25:49'),\
(75, 'reena@devrepubluc.nl', '', 'reena@devrepubluc.nl', '$2y$10$0jotRr0Jf6zB2cIj2btViuC/zVTadP7DbHi8iddtIAPMw98IDGSya', '', NULL, 1, NULL, NULL, '2021-06-16 11:37:40', '$2y$10$yAgL.aZFSNUZkM8AYDlMyuxgLP.mtZeA1gKVoe/rDIu/697dsBbqa', NULL, 'Reena', 'M.', 'Barad', '', 'I 702 Gota', 'ahamadabad', '380015', '', '', '', '', '', '', '', '2021-06-16 09:13:37', '2021-06-16 09:37:40'),\
(77, 'info@adiba.nl', '', 'info@adiba.nl', '$2y$10$5KJqjqzU9q2V.OeAAOP3BuxUEZsYrGD1xBn3cdZDLLf2.UaT/GNyq', '', NULL, 1, NULL, NULL, '2022-02-09 09:10:04', '$2y$10$1Hbi8cP7eaMDNtR5DpJLKOjpxSDYYw4kkQZzEbCtPU3mZBKdNJ5Eq', NULL, 'Fokko', NULL, 'Horst', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-08-12 07:13:36', '2022-02-09 08:10:04');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `users_groups`\
--\
\
CREATE TABLE `users_groups` (\
  `user_id` int(10) UNSIGNED NOT NULL,\
  `group_id` int(10) UNSIGNED NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `users_groups`\
--\
\
INSERT INTO `users_groups` (`user_id`, `group_id`) VALUES\
(2, 1),\
(5, 1),\
(5, 4),\
(15, 1),\
(28, 1),\
(75, 2),\
(75, 4),\
(77, 1);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `user_default_filter`\
--\
\
CREATE TABLE `user_default_filter` (\
  `id` int(11) UNSIGNED NOT NULL,\
  `user_id` int(10) UNSIGNED NOT NULL,\
  `filter_text` text,\
  `type` char(1) NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_ambassador`\
--\
\
CREATE TABLE `website_ambassador` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `summery` varchar(512) COLLATE utf8_unicode_ci NOT NULL,\
  `content` text COLLATE utf8_unicode_ci NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_contactforms`\
--\
\
CREATE TABLE `website_contactforms` (\
  `id` int(11) NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL,\
  `message` text COLLATE utf8_unicode_ci NOT NULL,\
  `created_date` date NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `website_contactforms`\
--\
\
INSERT INTO `website_contactforms` (`id`, `name`, `subject`, `message`, `created_date`) VALUES\
(1, 'contact 1', 'test', 'test message', '2014-12-01');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_news`\
--\
\
CREATE TABLE `website_news` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,\
  `summery` text COLLATE utf8_unicode_ci,\
  `content` text COLLATE utf8_unicode_ci,\
  `publication_date` date NOT NULL,\
  `expiration_date` date NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `website_news`\
--\
\
INSERT INTO `website_news` (`id`, `title`, `summery`, `content`, `publication_date`, `expiration_date`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES\
(1, 'news 1', 'summery 1', '', '2014-12-09', '2015-03-20', '2014-12-22 10:20:26', '2014-12-22 10:20:36', NULL, NULL);\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_pages`\
--\
\
CREATE TABLE `website_pages` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `website_pages`\
--\
\
INSERT INTO `website_pages` (`id`, `title`) VALUES\
(1, 'Test Page');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_page_posts`\
--\
\
CREATE TABLE `website_page_posts` (\
  `id` int(11) NOT NULL,\
  `website_page_id` int(10) UNSIGNED NOT NULL,\
  `sequence` int(11) NOT NULL,\
  `title` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `content` text COLLATE utf8_unicode_ci NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `website_teammembers`\
--\
\
CREATE TABLE `website_teammembers` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,\
  `summery` varchar(512) COLLATE utf8_unicode_ci NOT NULL,\
  `content` text COLLATE utf8_unicode_ci NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `wg_members`\
--\
\
CREATE TABLE `wg_members` (\
  `id` int(11) NOT NULL,\
  `workgroup_id` int(10) UNSIGNED NOT NULL,\
  `member_id` int(10) UNSIGNED NOT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `wg_members`\
--\
\
INSERT INTO `wg_members` (`id`, `workgroup_id`, `member_id`, `created_at`, `updated_at`) VALUES\
(4, 1, 4, '2014-12-19 06:03:12', '2014-12-19 06:03:12'),\
(16, 1, 9, '2015-01-08 12:03:01', '2015-01-08 12:03:01'),\
(26, 1, 21, '2015-01-20 09:06:14', '2015-01-20 09:06:14'),\
(54, 1, 17, '2015-03-03 09:17:34', '2015-03-03 09:17:34'),\
(56, 1, 19, '2015-03-03 09:18:08', '2015-03-03 09:18:08'),\
(71, 2, 29, '2015-04-22 17:35:57', '2015-04-22 17:35:57'),\
(72, 2, 3, '2015-04-22 17:36:23', '2015-04-22 17:36:23'),\
(73, 2, 5, '2015-04-22 17:36:38', '2015-04-22 17:36:38'),\
(74, 2, 30, '2015-04-22 17:37:45', '2015-04-22 17:37:45'),\
(75, 2, 33, '2015-04-23 07:31:23', '2015-04-23 07:31:23'),\
(76, 2, 34, '2015-04-23 07:33:57', '2015-04-23 07:33:57'),\
(77, 2, 35, '2015-04-23 07:34:48', '2015-04-23 07:34:48'),\
(104, 1, 13, '2015-08-06 18:14:06', '2015-08-06 18:14:06'),\
(105, 1, 14, '2015-08-06 18:14:19', '2015-08-06 18:14:19'),\
(106, 1, 16, '2015-08-06 18:14:39', '2015-08-06 18:14:39'),\
(107, 1, 18, '2015-08-06 18:14:50', '2015-08-06 18:14:50'),\
(108, 1, 20, '2015-08-06 18:15:02', '2015-08-06 18:15:02'),\
(109, 1, 22, '2015-08-06 18:15:15', '2015-08-06 18:15:15'),\
(110, 1, 23, '2015-08-06 18:15:26', '2015-08-06 18:15:26'),\
(112, 1, 27, '2015-08-06 18:15:57', '2015-08-06 18:15:57'),\
(113, 1, 26, '2015-08-06 18:16:08', '2015-08-06 18:16:08'),\
(114, 1, 25, '2015-08-06 18:16:20', '2015-08-06 18:16:20'),\
(149, 1, 51, '2015-11-25 12:09:05', '2015-11-25 12:09:05'),\
(150, 2, 51, '2015-11-25 12:09:05', '2015-11-25 12:09:05'),\
(163, 2, 62, '2015-12-14 08:12:20', '2015-12-14 08:12:20'),\
(164, 2, 50, '2015-12-15 08:56:55', '2015-12-15 08:56:55'),\
(171, 2, 36, '2016-05-27 17:38:56', '2016-05-27 17:38:56'),\
(175, 1, 24, '2017-04-21 12:54:49', '2017-04-21 12:54:49'),\
(176, 2, 24, '2017-04-21 12:54:49', '2017-04-21 12:54:49'),\
(185, 1, 75, '2021-06-16 09:37:27', '2021-06-16 09:37:27'),\
(186, 2, 75, '2021-06-16 09:37:27', '2021-06-16 09:37:27'),\
(187, 1, 76, '2021-08-12 07:10:52', '2021-08-12 07:10:52');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `workgroups`\
--\
\
CREATE TABLE `workgroups` (\
  `id` int(10) UNSIGNED NOT NULL,\
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,\
  `created_by` int(10) UNSIGNED DEFAULT NULL,\
  `updated_by` int(10) UNSIGNED DEFAULT NULL,\
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',\
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'\
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;\
\
--\
-- Dumping data for table `workgroups`\
--\
\
INSERT INTO `workgroups` (`id`, `name`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES\
(1, 'Pressure Cooker', NULL, 15, '2014-12-06 05:55:13', '2015-01-15 13:08:07'),\
(2, 'IncZwolle', 15, NULL, '2015-02-11 15:08:41', '2015-02-11 15:08:41');\
\
-- --------------------------------------------------------\
\
--\
-- Table structure for table `workspaces`\
--\
\
CREATE TABLE `workspaces` (\
  `id` int(11) NOT NULL,\
  `member_id` int(11) UNSIGNED DEFAULT NULL,\
  `date` datetime NOT NULL\
) ENGINE=InnoDB DEFAULT CHARSET=latin1;\
\
--\
-- Dumping data for table `workspaces`\
--\
\
INSERT INTO `workspaces` (`id`, `member_id`, `date`) VALUES\
(2, 2, '0000-00-00 00:00:00'),\
(4, 5, '0000-00-00 00:00:00'),\
(7, 15, '0000-00-00 00:00:00'),\
(63, 75, '2021-06-16 11:13:37');\
\
--\
-- Indexes for dumped tables\
--\
\
--\
-- Indexes for table `areas`\
--\
ALTER TABLE `areas`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`workspace_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `companies`\
--\
ALTER TABLE `companies`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`),\
  ADD KEY `workgroup_id` (`workgroup_id`);\
\
--\
-- Indexes for table `company_notes`\
--\
ALTER TABLE `company_notes`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `company_id` (`company_id`),\
  ADD KEY `user_id` (`user_id`);\
\
--\
-- Indexes for table `contactperson_note`\
--\
ALTER TABLE `contactperson_note`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `contacts`\
--\
ALTER TABLE `contacts`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `company_id` (`company_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `contexts`\
--\
ALTER TABLE `contexts`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`workspace_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `conversations`\
--\
ALTER TABLE `conversations`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `workgroup_id` (`workgroup_id`),\
  ADD KEY `member_id` (`member_id`),\
  ADD KEY `parent_conversation_id` (`parent_conversation_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `documents`\
--\
ALTER TABLE `documents`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `project_id` (`project_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `document_comments`\
--\
ALTER TABLE `document_comments`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `document_id` (`document_id`),\
  ADD KEY `created_by` (`created_by`);\
\
--\
-- Indexes for table `document_files`\
--\
ALTER TABLE `document_files`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `document_id` (`document_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `events`\
--\
ALTER TABLE `events`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `event_days`\
--\
ALTER TABLE `event_days`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`),\
  ADD KEY `event_days_event_id_index` (`event_id`);\
\
--\
-- Indexes for table `event_day_modules`\
--\
ALTER TABLE `event_day_modules`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `event_id` (`event_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`),\
  ADD KEY `event_day_id` (`event_day_id`);\
\
--\
-- Indexes for table `event_registrations`\
--\
ALTER TABLE `event_registrations`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `event_id` (`event_id`,`member_id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- Indexes for table `event_workgroups`\
--\
ALTER TABLE `event_workgroups`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `event_id` (`event_id`),\
  ADD KEY `workgroup_id` (`workgroup_id`);\
\
--\
-- Indexes for table `galleries`\
--\
ALTER TABLE `galleries`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`,`updated_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `general_settings`\
--\
ALTER TABLE `general_settings`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `general_settings_old`\
--\
ALTER TABLE `general_settings_old`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `groups`\
--\
ALTER TABLE `groups`\
  ADD PRIMARY KEY (`id`),\
  ADD UNIQUE KEY `groups_name_unique` (`name`);\
\
--\
-- Indexes for table `groups_list`\
--\
ALTER TABLE `groups_list`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `workspace_id` (`workspace_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `icons`\
--\
ALTER TABLE `icons`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `images`\
--\
ALTER TABLE `images`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `gallery_id` (`gallery_id`);\
\
--\
-- Indexes for table `inbox_mail`\
--\
ALTER TABLE `inbox_mail`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `invite_workgroup_members`\
--\
ALTER TABLE `invite_workgroup_members`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`),\
  ADD KEY `workgroup_id` (`workgroup_id`);\
\
--\
-- Indexes for table `invoicelines`\
--\
ALTER TABLE `invoicelines`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `invoice_id` (`invoice_id`);\
\
--\
-- Indexes for table `invoiceline_mistral`\
--\
ALTER TABLE `invoiceline_mistral`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `invoice_id` (`invoice_id`);\
\
--\
-- Indexes for table `invoiceline_new`\
--\
ALTER TABLE `invoiceline_new`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `invoice_id` (`invoice_id`);\
\
--\
-- Indexes for table `invoices`\
--\
ALTER TABLE `invoices`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- Indexes for table `invoice_mistral`\
--\
ALTER TABLE `invoice_mistral`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- Indexes for table `invoice_new`\
--\
ALTER TABLE `invoice_new`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- Indexes for table `links`\
--\
ALTER TABLE `links`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `page_id` (`page_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `lists`\
--\
ALTER TABLE `lists`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `workspace_id` (`workspace_id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`),\
  ADD KEY `project_id` (`project_id`),\
  ADD KEY `group_id` (`group_id`);\
\
--\
-- Indexes for table `list_items`\
--\
ALTER TABLE `list_items`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `list_id` (`list_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `mail_templates`\
--\
ALTER TABLE `mail_templates`\
  ADD PRIMARY KEY (`id`),\
  ADD UNIQUE KEY `mail_templates_title_unique` (`trigger`);\
\
--\
-- Indexes for table `pages`\
--\
ALTER TABLE `pages`\
  ADD PRIMARY KEY (`id`),\
  ADD UNIQUE KEY `pages_title_unique` (`title`);\
\
--\
-- Indexes for table `payments`\
--\
ALTER TABLE `payments`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `projects`\
--\
ALTER TABLE `projects`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `parent_project_id` (`parent_project_id`),\
  ADD KEY `workspace_id` (`workspace_id`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `project_members`\
--\
ALTER TABLE `project_members`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `project_id` (`project_id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- Indexes for table `project_notes`\
--\
ALTER TABLE `project_notes`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `company_id` (`project_id`),\
  ADD KEY `user_id` (`user_id`);\
\
--\
-- Indexes for table `project_tasks`\
--\
ALTER TABLE `project_tasks`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `task_id` (`task_id`),\
  ADD KEY `project_id` (`project_id`),\
  ADD KEY `created_by` (`updated_by`);\
\
--\
-- Indexes for table `subscriptions`\
--\
ALTER TABLE `subscriptions`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`),\
  ADD KEY `subscription_id` (`subscription_id`),\
  ADD KEY `created_by` (`created_by`);\
\
--\
-- Indexes for table `subscription_kinds`\
--\
ALTER TABLE `subscription_kinds`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `tasks`\
--\
ALTER TABLE `tasks`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`,`updated_by`),\
  ADD KEY `updated_by` (`updated_by`),\
  ADD KEY `workspace_id` (`workspace_id`),\
  ADD KEY `workspace_id_2` (`workspace_id`),\
  ADD KEY `assign_to` (`assigned_to`);\
\
--\
-- Indexes for table `task_areas`\
--\
ALTER TABLE `task_areas`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `area_id` (`area_id`),\
  ADD KEY `task_id` (`task_id`);\
\
--\
-- Indexes for table `task_comments`\
--\
ALTER TABLE `task_comments`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `task_id` (`task_id`),\
  ADD KEY `created_by` (`created_by`);\
\
--\
-- Indexes for table `task_contexts`\
--\
ALTER TABLE `task_contexts`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `task_id` (`task_id`),\
  ADD KEY `context_id` (`context_id`),\
  ADD KEY `created_by` (`created_by`);\
\
--\
-- Indexes for table `throttle`\
--\
ALTER TABLE `throttle`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `throttle_user_id_index` (`user_id`);\
\
--\
-- Indexes for table `users`\
--\
ALTER TABLE `users`\
  ADD PRIMARY KEY (`id`),\
  ADD UNIQUE KEY `users_email_unique` (`email`),\
  ADD UNIQUE KEY `users_username_unique` (`username`),\
  ADD KEY `users_activation_code_index` (`activation_code`),\
  ADD KEY `users_reset_password_code_index` (`reset_password_code`);\
\
--\
-- Indexes for table `users_groups`\
--\
ALTER TABLE `users_groups`\
  ADD PRIMARY KEY (`user_id`,`group_id`);\
\
--\
-- Indexes for table `user_default_filter`\
--\
ALTER TABLE `user_default_filter`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `user_id` (`user_id`);\
\
--\
-- Indexes for table `website_ambassador`\
--\
ALTER TABLE `website_ambassador`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `website_contactforms`\
--\
ALTER TABLE `website_contactforms`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `website_news`\
--\
ALTER TABLE `website_news`\
  ADD PRIMARY KEY (`id`),\
  ADD UNIQUE KEY `pages_title_unique` (`title`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `website_pages`\
--\
ALTER TABLE `website_pages`\
  ADD PRIMARY KEY (`id`);\
\
--\
-- Indexes for table `website_page_posts`\
--\
ALTER TABLE `website_page_posts`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `website_page_id` (`website_page_id`);\
\
--\
-- Indexes for table `website_teammembers`\
--\
ALTER TABLE `website_teammembers`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `created_by` (`created_by`),\
  ADD KEY `updated_by` (`updated_by`);\
\
--\
-- Indexes for table `wg_members`\
--\
ALTER TABLE `wg_members`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `workgroup_id` (`workgroup_id`,`member_id`);\
\
--\
-- Indexes for table `workgroups`\
--\
ALTER TABLE `workgroups`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `updated_by` (`updated_by`,`created_at`),\
  ADD KEY `created_by` (`created_by`,`updated_by`);\
\
--\
-- Indexes for table `workspaces`\
--\
ALTER TABLE `workspaces`\
  ADD PRIMARY KEY (`id`),\
  ADD KEY `member_id` (`member_id`);\
\
--\
-- AUTO_INCREMENT for dumped tables\
--\
\
--\
-- AUTO_INCREMENT for table `areas`\
--\
ALTER TABLE `areas`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;\
\
--\
-- AUTO_INCREMENT for table `companies`\
--\
ALTER TABLE `companies`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;\
\
--\
-- AUTO_INCREMENT for table `company_notes`\
--\
ALTER TABLE `company_notes`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;\
\
--\
-- AUTO_INCREMENT for table `contactperson_note`\
--\
ALTER TABLE `contactperson_note`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;\
\
--\
-- AUTO_INCREMENT for table `contacts`\
--\
ALTER TABLE `contacts`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;\
\
--\
-- AUTO_INCREMENT for table `contexts`\
--\
ALTER TABLE `contexts`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;\
\
--\
-- AUTO_INCREMENT for table `conversations`\
--\
ALTER TABLE `conversations`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `documents`\
--\
ALTER TABLE `documents`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;\
\
--\
-- AUTO_INCREMENT for table `document_comments`\
--\
ALTER TABLE `document_comments`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;\
\
--\
-- AUTO_INCREMENT for table `document_files`\
--\
ALTER TABLE `document_files`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;\
\
--\
-- AUTO_INCREMENT for table `events`\
--\
ALTER TABLE `events`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `event_days`\
--\
ALTER TABLE `event_days`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `event_day_modules`\
--\
ALTER TABLE `event_day_modules`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `event_registrations`\
--\
ALTER TABLE `event_registrations`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `event_workgroups`\
--\
ALTER TABLE `event_workgroups`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `galleries`\
--\
ALTER TABLE `galleries`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;\
\
--\
-- AUTO_INCREMENT for table `general_settings`\
--\
ALTER TABLE `general_settings`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `general_settings_old`\
--\
ALTER TABLE `general_settings_old`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `groups`\
--\
ALTER TABLE `groups`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;\
\
--\
-- AUTO_INCREMENT for table `groups_list`\
--\
ALTER TABLE `groups_list`\
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `icons`\
--\
ALTER TABLE `icons`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;\
\
--\
-- AUTO_INCREMENT for table `images`\
--\
ALTER TABLE `images`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;\
\
--\
-- AUTO_INCREMENT for table `inbox_mail`\
--\
ALTER TABLE `inbox_mail`\
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;\
\
--\
-- AUTO_INCREMENT for table `invite_workgroup_members`\
--\
ALTER TABLE `invite_workgroup_members`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `invoicelines`\
--\
ALTER TABLE `invoicelines`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=588;\
\
--\
-- AUTO_INCREMENT for table `invoiceline_mistral`\
--\
ALTER TABLE `invoiceline_mistral`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;\
\
--\
-- AUTO_INCREMENT for table `invoiceline_new`\
--\
ALTER TABLE `invoiceline_new`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;\
\
--\
-- AUTO_INCREMENT for table `invoices`\
--\
ALTER TABLE `invoices`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=440;\
\
--\
-- AUTO_INCREMENT for table `invoice_mistral`\
--\
ALTER TABLE `invoice_mistral`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;\
\
--\
-- AUTO_INCREMENT for table `invoice_new`\
--\
ALTER TABLE `invoice_new`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;\
\
--\
-- AUTO_INCREMENT for table `links`\
--\
ALTER TABLE `links`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `lists`\
--\
ALTER TABLE `lists`\
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `list_items`\
--\
ALTER TABLE `list_items`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `mail_templates`\
--\
ALTER TABLE `mail_templates`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;\
\
--\
-- AUTO_INCREMENT for table `pages`\
--\
ALTER TABLE `pages`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `payments`\
--\
ALTER TABLE `payments`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;\
\
--\
-- AUTO_INCREMENT for table `projects`\
--\
ALTER TABLE `projects`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;\
\
--\
-- AUTO_INCREMENT for table `project_members`\
--\
ALTER TABLE `project_members`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `project_notes`\
--\
ALTER TABLE `project_notes`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;\
\
--\
-- AUTO_INCREMENT for table `project_tasks`\
--\
ALTER TABLE `project_tasks`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;\
\
--\
-- AUTO_INCREMENT for table `subscriptions`\
--\
ALTER TABLE `subscriptions`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `subscription_kinds`\
--\
ALTER TABLE `subscription_kinds`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;\
\
--\
-- AUTO_INCREMENT for table `tasks`\
--\
ALTER TABLE `tasks`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=362;\
\
--\
-- AUTO_INCREMENT for table `task_areas`\
--\
ALTER TABLE `task_areas`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;\
\
--\
-- AUTO_INCREMENT for table `task_comments`\
--\
ALTER TABLE `task_comments`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `task_contexts`\
--\
ALTER TABLE `task_contexts`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;\
\
--\
-- AUTO_INCREMENT for table `throttle`\
--\
ALTER TABLE `throttle`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;\
\
--\
-- AUTO_INCREMENT for table `users`\
--\
ALTER TABLE `users`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;\
\
--\
-- AUTO_INCREMENT for table `user_default_filter`\
--\
ALTER TABLE `user_default_filter`\
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `website_ambassador`\
--\
ALTER TABLE `website_ambassador`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `website_contactforms`\
--\
ALTER TABLE `website_contactforms`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `website_news`\
--\
ALTER TABLE `website_news`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `website_pages`\
--\
ALTER TABLE `website_pages`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;\
\
--\
-- AUTO_INCREMENT for table `website_page_posts`\
--\
ALTER TABLE `website_page_posts`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `website_teammembers`\
--\
ALTER TABLE `website_teammembers`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;\
\
--\
-- AUTO_INCREMENT for table `wg_members`\
--\
ALTER TABLE `wg_members`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;\
\
--\
-- AUTO_INCREMENT for table `workgroups`\
--\
ALTER TABLE `workgroups`\
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;\
\
--\
-- AUTO_INCREMENT for table `workspaces`\
--\
ALTER TABLE `workspaces`\
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;\
\
--\
-- Constraints for dumped tables\
--\
\
--\
-- Constraints for table `areas`\
--\
ALTER TABLE `areas`\
  ADD CONSTRAINT `areas_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `areas_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `companies`\
--\
ALTER TABLE `companies`\
  ADD CONSTRAINT `companies_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `companies_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `company_notes`\
--\
ALTER TABLE `company_notes`\
  ADD CONSTRAINT `company_notes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `company_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `contacts`\
--\
ALTER TABLE `contacts`\
  ADD CONSTRAINT `contacts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `contacts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `contacts_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `contexts`\
--\
ALTER TABLE `contexts`\
  ADD CONSTRAINT `context_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `context_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `conversations`\
--\
ALTER TABLE `conversations`\
  ADD CONSTRAINT `conversation_parent_conversation_id_foreign` FOREIGN KEY (`parent_conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `conversations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `conversations_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `conversations_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `conversations_wg_id_foreign` FOREIGN KEY (`workgroup_id`) REFERENCES `workgroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `documents`\
--\
ALTER TABLE `documents`\
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `document_comments`\
--\
ALTER TABLE `document_comments`\
  ADD CONSTRAINT `document_comments_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `document_comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `document_files`\
--\
ALTER TABLE `document_files`\
  ADD CONSTRAINT `document_files_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `document_files_ibfk_2` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `events`\
--\
ALTER TABLE `events`\
  ADD CONSTRAINT `events_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `events_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `event_days`\
--\
ALTER TABLE `event_days`\
  ADD CONSTRAINT `ed_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `ed_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `event_days_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `event_day_modules`\
--\
ALTER TABLE `event_day_modules`\
  ADD CONSTRAINT `edm_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `edm_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `edm_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `event_day_modules_ibfk_1` FOREIGN KEY (`event_day_id`) REFERENCES `event_days` (`id`);\
\
--\
-- Constraints for table `event_registrations`\
--\
ALTER TABLE `event_registrations`\
  ADD CONSTRAINT `event_registration_event_id` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `event_registration_user_id` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `event_workgroups`\
--\
ALTER TABLE `event_workgroups`\
  ADD CONSTRAINT `ew_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `ew_workgroup_id_foreign` FOREIGN KEY (`workgroup_id`) REFERENCES `workgroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `galleries`\
--\
ALTER TABLE `galleries`\
  ADD CONSTRAINT `galleries_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `galleries_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `general_settings_old`\
--\
ALTER TABLE `general_settings_old`\
  ADD CONSTRAINT `general_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `groups_list`\
--\
ALTER TABLE `groups_list`\
  ADD CONSTRAINT `groups_list_ibfk_1` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `groups_list_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;\
\
--\
-- Constraints for table `images`\
--\
ALTER TABLE `images`\
  ADD CONSTRAINT `images_gallery_id_foreign` FOREIGN KEY (`gallery_id`) REFERENCES `galleries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `invite_workgroup_members`\
--\
ALTER TABLE `invite_workgroup_members`\
  ADD CONSTRAINT `invite_wg_member_member_id` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `invite_wg_member_workgroup_id` FOREIGN KEY (`workgroup_id`) REFERENCES `workgroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `invoices`\
--\
ALTER TABLE `invoices`\
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `links`\
--\
ALTER TABLE `links`\
  ADD CONSTRAINT `links_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `links_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `links_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `lists`\
--\
ALTER TABLE `lists`\
  ADD CONSTRAINT `list_workspace_id` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `lists_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `lists_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `lists_ibfk_3` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `lists_ibfk_4` FOREIGN KEY (`group_id`) REFERENCES `groups_list` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `list_items`\
--\
ALTER TABLE `list_items`\
  ADD CONSTRAINT `list_items_ibfk_1` FOREIGN KEY (`list_id`) REFERENCES `lists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `list_items_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `projects`\
--\
ALTER TABLE `projects`\
  ADD CONSTRAINT `projects_parent_projct_id_foreign` FOREIGN KEY (`parent_project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `projects_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `projects_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `project_members`\
--\
ALTER TABLE `project_members`\
  ADD CONSTRAINT `project_members_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `project_members_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `project_tasks`\
--\
ALTER TABLE `project_tasks`\
  ADD CONSTRAINT `project_tasks_created_id_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `project_tasks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `project_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `subscriptions`\
--\
ALTER TABLE `subscriptions`\
  ADD CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `subscription_kinds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `subscriptions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `subscriptions_ibfk_3` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `subscription_kinds`\
--\
ALTER TABLE `subscription_kinds`\
  ADD CONSTRAINT `subscription_kinds_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `subscription_kinds_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `tasks`\
--\
ALTER TABLE `tasks`\
  ADD CONSTRAINT `tasks_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `tasks_foreign_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `tasks_workspace_id_foreign` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `task_areas`\
--\
ALTER TABLE `task_areas`\
  ADD CONSTRAINT `task_areas_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `task_areas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `task_areas_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `task_comments`\
--\
ALTER TABLE `task_comments`\
  ADD CONSTRAINT `task_comments_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `task_comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `task_contexts`\
--\
ALTER TABLE `task_contexts`\
  ADD CONSTRAINT `tasks_contexts_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `tasks_contexts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,\
  ADD CONSTRAINT `tasks_contexts_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `user_default_filter`\
--\
ALTER TABLE `user_default_filter`\
  ADD CONSTRAINT `user_default_filter_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `website_ambassador`\
--\
ALTER TABLE `website_ambassador`\
  ADD CONSTRAINT `wa_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `wa_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `website_news`\
--\
ALTER TABLE `website_news`\
  ADD CONSTRAINT `website_news_updated_by_foregin` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `websites_news_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `website_page_posts`\
--\
ALTER TABLE `website_page_posts`\
  ADD CONSTRAINT `website_page_posts_ibfk_1` FOREIGN KEY (`website_page_id`) REFERENCES `website_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
\
--\
-- Constraints for table `website_teammembers`\
--\
ALTER TABLE `website_teammembers`\
  ADD CONSTRAINT `wt_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `wt_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `wg_members`\
--\
ALTER TABLE `wg_members`\
  ADD CONSTRAINT `wg_member_workgroup_id_foreign` FOREIGN KEY (`workgroup_id`) REFERENCES `workgroups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;\
\
--\
-- Constraints for table `workgroups`\
--\
ALTER TABLE `workgroups`\
  ADD CONSTRAINT `workgroups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,\
  ADD CONSTRAINT `workgroups_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;\
\
--\
-- Constraints for table `workspaces`\
--\
ALTER TABLE `workspaces`\
  ADD CONSTRAINT `workspaces_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;\
