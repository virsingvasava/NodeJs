#! /bin/bash
: '	#Output log generate on specific file
	ls -al 1>result_log.txt 2>&1'

# echo -e "\033[0;31mERROR:\e[0m Can't connect, please retry:" RED color
# echo -e "\033[0;32mSUCCESS:\e[0m Databse connected successfully." GREEN color
# echo -e "\033[1;33mWARNING:\e[0m warn retry:" YELLOW color
# echo -e "\033[1;36mCYAN:\e[0m CYAN color retry:" CYAN color

echo "Enter Mysql Credential :"
read -p "Username : " ROOT_USER
read -p "Password : " ROOT_PASSWORD
read -p "Enter database directory name : " directory
if [ -z $ROOT_USER ]; then
    echo "Username is Required." 
    exit
fi
if [ -z $ROOT_PASSWORD ]; then
    echo "Password is Required." 
    exit ;
fi

if mysql -u "$ROOT_USER" -p"$ROOT_PASSWORD" -e ";" 2>/dev/null ; then
	echo -e "\033[0;32mSUCCESS: Databse connection successfully.\e[0m"
	if [ -d "$directory" ]; then
	  	for file in "$directory"/*
		do
			FILE_NAME=$(basename $file)
			DB_NAME=${FILE_NAME%%.*}
			
			RESULT=`mysqlshow -u "$ROOT_USER" -p"$ROOT_PASSWORD" $DB_NAME 2>/dev/null| grep -v Wildcard | grep -o $DB_NAME`
			if [ "$RESULT" == "$DB_NAME" ]; then
			    echo -e "\033[1;33mThis Database Already Exits : \033[1;36m[ $DB_NAME ] \e[0m"
			else
				mysql -u "$ROOT_USER" -p"$ROOT_PASSWORD" -e "CREATE DATABASE $DB_NAME" 2>/dev/null
				mysql -u "$ROOT_USER" -p"$ROOT_PASSWORD" $DB_NAME < ${file} 2>/dev/null
				echo -e "\033[0;32mDONE: \033[1;36mDatabase is imported: [ $DB_NAME < ${file} ] \e[0m"
			fi
			for i in {16..21} {21..16} ; do echo -en "\e[38;5;${i}m#\e[0m" ; done ; echo
		done
		echo -e "\033[1;36mList All Database \e[0m"
		mysql -u "$ROOT_USER" -p"$ROOT_PASSWORD" -e 'show databases' 2>/dev/null
	else
		echo -e "\033[1;33mThis Directory does exits: \033[1;36m( $directory ) \e[0m"
	fi
else
	echo -e "\033[0;31mERROR: MYSQL databse can't connect, please retry:"
fi